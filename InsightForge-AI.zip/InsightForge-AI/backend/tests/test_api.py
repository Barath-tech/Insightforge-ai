import sqlite3

import pytest
from app.core.config import settings


@pytest.mark.parametrize("name", ["UK Retail Operations.csv", "uk_retail.sqlite"])
def test_upload_profile_preview_query(client, samples, name):
    with (samples / "samples" / name).open("rb") as f:
        response = client.post("/api/datasets", files={"file": (name, f)})
    assert response.status_code == 201, response.text
    dataset = response.json()
    assert "duckdb_path" not in dataset
    assert dataset["row_count"] == 4873
    identifier = dataset["id"]
    prefix = f"/api/datasets/{identifier}"
    profile = client.get(prefix + "/profile").json()
    table = next(iter(profile["tables"]))
    assert (
        next(i for i in profile["tables"][table]["issues"] if i["code"] == "duplicate_ids")["count"]
        == 23
    )
    preview = client.get(prefix + "/preview", params={"table": table, "limit": 10})
    assert preview.status_code == 200, preview.text
    assert preview.json()["row_count"] == 10
    assert preview.json()["rows"][2]["delivery_timestamp"].startswith("2024-01-09")
    run = client.post(
        prefix + "/query", json={"sql": f'SELECT COUNT(*) AS n FROM "{table}"'}
    ).json()
    assert run["run"]["status"] == "ok", run
    assert run["result"]["rows"] == [{"n": 4873}]
    blocked = client.post(prefix + "/query", json={"sql": f'DROP TABLE "{table}"'}).json()
    assert blocked["run"]["status"] == "validation_error"
    failed = client.post(
        prefix + "/query", json={"sql": f'SELECT no_such_column FROM "{table}"'}
    ).json()
    assert failed["run"]["status"] == "execution_error"
    assert len(client.get(prefix + "/queries").json()) == 3
    assert client.get(prefix + "/preview", params={"table": "not_allowed"}).status_code == 400


def test_validation_and_demo(client, monkeypatch):
    assert client.get("/api/datasets/missing").status_code == 404
    assert client.post("/api/datasets", files={"file": ("bad.exe", b"x")}).status_code == 415
    assert client.post("/api/datasets", files={"file": ("bad.csv", b"")}).status_code == 400
    assert client.post("/api/datasets", files={"file": ("bad.db", b"invalid")}).status_code == 422
    monkeypatch.setattr(settings, "max_upload_mb", 0)
    assert client.post("/api/datasets", files={"file": ("big.csv", b"a\n1")}).status_code == 413
    monkeypatch.setattr(settings, "max_upload_mb", 50)
    assert client.post("/api/datasets/demo").status_code == 201
    assert len(client.get("/api/datasets").json()) == 1
    monkeypatch.setattr(settings, "max_rows", 1)
    assert client.post("/api/datasets", files={"file": ("big.csv", b"a\n1\n2")}).status_code == 422


def test_sqlite_multiple_tables_and_names(client, tmp_path):
    path = tmp_path / "multi.db"
    with sqlite3.connect(path) as conn:
        for table in ["sales", "raw_sales", 'odd"name']:
            conn.execute('CREATE TABLE "' + table.replace('"', '""') + '" ("Item ID" TEXT)')
    with path.open("rb") as f:
        response = client.post("/api/datasets", files={"file": ("multi.db", f)})
    assert response.status_code == 201, response.text
    names = response.json()["table_names"]
    assert len(names) == len(set(names)) == 6
