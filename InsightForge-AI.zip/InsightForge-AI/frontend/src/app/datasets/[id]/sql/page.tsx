"use client";
import { useState } from "react";
import dynamic from "next/dynamic";
import { sql } from "@codemirror/lang-sql";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Clock, Play, ShieldCheck, Terminal } from "lucide-react";
import { api } from "@/lib/api";
import { Journey } from "@/components/journey";
import { Button } from "@/components/ui/button";
import { DataTable, ErrorBox, Loading } from "@/components/shared";
const CodeMirror = dynamic(() => import("@uiw/react-codemirror"), {
  ssr: false,
  loading: () => <Loading />,
});
export default function SQLConsole({ params }: { params: { id: string } }) {
  const id = params.id,
    client = useQueryClient();
  const [code, setCode] = useState<string | null>(null);
  const dataset = useQuery({
      queryKey: ["dataset", id],
      queryFn: () => api.dataset(id),
    }),
    profile = useQuery({
      queryKey: ["profile", id],
      queryFn: () => api.profile(id),
    }),
    history = useQuery({
      queryKey: ["history", id],
      queryFn: () => api.history(id),
    });
  const query = useMutation({
    mutationFn: (value: string) => api.query(id, value),
    onSuccess: () => client.invalidateQueries({ queryKey: ["history", id] }),
  });
  if (dataset.error || profile.error)
    return (
      <ErrorBox
        error={dataset.error || profile.error}
        retry={() => {
          dataset.refetch();
          profile.refetch();
        }}
      />
    );
  if (!dataset.data || !profile.data) return <Loading />;
  const table = Object.keys(profile.data.tables)[0];
  const value = code ?? `SELECT *\nFROM "${table}"\nLIMIT 50;`;
  return (
    <>
      <Journey datasetId={id} />
      <div className="eyebrow mb-3">{dataset.data.name} / SQL workspace</div>
      <h1 className="page-title">Ask your data. Get the evidence.</h1>
      <p className="subtle mt-3">
        Write SQL against your raw or cleaned tables. Every query is validated
        before it runs.
      </p>
      <div className="flex gap-2 items-center bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-primary rounded-lg p-3 text-xs my-6">
        <ShieldCheck size={16} />
        Read-only workspace · External access blocked · Results capped ·
        Execution timeout enforced
      </div>
      <div className="grid lg:grid-cols-[1fr_250px] gap-5">
        <div className="min-w-0">
          <section className="panel overflow-hidden">
            <div className="border-b px-5 py-3 flex items-center justify-between">
              <span className="text-sm font-semibold flex gap-2 items-center">
                <Terminal size={16} />
                Query editor
              </span>
              <span className="text-xs text-muted-foreground">DuckDB SQL</span>
            </div>
            <CodeMirror
              value={value}
              height="260px"
              extensions={[sql()]}
              onChange={setCode}
              theme="light"
              aria-label="SQL query editor"
            />
            <div className="border-t p-4 flex justify-between items-center">
              <span className="subtle text-xs">
                A single SELECT, including CTEs and joins.
              </span>
              <Button
                disabled={query.isPending || !value.trim()}
                onClick={() => query.mutate(value)}
              >
                <Play size={14} />
                {query.isPending ? "Running…" : "Run query"}
              </Button>
            </div>
          </section>
          <div className="mt-5">
            {query.error && <ErrorBox error={query.error} />}
            {query.data?.run.error && (
              <ErrorBox
                error={
                  new Error(
                    `${query.data.run.status === "validation_error" ? "SQL guard blocked this query" : "Query execution failed"}\n${query.data.run.error}`,
                  )
                }
              />
            )}
            {query.isPending && <Loading />}
            {!query.isPending && query.data?.result && (
              <section className="panel">
                <div className="p-5 border-b flex justify-between">
                  <h2 className="font-semibold">Query results</h2>
                  <span className="subtle">
                    {query.data.result.row_count.toLocaleString()} rows ·{" "}
                    {query.data.run.elapsed_ms.toFixed(0)} ms
                  </span>
                </div>
                <DataTable
                  columns={query.data.result.columns}
                  rows={query.data.result.rows}
                />
                {query.data.result.truncated && (
                  <p className="p-4 text-sm text-amber-700">
                    Result limit reached. Add filters or a smaller LIMIT to
                    refine your query.
                  </p>
                )}
              </section>
            )}
            {!query.data && !query.isPending && (
              <div className="panel p-12 text-center">
                <Terminal
                  size={24}
                  className="mx-auto text-muted-foreground mb-3"
                />
                <p className="subtle">Your query results will appear here.</p>
              </div>
            )}
          </div>
        </div>
        <aside className="panel p-5 h-fit">
          <h2 className="eyebrow mb-4">Available tables</h2>
          {dataset.data.table_names.map((t) => (
            <details key={t} className="mb-3 text-xs">
              <summary className="cursor-pointer font-mono break-all">
                {t}
              </summary>
              <div className="mt-3 space-y-2 text-muted-foreground">
                {profile.data!.tables[t]?.schema.map((c) => (
                  <p key={c.name} className="flex justify-between gap-2">
                    <span>{c.name}</span>
                    <span className="text-[9px]">{c.type}</span>
                  </p>
                )) || (
                  <p>
                    Original source columns. Preview raw data on the health
                    page.
                  </p>
                )}
              </div>
            </details>
          ))}
        </aside>
      </div>
      <section className="mt-8">
        <h2 className="font-semibold mb-4 flex gap-2 items-center">
          <Clock size={17} />
          Recent queries
        </h2>
        {history.isLoading ? (
          <Loading />
        ) : history.error ? (
          <ErrorBox error={history.error} retry={() => history.refetch()} />
        ) : (
          <div className="panel divide-y">
            {!history.data?.length && (
              <p className="p-6 subtle">
                Run a query to begin your audit trail.
              </p>
            )}
            {history.data?.map((run) => (
              <button
                className="text-left w-full p-4 flex gap-4 items-center hover:bg-muted/50"
                key={run.id}
                onClick={() => setCode(run.sql)}
              >
                <span
                  className={`text-xs rounded px-2 py-1 ${run.status === "ok" ? "text-primary bg-emerald-50" : "text-red-700 bg-red-50"}`}
                >
                  {run.status}
                </span>
                <code className="text-xs flex-1 truncate">{run.sql}</code>
                <span className="subtle text-xs">
                  {run.elapsed_ms.toFixed(0)} ms
                </span>
              </button>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
