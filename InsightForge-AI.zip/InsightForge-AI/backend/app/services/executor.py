"""Isolated, resource-bounded execution. All callers pass through the same guard."""

import multiprocessing as mp
import time

import duckdb

from app.services.profiling import json_records
from app.services.sql_guard import validate_sql

STARTUP_SECONDS = 30


def _worker(path, sql, limit, pipe, ready=None):
    try:
        with duckdb.connect(
            path,
            read_only=True,
            config={
                "enable_external_access": "false",
                "autoinstall_known_extensions": "false",
                "autoload_known_extensions": "false",
                "memory_limit": "256MB",
                "threads": "1",
                "max_temp_directory_size": "0B",
                "lock_configuration": "true",
            },
        ) as conn:
            if ready is not None:
                ready.set()
            cursor = conn.execute(sql)
            columns = [d[0] for d in cursor.description]
            # Fetch at most limit+1; never materialize an unbounded result in the API process.
            import pandas as pd

            rows = cursor.fetchmany(limit + 1)
            frame = pd.DataFrame(rows[:limit], columns=columns)
            pipe.send(
                {
                    "columns": columns,
                    "column_types": [str(d[1]) for d in cursor.description],
                    "rows": json_records(frame),
                    "truncated": len(rows) > limit,
                    "row_count": min(len(rows), limit),
                }
            )
    except Exception as exc:
        pipe.send({"error": str(exc)[:2000]})
    finally:
        pipe.close()


def execute(path, sql, tables, timeout=5, limit=1000, cancel=None):
    validated = validate_sql(sql, tables)
    if cancel is not None and cancel.is_set():
        raise InterruptedError("Analysis cancelled.")
    start = time.perf_counter()
    context = mp.get_context("spawn")
    parent, child = context.Pipe(duplex=False)
    ready = context.Event()
    process = context.Process(
        target=_worker, args=(path, validated, limit, child, ready), daemon=True
    )
    process.start()
    child.close()
    # Interpreter start-up is not query time: the query deadline starts once the worker has
    # connected; start-up itself has a separate, larger bound so a stuck spawn still fails.
    startup_limit = max(STARTUP_SECONDS, timeout)
    query_start = None
    try:
        while not parent.poll(0.05):
            if cancel is not None and cancel.is_set():
                raise InterruptedError("Analysis cancelled.")
            now = time.perf_counter()
            if query_start is None and ready.is_set():
                query_start = now
            if query_start is None and now - start >= startup_limit:
                raise TimeoutError(f"Query worker did not start within {startup_limit:g} seconds.")
            if query_start is not None and now - query_start >= timeout:
                raise TimeoutError(f"Query exceeded the {timeout:g}-second execution limit.")
        try:
            result = parent.recv()
        except EOFError as exc:
            raise RuntimeError("Query worker stopped unexpectedly.") from exc
        if "error" in result:
            raise RuntimeError(result["error"])
        result["elapsed_ms"] = round((time.perf_counter() - start) * 1000, 2)
        return result
    finally:
        if process.is_alive():
            process.terminate()
        process.join(timeout=1)
        if process.is_alive():
            process.kill()
            process.join()
        parent.close()
