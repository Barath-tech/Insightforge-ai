"""Redact secrets and sensitive data from both sides of model audit records."""

import re

from app.core.config import settings


def sanitize(text):
    text = re.sub(r"\x1b\[[0-9;]*m", "", str(text))
    if settings.openai_api_key:
        text = text.replace(settings.openai_api_key, "[REDACTED]")
    text = re.sub(r"sk-[\w-]+", "[REDACTED]", text)
    text = re.sub(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", "[EMAIL]", text)
    text = re.sub(r"(?:/home/|/tmp/|[A-Z]:\\)[^\s\"']+", "[PATH]", text)
    return text[:10000]


def redact(value, key=""):
    if any(word in key.lower() for word in ("api_key", "password", "secret", "authorization")):
        return "[REDACTED]"
    if key in {"samples", "rows", "question"}:
        return {"redacted": True, "size": len(value) if hasattr(value, "__len__") else None}
    if isinstance(value, dict) and value.get("unit") == "identifier":
        value = {**value, "value": "[IDENTIFIER]"}
    if isinstance(value, dict):
        return {k: redact(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v) for v in value[:30]]
    if isinstance(value, str):
        return sanitize(value)
    return value
