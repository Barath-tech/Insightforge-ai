def check_result(result, proposal, plan):
    if not result["rows"]:
        return ["No matching rows. Preserve filters; confirm insufficient evidence."]
    problems = []
    if len(set(result["columns"])) != len(result["columns"]):
        problems.append("Duplicate output names; use unique metric aliases for cell provenance.")
    inferred = [
        col
        for col, dtype in zip(result["columns"], result.get("column_types", []))
        if any(t in dtype for t in ("INT", "DOUBLE", "FLOAT", "DECIMAL"))
    ]
    for col in set(proposal.measure_columns) | set(inferred):
        if col not in result["columns"]:
            problems.append(f"Expected measure column absent: {col}")
        elif all(r.get(col) is None for r in result["rows"]):
            problems.append(f"All-null measure: {col}")
    allowed = {m.name for m in plan.metrics if m.nonnegative}
    for col in proposal.nonnegative_columns:
        if col in allowed and any(
            isinstance(r.get(col), (int, float)) and r[col] < 0 for r in result["rows"]
        ):
            problems.append(f"Negative value for explicitly nonnegative metric: {col}")
    return problems


def preserve_filters(original, corrected):
    """Conservative correction policy: retain existing WHERE/HAVING predicates.

    Repairs may fix SELECT expressions or add constraints. Changing a filter
    requires a new analysis, rather than silently broadening the population.
    """
    import sqlglot
    from sqlglot import exp

    from app.services.sql_guard import SQLValidationError

    def predicates(sql):
        tree = sqlglot.parse_one(sql, read="duckdb")
        parts = set()
        for clause in tree.find_all(exp.Where, exp.Having):

            def visit(node):
                if isinstance(node, exp.And):
                    visit(node.left)
                    visit(node.right)
                else:
                    parts.add(node.sql(dialect="duckdb"))

            visit(clause.this)
        return parts

    try:
        required, current = predicates(original), predicates(corrected)
    except sqlglot.errors.SqlglotError:
        return  # Syntax repair remains governed by the guard.
    if not required <= current:
        raise SQLValidationError(
            "Correction changed or removed an existing filter; intent must remain."
        )
