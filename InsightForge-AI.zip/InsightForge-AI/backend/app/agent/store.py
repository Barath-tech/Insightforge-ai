from sqlmodel import Session, select

from app.models.analysis import Analysis, AnalysisStep, LLMCall
from app.models.metadata import QueryRun, now


def save(engine, value):
    with Session(engine) as session:
        session.add(value)
        session.commit()
        session.refresh(value)
    return value


def update(engine, identifier, **changes):
    with Session(engine) as session:
        analysis = session.get(Analysis, identifier)
        for key, value in changes.items():
            setattr(analysis, key, value)
        analysis.updated_at = now()
        if analysis.status in {"completed", "failed", "cancelled"}:
            analysis.completed_at = now()
        session.add(analysis)
        session.commit()


def challenge_children(session, dataset_id):
    """Map each Challenge test analysis to the finding it challenged (dataset-scoped)."""
    from app.models.final import Challenge

    parents = session.exec(
        select(Challenge)
        .join(Analysis, Analysis.id == Challenge.analysis_id)
        .where(Analysis.dataset_id == dataset_id)
    ).all()
    return {
        h["analysis_id"]: c.analysis_id
        for c in parents
        for h in (c.result_json or {}).get("hypotheses", [])
        if h.get("analysis_id")
    }


def detail(engine, identifier):
    with Session(engine) as session:
        analysis = session.get(Analysis, identifier)
        if analysis is None:
            return None
        steps = session.exec(
            select(AnalysisStep)
            .where(AnalysisStep.analysis_id == identifier)
            .order_by(AnalysisStep.created_at)
        ).all()
        return {
            **analysis.model_dump(mode="json"),
            "steps": [s.model_dump(mode="json") for s in steps],
        }


def recover(engine):
    """Single-process restart policy: interrupted work is never replayed or billed again."""
    from app.models.final import Challenge

    with Session(engine) as session:
        for c in session.exec(select(Challenge).where(Challenge.status == "running")):
            c.status = "cancelled"
            session.add(c)
        for analysis in session.exec(
            select(Analysis).where(Analysis.status.in_(["pending", "running"]))
        ):
            analysis.status = "cancelled"
            analysis.error = "Server restarted; interrupted analysis was cancelled."
            analysis.updated_at = analysis.completed_at = now()
            session.add(analysis)
        for model in (AnalysisStep, QueryRun, LLMCall):
            for row in session.exec(select(model).where(model.status == "running")):
                row.status, row.error = "cancelled", "Server interrupted this operation."
                session.add(row)
        session.commit()
