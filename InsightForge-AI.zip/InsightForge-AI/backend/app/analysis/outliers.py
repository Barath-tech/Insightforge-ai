"""Robust statistics; undefined ratios and zero-MAD scores are never invented."""

import re

import numpy as np

from app.analysis.charts import numeric

METHOD_NAMES = {"robust_z": "robust z", "iqr": "IQR", "rolling_baseline": "trailing baseline"}
BASELINE_NAMES = {"robust_z": "median", "iqr": "median", "rolling_baseline": "trailing mean"}
MIDNIGHT = re.compile(r"^(\d{4}-\d{2}-\d{2})[T ]00:00:00(?:\.0+)?(?:Z|[+-]00:?00)?$")


def display_label(value):
    text = str(value)
    match = MIDNIGHT.match(text)
    return match[1] if match else text


def callout(key, column, value, detection, score, methods):
    baseline, delta = detection["baseline"], detection["deviation_pct"]
    name = BASELINE_NAMES[detection["method"]]
    text = f"{key}: {column} is {value:,.3f}"
    text += (
        f" ({delta:+.1f}% vs {name} {baseline:,.3f})"
        if delta is not None
        else f" ({name} {baseline:,.3f}; percentage undefined)"
    )
    if score is not None:
        text += f"; robust z = {score:.2f}"
    return text + "; detected by " + ", ".join(METHOD_NAMES[m] for m in methods)


def detect_outliers(result, x=None, labels=None):
    """One consolidated callout per flagged cell; every detection method is retained."""
    rows = result.get("rows", [])
    found = []
    for col in result.get("columns", []):
        pairs = [(i, r[col]) for i, r in enumerate(rows) if numeric(r.get(col))]
        if len(pairs) < 4 or col == x:
            continue
        values = np.array([v for _, v in pairs], dtype=float)
        median = float(np.median(values))
        mad = float(np.median(np.abs(values - median)))
        q1, q3 = np.percentile(values, [25, 75])
        iqr = float(q3 - q1)
        for position, (index, value) in enumerate(pairs):
            z = 0.67448975 * (value - median) / mad if mad else None
            detections = []
            if z is not None and abs(z) > 3.5:
                detections.append(("robust_z", median))
            if value < q1 - 1.5 * iqr or value > q3 + 1.5 * iqr:
                detections.append(("iqr", median))
            if x and position >= 3:
                prior = values[max(0, position - 9) : position]
                baseline = float(np.mean(prior))
                variation = float(np.std(prior))
                if abs(value - baseline) > max(3 * variation, abs(baseline) * 0.10, 1e-9):
                    detections.append(("rolling_baseline", baseline))
            if not detections:
                continue
            detections = [
                {
                    "method": method,
                    "baseline": baseline,
                    "deviation_pct": 100 * (value - baseline) / abs(baseline) if baseline else None,
                }
                for method, baseline in detections
            ]
            # Time series compare against their own trailing history when available.
            primary = next(
                (d for d in detections if d["method"] == "rolling_baseline"), detections[0]
            )
            methods = [d["method"] for d in detections]
            if labels is not None:
                key = labels[index]
            else:
                key = display_label(rows[index].get(x, index)) if x else str(index)
            found.append(
                dict(
                    row_key=key,
                    row_index=index,
                    column=col,
                    value=value,
                    baseline=primary["baseline"],
                    deviation_pct=primary["deviation_pct"],
                    method=primary["method"],
                    methods=methods,
                    detections=detections,
                    robust_z=z,
                    severity="high" if z and abs(z) > 5 else "medium",
                    callout=callout(key, col, value, primary, z, methods),
                )
            )
    return found


def row_labels(chart):
    rows = chart["rows"]
    if chart["x"] and chart["type"] != "scatter":
        return [display_label(r.get(chart["x"])) for r in rows]
    # Scatter x values are measures; identify points by their descriptive columns instead.
    labels = []
    for i, row in enumerate(rows):
        parts = [
            display_label(v)
            for k, v in row.items()
            if v is not None and not numeric(v) and k not in chart["y"]
        ]
        labels.append(" · ".join(parts) or f"row {i + 1}")
    return labels


def enrich_chart(result, chart):
    ordered = {**result, "rows": chart["rows"]}
    date_x = chart["x"] if chart["type"] == "line" else None
    # Highlights refer to positions in the chart's display order.
    outliers = detect_outliers(ordered, date_x, row_labels(chart))
    chart["highlights"] = outliers
    return outliers
