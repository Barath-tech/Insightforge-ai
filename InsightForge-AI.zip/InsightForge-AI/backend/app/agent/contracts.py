"""Public, observable plans and evidence; never private chain-of-thought."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Contract(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Metric(Contract):
    name: str
    definition: str
    unit: str
    nonnegative: bool


class Filter(Contract):
    column: str
    operator: str
    value: str


class PlanStep(Contract):
    id: str = Field(pattern=r"^[a-zA-Z][a-zA-Z0-9_]{0,39}$")
    purpose: str = Field(max_length=600)
    expected_output: str = Field(max_length=600)
    depends_on: list[str] = Field(max_length=5)


class Plan(Contract):
    intent: Literal["lookup", "trend", "comparison", "why", "distribution", "correlation"]
    answerable: bool
    explanation: str
    metrics: list[Metric] = Field(max_length=12)
    dimensions: list[str] = Field(max_length=12)
    filters: list[Filter] = Field(max_length=12)
    time_range: str
    steps: list[PlanStep] = Field(max_length=5)
    assumptions: list[str] = Field(max_length=12)

    @model_validator(mode="after")
    def ordered_steps(self):
        seen = set()
        for step in self.steps:
            if step.id in seen or not set(step.depends_on) <= seen:
                raise ValueError("Step IDs must be unique; dependencies must precede the step")
            seen.add(step.id)
        if self.answerable and not self.steps:
            raise ValueError("An answerable plan needs steps")
        return self


class SQLProposal(Contract):
    sql: str = Field(min_length=1, max_length=20000)
    rationale: str = Field(max_length=1000)
    measure_columns: list[str] = Field(max_length=20)
    nonnegative_columns: list[str] = Field(max_length=20)
    no_matching_data: bool


class KeyNumber(Contract):
    label: str
    value: str
    unit: Literal["number", "GBP", "USD", "EUR", "percent", "date", "identifier", "text"]
    source_step_id: str
    source_attempt: int = Field(ge=1, le=3)
    column: str
    row_index: int = Field(ge=0)
    conversion: Literal["identity", "fraction_to_percent"]
    decimals: int = Field(ge=0, le=6)


class Finding(Contract):
    # Numeric claims use {{n0}}, {{n1}} placeholders, resolved by the server.
    headline: str = Field(max_length=500)
    answer: str = Field(max_length=4000)
    key_numbers: list[KeyNumber] = Field(max_length=24)
    caveats: list[str] = Field(max_length=12)


class NarrativeClaim(Contract):
    fact_id: str
    label: str
    value: str


class Narrative(Contract):
    introduction: str = Field(max_length=500)
    claims: list[NarrativeClaim] = Field(max_length=16)


class Suggestion(Contract):
    question: str = Field(min_length=8, max_length=300)
    table: str
    columns: list[str] = Field(max_length=10)


class Suggestions(Contract):
    questions: list[Suggestion] = Field(min_length=5, max_length=5)
