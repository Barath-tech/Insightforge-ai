"""Start, reuse, or stop local replay services and optionally execute the scripted demo.

Usage: ``python -m scripts.demo [start|stop]``. Only processes recorded in ``work/*.pid``
by this launcher are ever stopped, and only after their command line is re-verified.
"""

import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import httpx
from app.llm.replay import FIXTURE_MODEL

from scripts.demo_responses import QUESTION
from scripts.generate_uk_retail import write

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
BACKEND = "http://localhost:8000"
FRONTEND = "http://localhost:3000"
FRONTEND_MARKER = "InsightForge AI"
# Substrings that must appear in an owned process's command line before it is signalled.
MARKERS = {"backend": ("uvicorn", "app.main:app"), "frontend": ("run", "dev")}
DIRECTORIES = {"backend": ROOT, "frontend": ROOT / "frontend"}


def command_line(pid):
    proc = Path(f"/proc/{pid}/cmdline")
    if proc.exists():
        return proc.read_bytes().replace(b"\0", b" ").decode(errors="replace")
    result = subprocess.run(
        ["ps", "-o", "command=", "-p", str(pid)], capture_output=True, text=True
    )
    return result.stdout.strip()


def alive(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def owned(name):
    """Return the recorded PID if it is alive and still the process this launcher started."""
    path = WORK / f"{name}.pid"
    if not path.exists():
        return None
    try:
        record = json.loads(path.read_text())
        pid = int(record["pid"])
    except (ValueError, KeyError, TypeError):
        # Legacy plain-PID files carry no identity record; never signal them blindly.
        path.unlink()
        return None
    commandline = command_line(pid) if alive(pid) else ""
    if not commandline or not all(m in commandline for m in MARKERS[name]):
        path.unlink()
        return None
    cwd = Path(f"/proc/{pid}/cwd")
    if cwd.exists() and cwd.resolve() != DIRECTORIES[name].resolve():
        path.unlink()
        return None
    return pid


def backend_ready(client, mode):
    try:
        health = client.get(BACKEND + "/api/health", timeout=2).json()
    except (httpx.HTTPError, ValueError):
        return False
    if health.get("phase") != 4:
        raise RuntimeError("Port 8000 belongs to an older app. Stop it before make demo.")
    if health.get("demo_replay") != mode:
        raise RuntimeError(
            f"The backend on port 8000 runs with DEMO_REPLAY={health.get('demo_replay')}, "
            f"not {mode}. Run `make demo-stop` (or stop that server) and retry."
        )
    return True


def frontend_ready(client, starting=False):
    try:
        response = client.get(FRONTEND, timeout=30 if starting else 5)
    except httpx.HTTPError:
        return False
    if starting and response.status_code != 200:
        return False  # Still compiling or recovering from a transient development error.
    if response.status_code != 200 or FRONTEND_MARKER not in response.text:
        raise RuntimeError("Port 3000 is serving another application. Stop it and retry.")
    return True


def launch(name, args, cwd, env):
    WORK.mkdir(exist_ok=True)
    with (WORK / f"{name}.log").open("ab") as output:
        process = subprocess.Popen(
            args,
            cwd=cwd,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    (WORK / f"{name}.pid").write_text(
        json.dumps({"pid": process.pid, "pgid": process.pid, "command": args})
    )
    return process


def wait_until(name, ready, process, seconds):
    for _ in range(seconds):
        if ready():
            return
        if process is not None and process.poll() is not None:
            raise RuntimeError(f"The {name} exited early; see work/{name}.log")
        time.sleep(1)
    raise RuntimeError(f"The {name} did not become ready; see work/{name}.log")


def start():
    write(ROOT / "data")
    mode = os.environ.get("DEMO_REPLAY", "replay")
    env = {
        **os.environ,
        "DEMO_REPLAY": mode,
        "PATH": str(WORK / "bin") + os.pathsep + os.environ["PATH"],
        "NEXT_TELEMETRY_DISABLED": "1",
    }
    if mode == "replay":
        # Fixtures are keyed by their model; override a live gateway/model set in .env.
        env.setdefault("OPENAI_MODEL", FIXTURE_MODEL)
        env.setdefault("OPENAI_BASE_URL", "")
    probe = httpx.Client()
    backend = None
    if backend_ready(probe, mode):
        print("Reusing the InsightForge backend on port 8000.", flush=True)
    else:
        args = [sys.executable, "-m", "uvicorn", "app.main:app", "--app-dir", "backend"]
        args += ["--host", "127.0.0.1", "--port", "8000"]
        backend = launch("backend", args, ROOT, env)
    wait_until("backend", lambda: backend_ready(probe, mode), backend, 90)
    frontend = None
    if frontend_ready(probe):
        print("Reusing the InsightForge frontend on port 3000.", flush=True)
    else:
        frontend = launch("frontend", ["npm", "run", "dev"], ROOT / "frontend", env)
    with httpx.Client(base_url=BACKEND, timeout=180) as client:
        d = client.post("/api/datasets/demo")
        d.raise_for_status()
        dataset = d.json()["id"]
        if os.environ.get("DEMO_FULL_FLOW", "1") != "0":
            brief = full_flow(client, dataset)
    # The first Next.js development compile can be slow; print URLs only once it serves.
    wait_until("frontend", lambda: frontend_ready(probe, starting=True), frontend, 240)
    probe.close()
    print(f"Data Health: {FRONTEND}/datasets/{dataset}", flush=True)
    if os.environ.get("DEMO_FULL_FLOW", "1") != "0":
        print(f"Executive brief: {FRONTEND}/briefs/{brief}")
    print(f"Workspace: {FRONTEND}/datasets/{dataset}/ask\nAudit: {FRONTEND}/audit", flush=True)
    print("Stop launcher-owned services with: make demo-stop", flush=True)


def full_flow(client, dataset):
    client.post(f"/api/datasets/{dataset}/narrative").raise_for_status()
    identifier = None
    with client.stream("POST", f"/api/datasets/{dataset}/ask", json={"question": QUESTION}) as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if line.startswith("data: "):
                event = json.loads(line[6:])
                identifier = event["analysis_id"]
                print(event["type"], flush=True)
                if event["type"] == "error":
                    raise RuntimeError(event["payload"])
    client.patch(f"/api/analyses/{identifier}/pin", json={"pinned": True}).raise_for_status()
    with client.stream("POST", f"/api/analyses/{identifier}/challenge") as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if line.startswith("data: "):
                event = json.loads(line[6:])
                if event["type"] == "error":
                    raise RuntimeError(event["payload"])
                if event["type"] == "challenge":
                    client.patch(
                        f"/api/challenges/{event['payload']['id']}/pin",
                        json={"pinned": True},
                    ).raise_for_status()
    b = client.post(f"/api/datasets/{dataset}/briefs", json={})
    b.raise_for_status()
    return b.json()["id"]


def stop():
    stopped = False
    for name in ["frontend", "backend"]:
        pid = owned(name)
        if pid is None:
            print(f"No launcher-owned {name} is running.")
            continue
        # The launcher started each service in its own session, so its group is its PID.
        for sig, grace in [(signal.SIGTERM, 10), (signal.SIGKILL, 2)]:
            try:
                os.killpg(pid, sig)
            except ProcessLookupError:
                break
            for _ in range(grace * 10):
                if not alive(pid):
                    break
                time.sleep(0.1)
            if not alive(pid):
                break
        (WORK / f"{name}.pid").unlink(missing_ok=True)
        print(f"Stopped {name} (process group {pid}).")
        stopped = True
    return stopped


if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "start"
    if action not in {"start", "stop"}:
        sys.exit("Usage: python -m scripts.demo [start|stop]")
    stop() if action == "stop" else start()
