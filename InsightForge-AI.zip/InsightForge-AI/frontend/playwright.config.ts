import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./e2e",
  // First-visit dev compiles of every route dominate on small CI runners.
  timeout: 300000,
  workers: 1,
  use: {
    baseURL: "http://localhost:3100",
    viewport: { width: 1440, height: 1000 },
    trace: "retain-on-failure",
    launchOptions: {
      executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,
      args: ["--no-sandbox"],
    },
  },
  webServer: [
    {
      command:
        "../.venv/bin/python -m uvicorn app.main:app --app-dir ../backend --host 127.0.0.1 --port 8100",
      url: "http://localhost:8100/api/health",
      env: {
        DEMO_REPLAY: "replay",
        OPENAI_MODEL: "gpt-4.1",
        OPENAI_BASE_URL: "",
        CORS_ORIGINS: '["http://localhost:3100"]',
        ASK_PER_MINUTE: "60",
      },
      timeout: 30000,
      reuseExistingServer: false,
    },
    {
      command: "npm run dev -- --port 3100",
      url: "http://localhost:3100",
      env: {
        NEXT_PUBLIC_API_URL: "http://localhost:8100",
        NEXT_TELEMETRY_DISABLED: "1",
        NEXT_DIST_DIR: ".next-e2e",
      },
      timeout: 120000,
      reuseExistingServer: false,
    },
  ],
});
