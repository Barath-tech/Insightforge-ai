"use client";
import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ArrowRight,
  Database,
  FileSpreadsheet,
  ShieldCheck,
  Sparkles,
  UploadCloud,
} from "lucide-react";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { ErrorBox, Loading } from "@/components/shared";
export default function Home() {
  const [sample, setSample] = useState("messy");
  const router = useRouter(),
    client = useQueryClient(),
    input = useRef<HTMLInputElement>(null);
  const [progress, setProgress] = useState(0),
    [drag, setDrag] = useState(false);
  const list = useQuery({ queryKey: ["datasets"], queryFn: api.list });
  const upload = useMutation({
    mutationFn: (file: File) => {
      setProgress(0);
      return api.upload(file, setProgress);
    },
    onSuccess: (d) => {
      client.invalidateQueries({ queryKey: ["datasets"] });
      router.push(`/datasets/${d.id}`);
    },
  });
  const demo = useMutation({
    mutationFn: () => api.demo(sample),
    onSuccess: (d) => {
      client.invalidateQueries({ queryKey: ["datasets"] });
      router.push(`/datasets/${d.id}`);
    },
  });
  const busy = upload.isPending || demo.isPending;
  const latest = list.data?.[0];
  const steps = [
    ["Load data", "Upload a CSV/SQLite file or load the demo."],
    ["Inspect health", "Review quality issues and the cleaning log."],
    ["Ask", "Ask a question; SQL runs and every number is cited."],
    ["Challenge", "Test alternative explanations."],
    ["Brief", "Pin evidence and generate a one-page brief."],
  ];
  return (
    <>
      <section className="panel p-5 mb-6" aria-labelledby="how-it-works">
        <h2 id="how-it-works" className="eyebrow mb-3">
          How it works
        </h2>
        <ol className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {steps.map(([title, text], i) => (
            <li key={title} className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-xs font-semibold">
                {i + 1}
              </span>
              <span>
                <strong className="text-sm block">{title}</strong>
                <span className="subtle text-xs">{text}</span>
              </span>
            </li>
          ))}
        </ol>
        <p className="subtle text-xs mt-3">
          Offline replay mode supports the scripted demo question
          (“Why did profit margin decline in London in October?”). SQL always
          executes against your data.
        </p>
      </section>
      {latest && (
        <Link
          href={`/datasets/${latest.id}/ask`}
          className="panel p-4 mb-6 flex items-center gap-3 hover:bg-muted/50"
        >
          <Sparkles size={18} className="text-primary shrink-0" />
          <span className="flex-1 min-w-0">
            <span className="text-sm font-semibold block">
              Continue where you left off
            </span>
            <span className="subtle text-xs truncate block">
              {latest.name} · loaded{" "}
              {new Date(latest.created_at).toLocaleString(undefined, {
                dateStyle: "medium",
                timeStyle: "short",
              })}
            </span>
          </span>
          <ArrowRight size={16} />
        </Link>
      )}
      <div className="eyebrow mb-3">From raw data to clarity</div>
      <h1 className="page-title">Good decisions start with trusted data.</h1>
      <p className="text-muted-foreground mt-4 max-w-2xl leading-relaxed">
        Bring your business data into focus. Inspect quality, explore your
        schema, and find answers with a secure SQL workspace.
      </p>
      <div className="grid lg:grid-cols-[1.5fr_1fr] gap-6 mt-9">
        <section
          className={`panel p-8 border-dashed border-2 text-center flex flex-col justify-center items-center min-h-[300px] ${drag ? "border-primary bg-emerald-50" : ""}`}
          onDragOver={(e) => {
            e.preventDefault();
            setDrag(true);
          }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDrag(false);
            if (!busy && e.dataTransfer.files[0])
              upload.mutate(e.dataTransfer.files[0]);
          }}
        >
          <div className="rounded-2xl bg-emerald-50 dark:bg-emerald-950 text-primary p-4 mb-5">
            <UploadCloud size={30} />
          </div>
          <h2 className="font-semibold text-xl">
            Give your data a fresh start
          </h2>
          <p className="subtle mt-2">
            Drop a CSV or SQLite file here, or browse your files.
          </p>
          <input
            ref={input}
            type="file"
            accept=".csv,.sqlite,.db"
            className="hidden"
            aria-label="Upload dataset"
            onChange={(e) => {
              if (e.target.files?.[0]) upload.mutate(e.target.files[0]);
              e.target.value = "";
            }}
          />
          <Button
            className="mt-5"
            disabled={busy}
            onClick={() => input.current?.click()}
          >
            <UploadCloud size={16} />
            {upload.isPending ? "Processing dataset…" : "Choose a file"}
          </Button>
          <p className="text-xs text-muted-foreground mt-4">
            CSV, SQLITE, DB · 50 MB default limit
          </p>
          {upload.isPending && (
            <div className="w-full mt-5">
              <progress
                className="w-full accent-emerald-600"
                max={100}
                value={progress}
              />
              <p className="subtle">
                {progress === 100
                  ? "Inspecting schema and profiling columns…"
                  : `Uploading ${progress}%`}
              </p>
            </div>
          )}
        </section>
        <section className="rounded-xl bg-[#173d32] p-8 text-white flex flex-col">
          <div className="text-xs uppercase tracking-[.15em] text-emerald-200 flex gap-2 items-center">
            <Sparkles size={15} />
            Explore the demo
          </div>
          <h2 className="text-2xl font-semibold mt-5">
            A year of UK retail.
            <br />A few hidden problems.
          </h2>
          <p className="text-emerald-100/70 text-sm leading-relaxed mt-4">
            Realistic orders across 12 cities. Discover messy dates, duplicate
            records, and gaps in delivery data.
          </p>
          <label className="text-xs mt-4">
            Demo source
            <select
              aria-label="Demo source"
              className="block border rounded p-2 my-2 text-slate-900 bg-white"
              value={sample}
              onChange={(e) => setSample(e.target.value)}
            >
              <option value="messy">Messy CSV</option>
              <option value="clean">Clean CSV fallback</option>
              <option value="sqlite">SQLite fallback</option>
            </select>
          </label>
          <Button
            variant="outline"
            className="mt-auto pt-2 bg-white text-[#173d32] border-white hover:bg-emerald-50 w-fit"
            disabled={busy}
            onClick={() => demo.mutate()}
          >
            {demo.isPending
              ? "Building your data profile…"
              : "Load demo dataset"}
            <ArrowRight size={16} />
          </Button>
        </section>
      </div>
      {(upload.error || demo.error) && (
        <div className="mt-4">
          <ErrorBox error={upload.error || demo.error} />
        </div>
      )}
      <div className="grid sm:grid-cols-3 gap-6 my-8">
        {[
          {
            icon: FileSpreadsheet,
            title: "Keep the original",
            text: "Raw and cleaned tables, side by side.",
          },
          {
            icon: ShieldCheck,
            title: "Know what changed",
            text: "A transparent log for every cleaning step.",
          },
          {
            icon: Database,
            title: "Query with confidence",
            text: "Read-only SQL with built-in safeguards.",
          },
        ].map(({ icon: Icon, title, text }) => (
          <div key={title} className="flex gap-3">
            <Icon size={19} className="text-primary mt-1 shrink-0" />
            <div>
              <h3 className="text-sm font-semibold">{title}</h3>
              <p className="text-xs text-muted-foreground mt-1">{text}</p>
            </div>
          </div>
        ))}
      </div>
      <section className="mt-10">
        <div className="flex justify-between items-center mb-5">
          <h2 className="font-semibold text-xl">Your data library</h2>
          <span className="subtle">{list.data?.length ?? 0} datasets</span>
        </div>
        {list.isLoading ? (
          <Loading />
        ) : list.error ? (
          <ErrorBox error={list.error} retry={() => list.refetch()} />
        ) : !list.data?.length ? (
          <div className="panel p-10 text-center subtle">
            Your workspace is ready. Upload a file or load the demo to get
            started.
          </div>
        ) : (
          <div className="panel divide-y">
            {list.data.map((d, i) => (
              <Link
                key={d.id}
                href={`/datasets/${d.id}`}
                className="flex gap-4 items-center p-5 hover:bg-muted/50"
              >
                <div className="rounded-lg bg-muted p-3">
                  <Database size={20} />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-semibold truncate">{d.name}</h3>
                  <p className="subtle mt-1">
                    {d.row_count.toLocaleString()} rows ·{" "}
                    {d.source_type.toUpperCase()} · {d.original_filename} ·{" "}
                    {new Date(d.created_at).toLocaleString(undefined, {
                      dateStyle: "medium",
                      timeStyle: "short",
                    })}
                  </p>
                </div>
                {i === 0 && (
                  <span className="text-xs text-white bg-primary rounded-full px-3 py-1">
                    Most recent
                  </span>
                )}
                <span className="text-xs text-primary border rounded-full px-3 py-1">
                  Ready
                </span>
                <ArrowRight size={16} />
              </Link>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
