#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
trap 'kill ${BACKEND_PID:-} ${FRONTEND_PID:-} 2>/dev/null || true' EXIT INT TERM
.venv/bin/python -m uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8000 --reload --reload-dir backend &
BACKEND_PID=$!
(cd frontend && ${NPM:-npm} run dev) &
FRONTEND_PID=$!
wait -n "$BACKEND_PID" "$FRONTEND_PID"
