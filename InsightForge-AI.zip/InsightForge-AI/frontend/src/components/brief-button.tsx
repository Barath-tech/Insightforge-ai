"use client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { briefApi } from "@/lib/api";
import { useProgress } from "./journey";
import { Button } from "./ui/button";
import { ErrorBox } from "./shared";
export function BriefButton({ datasetId }: { datasetId: string }) {
  const router = useRouter(),
    cache = useQueryClient();
  const progress = useProgress(datasetId);
  const findings = progress.data?.pinned_findings ?? 0,
    challenges = progress.data?.pinned_challenges ?? 0;
  const create = useMutation({
    mutationFn: () => briefApi.create(datasetId),
    onSuccess: (b) => {
      void cache.invalidateQueries({ queryKey: ["progress", datasetId] });
      router.push(`/briefs/${b.id}`);
    },
  });
  return (
    <div className="mt-4 flex flex-wrap items-center gap-3" id="brief">
      <Button
        disabled={create.isPending || !findings}
        aria-describedby="brief-help"
        onClick={() => create.mutate()}
      >
        {create.isPending
          ? "Preparing executive brief…"
          : "Generate Executive Brief"}
      </Button>
      <span id="brief-help" className="subtle text-xs">
        {!progress.data
          ? "Checking pinned evidence…"
          : findings
            ? `${findings} finding${findings === 1 ? "" : "s"} and ${challenges} challenge${challenges === 1 ? "" : "s"} pinned.`
            : "Pin at least one finding to enable the brief."}
      </span>
      {create.error && <ErrorBox error={create.error} />}
    </div>
  );
}