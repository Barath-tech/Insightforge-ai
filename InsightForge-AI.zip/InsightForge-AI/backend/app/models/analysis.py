"""Additive Phase 2 tables: existing Phase 1 tables require no column migration."""

from datetime import datetime
from uuid import uuid4

from sqlalchemy import JSON, Column, UniqueConstraint
from sqlmodel import Field, SQLModel

from app.models.metadata import now


class Analysis(SQLModel, table=True):
    __tablename__ = "analyses"
    id: str = Field(default_factory=lambda: str(uuid4()), primary_key=True)
    dataset_id: str = Field(foreign_key="datasets.id", index=True)
    question: str
    status: str = "pending"
    plan_json: dict | None = Field(default=None, sa_column=Column(JSON))
    finding_json: dict | None = Field(default=None, sa_column=Column(JSON))
    grounding_status: str = "pending"
    error: str | None = None
    created_at: datetime = Field(default_factory=now)
    updated_at: datetime = Field(default_factory=now)
    completed_at: datetime | None = None


class AnalysisStep(SQLModel, table=True):
    __tablename__ = "analysis_steps"
    __table_args__ = (UniqueConstraint("analysis_id", "step_id", "attempt_no"),)
    id: str = Field(default_factory=lambda: str(uuid4()), primary_key=True)
    analysis_id: str = Field(foreign_key="analyses.id", index=True)
    step_id: str
    attempt_no: int
    purpose: str
    rationale: str = ""
    generated_sql: str = ""
    normalized_sql: str | None = None
    validation_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    execution_summary_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    result_json: dict | None = Field(default=None, sa_column=Column(JSON))
    query_run_id: str | None = Field(default=None, foreign_key="query_runs.id")
    error: str | None = None
    status: str = "running"
    created_at: datetime = Field(default_factory=now)
    completed_at: datetime | None = None


class LLMCall(SQLModel, table=True):
    __tablename__ = "llm_calls"
    id: str = Field(default_factory=lambda: str(uuid4()), primary_key=True)
    analysis_id: str | None = Field(default=None, foreign_key="analyses.id", index=True)
    dataset_id: str = Field(foreign_key="datasets.id", index=True)
    purpose: str
    model: str
    prompt_version: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    latency_ms: float = 0
    request_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    response_json: dict | None = Field(default=None, sa_column=Column(JSON))
    status: str = "running"
    error: str | None = None
    created_at: datetime = Field(default_factory=now)
