import assert from "node:assert/strict";
import test from "node:test";
import fs from "node:fs";
import ts from "typescript";
const source = fs.readFileSync(
  new URL("../src/lib/streaming.ts", import.meta.url),
  "utf8",
);
const js = ts.transpileModule(source, {
  compilerOptions: {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.ES2022,
  },
}).outputText;
const { readSSE } = await import(
  `data:text/javascript;base64,${Buffer.from(js).toString("base64")}`
);
function stream(chunks) {
  return new ReadableStream({
    start(c) {
      chunks.forEach((x) => c.enqueue(x));
      c.close();
    },
  });
}
const encode = (value) => new TextEncoder().encode(value);
test("fragmented UTF-8, CRLF, heartbeats, many events and final buffer", async () => {
  const bytes = encode(
    ': hello\r\n\r\ndata: {"text":"£ café"}\r\n\r\ndata: {"n":2}\n\ndata: {"last":true}',
  );
  const chunks = Array.from(bytes, (b) => Uint8Array.of(b));
  const received = [];
  for await (const event of readSSE(stream(chunks))) received.push(event);
  assert.deepEqual(received, [{ text: "£ café" }, { n: 2 }, { last: true }]);
});
test("multiple events in a chunk and multiline data", async () => {
  const received = [];
  for await (const event of readSSE(
    stream([encode('data: {\ndata: "n":1}\n\ndata: {"n":2}\n\n')]),
  ))
    received.push(event);
  assert.deepEqual(received, [{ n: 1 }, { n: 2 }]);
});
test("abort cancels reader and rejects further updates", async () => {
  const controller = new AbortController();
  let cancelled = false;
  const body = new ReadableStream({
    cancel() {
      cancelled = true;
    },
  });
  const pending = (async () => {
    for await (const event of readSSE(body, controller.signal)) void event;
  })();
  controller.abort();
  await assert.rejects(pending, { name: "AbortError" });
  assert.equal(cancelled, true);
});
test("malformed JSON is rejected", async () => {
  await assert.rejects(async () => {
    for await (const event of readSSE(stream([encode("data: invalid\n\n")])))
      void event;
  });
});
