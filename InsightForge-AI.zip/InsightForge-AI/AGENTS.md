# InsightForge AI conventions

- Backend: Python 3.11, FastAPI, Pydantic v2, SQLModel metadata, DuckDB analytical data.
- `backend/app/routers`: HTTP only. `services`: cleaning, profiling, ingestion, guard, executor.
- `backend/app/models`: metadata tables. `core`: settings and database lifecycle.
- Frontend: Next.js 14 App Router, TypeScript, Tailwind, shadcn/ui components, TanStack Query, Recharts.
- Run `make setup`, `make gen-data`, `make dev`; verify `make test`, `make lint`, `make build`.
- All data numbers must come from executed SQL or deterministic profiling, never from the LLM.
- SQL must go through `sql_guard` + read-only executor. Never bypass either layer.
- Do not enable arbitrary Python execution, autonomous shell tools, or browsing tools. Phase 1 features must work without an API key; Phase 2 uses only the injectable, audited OpenAI Structured Outputs client.
- Preserve raw tables and retain duplicates. Log transformations and count rejected values.
- Ground truth belongs only in generator tests. Application code must never import or read it.
- Console and agent SQL go through `services/query.py` then guarded `executor.py`; every agent attempt records `source="agent"` exactly once.
- Keep frontend response validation in `frontend/src/lib/api.ts`.
- Keep secrets in environment variables; never commit `.env`, generated databases, or upload contents.
- Change guard policy explicitly with negative tests. Deny unknown functions by default.
- Keep package lock files and the backend requirements lock in sync after dependency changes.

- Keep typed plans/results in `agent/contracts.py`, orchestration in `agent/pipeline.py`, and HTTP/SSE handling in routers. Trace means observable actions and concise rationales, never private chain-of-thought.
- All LLM payloads use Pydantic Structured Outputs via `llm/client.py`; version prompt changes. SDK retries stay zero; schema repair, transport retry, SQL attempts, and grounding repair have separate bounds.
- Audit every actual model request, with sanitized/redacted request and response data and NULL for unknown token usage. No credentials in frontend, prompts, or logs.
- Findings must cite successful step/attempt/column/row evidence. Numeric prose uses server-rendered evidence tokens; unsupported findings remain explicitly unverified. Narratives fall back deterministically.
- Preserve original correction filters; never remove them to manufacture results. Empty evidence is a valid reason to stop. Negative profit is not an error.
- Only additive tables were introduced in Phase 2. Future existing-column changes require migrations; never delete metadata to upgrade.
- SSE must be incremental, validated, and terminal exactly once while connected. Cancel must stop subsequent work, clean up workers, persist cancellation, and release capacity. Startup cancels interrupted operations without replay.
- Default tests use fake transports and zero OpenAI network calls. Paid tests require both `OPENAI_API_KEY` and `INSIGHTFORGE_LIVE_TEST=1` and carry `pytest.mark.live`.
- Keep the app single-process while admission limits, caches, and recovery remain in memory. Do not add Phase 3 charts/confidence/decomposition or Phase 4 briefs/exports/audit UI/replay infrastructure.
