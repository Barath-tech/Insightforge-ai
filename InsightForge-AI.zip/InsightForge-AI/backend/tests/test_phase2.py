import asyncio
import json
import os
from decimal import Decimal

import pytest
from app.agent import store
from app.agent.contracts import Finding, Narrative
from app.agent.events import Events
from app.agent.pipeline import run
from app.core.config import settings
from app.llm.client import Client, LLMError, OpenAITransport, get_transport
from app.main import app
from app.models.analysis import Analysis, LLMCall
from app.models.metadata import Dataset, QueryRun
from app.services.grounding import check_finding, check_narrative, format_number, normalize
from app.services.schema import Fact, describe, facts_from_profile
from sqlmodel import Session, select

ORIGINAL_OPENAI_REQUEST = OpenAITransport.request


class Scripted:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    async def request(self, purpose, context, response_model):
        self.calls.append((purpose, context))
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return value(purpose, context) if callable(value) else value


def plan(steps=1):
    return dict(
        intent="lookup",
        answerable=True,
        explanation="Count imported rows.",
        metrics=[dict(name="n", definition="row count", unit="number", nonnegative=True)],
        dimensions=[],
        filters=[],
        time_range="All available dates",
        assumptions=[],
        steps=[
            dict(
                id=f"s{i}",
                purpose="Count rows",
                expected_output="n",
                depends_on=[f"s{i - 1}"] if i else [],
            )
            for i in range(steps)
        ],
    )


def sql(value, empty=False):
    return dict(
        sql=value,
        rationale="Measure the requested population.",
        measure_columns=["n"],
        nonnegative_columns=["n"],
        no_matching_data=empty,
    )


def finding(value="3", attempt=1, step="s0", column="n"):
    return dict(
        headline="Measured result",
        answer="{{n0}}",
        caveats=["Duplicates remain."],
        key_numbers=[
            dict(
                label=column,
                value=value,
                unit="number",
                source_step_id=step,
                source_attempt=attempt,
                column=column,
                row_index=0,
                conversion="identity",
                decimals=0,
            )
        ],
    )


def upload(client):
    result = client.post(
        "/api/datasets",
        files={
            "file": ("sales.csv", b"order_id,city,revenue\na,London,10\nb,Leeds,20\nb,Leeds,30\n")
        },
    )
    assert result.status_code == 201, result.text
    return result.json()["id"]


def ask(client, identifier, fake, question="Count rows"):
    app.dependency_overrides[get_transport] = lambda: fake
    result = client.post(f"/api/datasets/{identifier}/ask", json={"question": question})
    assert result.status_code == 200, result.text
    assert result.headers["content-type"].startswith("text/event-stream")
    events = [
        json.loads(line[6:]) for line in result.text.splitlines() if line.startswith("data: ")
    ]
    assert [e["sequence"] for e in events] == list(range(1, len(events) + 1))
    assert sum(e["type"] == "done" for e in events) == 1
    assert events[-1]["type"] == "done"
    return events, client.get("/api/analyses/" + events[0]["analysis_id"]).json()


def records(client, model):
    with Session(app.state.test_engine) as session:
        return session.exec(select(model)).all()


def test_correction_audit_history_schema(client):
    identifier = upload(client)
    schema = client.get(f"/api/datasets/{identifier}/schema").json()
    assert {t["name"] for t in schema["tables"]} == {"sales", "raw_sales"}
    assert schema["tables"][0]["columns"][0]["samples"] == []
    assert next(f for f in schema["facts"] if f["id"].endswith(":unique_ids"))["value"] == 2
    fake = Scripted(
        [
            plan(),
            sql("SELECT nonexistent FROM sales"),
            sql("SELECT COUNT(*) AS n FROM sales"),
            finding(attempt=2),
        ]
    )
    events, saved = ask(client, identifier, fake)
    assert saved["status"] == "completed", saved
    assert saved["grounding_status"] == "verified"
    assert len(saved["steps"]) == 2
    assert saved["steps"][0]["status"] == "execution_error"
    assert saved["steps"][1]["result_json"]["column_types"] == ["BIGINT"]
    assert "correction" in [e["type"] for e in events]
    assert len(records(client, QueryRun)) == 3  # Two attempts plus guarded population count.
    counts = saved["finding_json"]["evidence"]["rows_scanned"]
    assert counts[0]["rows"] == 3
    assert counts[0]["query_run_id"] in {r.id for r in records(client, QueryRun)}
    assert all(r.source == "agent" for r in records(client, QueryRun))
    audited = {s["query_run_id"] for s in saved["steps"]} | {c["query_run_id"] for c in counts}
    assert audited == {r.id for r in records(client, QueryRun)}
    calls = records(client, LLMCall)
    assert len(calls) == 4
    assert all(c.analysis_id == saved["id"] and c.input_tokens is None for c in calls)
    assert client.get(f"/api/datasets/{identifier}/analyses").json()[0]["id"] == saved["id"]


@pytest.mark.parametrize(
    "statement",
    [
        "DELETE FROM sales",
        "SELECT * FROM read_csv('/tmp/x')",
        "SELECT evil(revenue) FROM sales",
        "SELECT 1; SELECT 2",
        "WITH x AS (DELETE FROM sales RETURNING *) SELECT * FROM x",
        "SELECT no_such_column FROM sales",
    ],
)
def test_three_attempts_and_guard(client, statement):
    identifier = upload(client)
    events, saved = ask(client, identifier, Scripted([plan()] + [sql(statement)] * 3))
    assert saved["status"] == "failed"
    assert len(saved["steps"]) == len(records(client, QueryRun)) == 3
    assert len(records(client, LLMCall)) == 4
    assert saved["finding_json"] is None
    assert events[-2]["type"] == "error"


@pytest.mark.parametrize(
    "statement",
    [
        "SELECT NULL AS n FROM sales",
        "SELECT -1 AS n FROM sales",
        "SELECT 1 AS n FROM sales WHERE city='Absent'",
    ],
)
def test_suspicious_corrections_bounded(client, statement):
    identifier = upload(client)
    _, saved = ask(client, identifier, Scripted([plan()] + [sql(statement)] * 3))
    assert saved["status"] == "failed"
    assert all(s["status"] == "suspicious" for s in saved["steps"])


def test_confirmed_empty_stops(client):
    identifier = upload(client)
    _, saved = ask(
        client,
        identifier,
        Scripted([plan(), sql("SELECT 1 AS n FROM sales WHERE city='Absent'", empty=True)]),
    )
    assert len(saved["steps"]) == 1
    assert saved["status"] == "failed"


def test_unverified_finding_and_truncation(client, monkeypatch):
    monkeypatch.setattr(settings, "query_max_rows", 1)
    identifier = upload(client)
    _, saved = ask(
        client,
        identifier,
        Scripted([plan(), sql("SELECT revenue AS n FROM sales"), finding("999"), finding("999")]),
    )
    assert saved["status"] == "completed"
    assert saved["grounding_status"] == "unverified"
    assert saved["steps"][0]["result_json"]["truncated"]
    assert len(records(client, LLMCall)) == 4


def test_narrative_repair_fallback_cache(client):
    identifier = upload(client)
    fake = Scripted([dict(introduction="Invented story", claims=[])] * 2)
    app.dependency_overrides[get_transport] = lambda: fake
    first = client.post(f"/api/datasets/{identifier}/narrative").json()
    second = client.post(f"/api/datasets/{identifier}/narrative").json()
    assert first == second
    assert first["status"] == "fallback" and "Total imported rows: 3" in first["narrative"]
    assert len(records(client, LLMCall)) == 2
    assert all(c.analysis_id is None for c in records(client, LLMCall))


def test_missing_key_suggestions_and_request_id(client, monkeypatch):
    identifier = upload(client)
    monkeypatch.setattr(settings, "openai_api_key", "")
    app.dependency_overrides[get_transport] = OpenAITransport
    response = client.post(f"/api/datasets/{identifier}/ask", json={"question": "Count rows"})
    assert response.status_code == 503
    assert response.headers["X-Request-ID"]
    assert client.post(f"/api/datasets/{identifier}/ask", json={"question": " "}).status_code == 422
    assert client.post("/api/datasets/no/ask", json={"question": "Count rows"}).status_code == 404
    suggestions = client.get(f"/api/datasets/{identifier}/suggestions").json()
    assert len(suggestions["questions"]) == 5
    assert suggestions["status"] == "fallback"


@pytest.mark.parametrize(
    "error",
    [
        LLMError("refusal", "Declined"),
        LLMError("authentication", "Check configuration"),
        LLMError("incomplete", "Incomplete"),
    ],
)
def test_terminal_model_errors(client, error):
    identifier = upload(client)
    events, saved = ask(client, identifier, Scripted([error]))
    assert saved["status"] == "failed"
    assert len(records(client, LLMCall)) == 1
    assert events[-1]["payload"]["status"] == "failed"


def test_schema_transport_budgets(client):
    identifier = upload(client)
    fake = Scripted([LLMError("rate_limit", "Limited", True), {}, {}, {}])
    _, saved = ask(client, identifier, fake)
    assert saved["status"] == "failed"
    assert len(fake.calls) == len(records(client, LLMCall)) == 3


def test_grounding_categories_provenance_and_rounding():
    assert normalize("£-1,234.50") == Decimal("-1234.50")
    assert normalize("18.7%") == Decimal("18.7")
    assert normalize("00123", "identifier") == "00123"
    assert normalize("2024-10-01", "date") == "2024-10-01"
    assert format_number(0.187, "percent", "fraction_to_percent", 1) == "18.7%"
    assert format_number(-1.235, "GBP", "identity", 2) == "£-1.24"
    evidence = {("s0", 1): {"columns": ["n", "missing"], "rows": [{"n": 3, "missing": 47}]}}
    valid = Finding.model_validate(finding())
    assert check_finding(valid, evidence)["grounding_status"] == "verified"
    valid.key_numbers[0].source_step_id = "other"
    assert check_finding(valid, evidence)["grounding_errors"]
    valid = Finding.model_validate(finding("47"))
    assert check_finding(valid, evidence)["grounding_errors"]
    valid = Finding.model_validate(finding())
    valid.answer = "There were 999 orders."
    assert check_finding(valid, evidence)["grounding_errors"]
    valid.answer = "There were forty orders."
    # Unsupported number words are rejected too.
    assert check_finding(valid, evidence)["grounding_errors"]
    fact = Fact(id="missing", table="sales", column="date", label="Missing dates", value=47)
    narrative = Narrative.model_validate(
        dict(
            introduction="Profile summary by table.",
            claims=[dict(fact_id="missing", label="Duplicate orders", value="47")],
        )
    )
    assert check_narrative(narrative, [fact])["errors"]


def test_facts_multi_table_legacy_shape():
    facts = facts_from_profile({"tables": {"a": {"row_count": 5}, "b": {"row_count": 7}}})
    assert [(f.table, f.value) for f in facts] == [("a", 5), ("b", 7)]


def test_cancel_model_and_recovery(client):
    identifier = upload(client)
    engine = app.state.test_engine

    class Slow:
        async def request(self, *args):
            await asyncio.sleep(30)

    async def scenario():
        with Session(engine) as session:
            dataset = session.get(Dataset, identifier)
            schema = describe(dataset, session)
        analysis = store.save(engine, Analysis(dataset_id=identifier, question="Count rows"))
        queue = asyncio.Queue()
        task = asyncio.create_task(
            run(engine, dataset, schema, analysis, Slow(), Events(analysis.id, queue))
        )
        await asyncio.sleep(0.15)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
        assert store.detail(engine, analysis.id)["status"] == "cancelled"

    asyncio.run(scenario())
    assert records(client, LLMCall)[0].status == "cancelled"
    pending = store.save(engine, Analysis(dataset_id=identifier, question="Interrupted"))
    store.recover(engine)
    assert store.detail(engine, pending.id)["status"] == "cancelled"


def test_fake_london_flow(client):
    identifier = client.post("/api/datasets/demo").json()["id"]
    p = plan(3)
    p["intent"] = "why"
    p["steps"][0]["purpose"] = "Infer year from available dates"
    p["steps"][1]["purpose"] = "Compare per-order components with January–September baseline"
    p["steps"][2]["purpose"] = "Compare peak-slot delivery cost separately"
    p["assumptions"] = [
        "Gross margin is a GBP amount; compare average per order.",
        "Duplicates retained; null dates excluded from periods.",
    ]
    table = "uk_retail_operations"
    year = sql(f"SELECT MAX(YEAR(order_date)) AS n FROM {table}")
    components = sql(f"""SELECT CASE WHEN MONTH(order_date)=10
        THEN 'October' ELSE 'Jan-Sep' END AS period,
        AVG(revenue) AS revenue, AVG(cogs) AS cogs, AVG(delivery_cost) AS delivery_cost,
        AVG(refund_amount) AS refund_amount,
        AVG(revenue-cogs-delivery_cost-refund_amount) AS n
        FROM {table} WHERE city='London' AND YEAR(order_date)=2024
        AND MONTH(order_date)<=10 GROUP BY 1 ORDER BY 1""")
    peak = sql(f"""SELECT CASE WHEN MONTH(order_date)=10
        THEN 'October' ELSE 'Jan-Sep' END AS period,
        AVG(delivery_cost) AS n FROM {table} WHERE city='London' AND delivery_slot='Peak'
        AND YEAR(order_date)=2024 AND MONTH(order_date)<=10 GROUP BY 1 ORDER BY 1""")

    def grounded(purpose, context):
        result = context["evidence"]["s2"]["rows"][0]["n"]
        return finding(str(round(result, 2)), step="s2") | {
            "key_numbers": [
                dict(
                    label="n",
                    value=str(round(result, 2)),
                    unit="GBP",
                    source_step_id="s2",
                    source_attempt=1,
                    column="n",
                    row_index=0,
                    conversion="identity",
                    decimals=2,
                )
            ]
        }

    _, saved = ask(
        client,
        identifier,
        Scripted([p, year, components, peak, grounded]),
        question="Why did profit margin decline in London in October?",
    )
    assert saved["status"] == "completed", saved
    assert saved["grounding_status"] == "verified"
    assert len(saved["steps"]) == 3
    assert "delivery_cost" in saved["steps"][1]["result_json"]["columns"]


@pytest.mark.live
def test_live_london(client):
    if not (os.getenv("INSIGHTFORGE_LIVE_TEST") == "1" and settings.openai_api_key):
        pytest.skip("Requires key and INSIGHTFORGE_LIVE_TEST=1")
    identifier = client.post("/api/datasets/demo").json()["id"]
    app.dependency_overrides[get_transport] = OpenAITransport
    result = client.post(
        f"/api/datasets/{identifier}/ask",
        json={"question": "Why did profit margin decline in London in October?"},
    )
    events = [
        json.loads(line[6:]) for line in result.text.splitlines() if line.startswith("data: ")
    ]
    saved = client.get("/api/analyses/" + events[0]["analysis_id"]).json()
    assert saved["status"] == "completed", saved
    keys = saved["finding_json"]["key_numbers"]
    assert any(
        "delivery" in k["column"].lower()
        and any(
            s["step_id"] == k["source_step_id"]
            and s["attempt_no"] == k["source_attempt"]
            and s["status"] == "ok"
            for s in saved["steps"]
        )
        for k in keys
    )


def test_boolean_operators_guard():
    from app.services.sql_guard import SQLValidationError, validate_sql

    assert validate_sql(
        "SELECT * FROM sales WHERE revenue>0 AND (city='London' OR NOT city='Leeds')", ["sales"]
    )
    for statement in [
        "SELECT * FROM sales WHERE revenue>0 AND evil(city)=1",
        "SELECT * FROM sales WHERE revenue>0 OR EXISTS(SELECT * FROM read_csv('/tmp/x'))",
        "WITH x AS (DELETE FROM sales RETURNING *) SELECT * FROM x WHERE TRUE AND TRUE",
    ]:
        with pytest.raises(SQLValidationError):
            validate_sql(statement, ["sales"])


def test_stream_incremental_disconnect_and_capacity(client):
    """Exercise ASGI send/receive directly: HTTP clients often buffer test streams."""
    identifier = upload(client)
    from app.routers.analyses import limiter

    class Pausing(Scripted):
        async def request(self, purpose, context, response_model):
            if purpose == "sql":
                await asyncio.sleep(30)
            return await super().request(purpose, context, response_model)

    fake = Pausing([plan()])
    app.dependency_overrides[get_transport] = lambda: fake

    async def scenario():
        incoming = asyncio.Queue()
        incoming.put_nowait(
            {
                "type": "http.request",
                "body": json.dumps({"question": "Count rows"}).encode(),
                "more_body": False,
            }
        )
        frames = []

        async def send(message):
            if message["type"] == "http.response.body":
                body = message.get("body", b"").decode()
                frames.append(body)
                if '"type": "plan"' in body:
                    # Plan arrived while the next model operation is still blocked.
                    assert len(fake.calls) == 1
                    incoming.put_nowait({"type": "http.disconnect"})

        scope = {
            "type": "http",
            "asgi": {"version": "3.0", "spec_version": "2.3"},
            "http_version": "1.1",
            "method": "POST",
            "scheme": "http",
            "path": f"/api/datasets/{identifier}/ask",
            "raw_path": b"/",
            "query_string": b"",
            "headers": [(b"content-type", b"application/json")],
            "client": ("127.0.0.1", 1),
            "server": ("test", 80),
        }
        await asyncio.wait_for(app(scope, incoming.get, send), timeout=5)
        assert any('"type": "plan"' in f for f in frames)

    asyncio.run(scenario())
    assert limiter.active == 0
    assert records(client, Analysis)[0].status == "cancelled"
    assert not records(client, QueryRun)


def test_executor_cancellation_cleans_children(client):
    import multiprocessing
    import threading

    from app.services.executor import execute

    identifier = upload(client)
    with Session(app.state.test_engine) as session:
        dataset = session.get(Dataset, identifier)
    cancellation = threading.Event()
    cancellation.set()
    before = {p.pid for p in multiprocessing.active_children()}
    with pytest.raises(InterruptedError):
        execute(
            dataset.duckdb_path,
            "SELECT COUNT(*) FROM sales a, sales b",
            dataset.table_names,
            cancel=cancellation,
        )
    assert {p.pid for p in multiprocessing.active_children()} == before


def test_capacity_preflight(client):
    identifier = upload(client)
    from app.routers.analyses import limiter

    app.dependency_overrides[get_transport] = lambda: Scripted([])
    limiter.active = settings.ask_concurrency
    try:
        response = client.post(f"/api/datasets/{identifier}/ask", json={"question": "Count rows"})
        assert response.status_code == 429
        assert not records(client, Analysis)
    finally:
        limiter.active = 0


def test_negative_profit_is_valid(client):
    identifier = upload(client)
    p = plan()
    p["metrics"][0]["nonnegative"] = False
    _, saved = ask(client, identifier, Scripted([p, sql("SELECT -10 AS n"), finding("-10")]))
    assert saved["grounding_status"] == "verified"
    assert len(saved["steps"]) == 1


def test_schema_multitable_and_missing_profile(client, tmp_path):
    import sqlite3

    from app.models.metadata import DatasetProfile

    path = tmp_path / "multiple.sqlite"
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE first (id INTEGER, value INTEGER)")
        conn.execute("INSERT INTO first VALUES (1, 2)")
        conn.execute("CREATE TABLE second (id INTEGER, value INTEGER)")
    with path.open("rb") as f:
        identifier = client.post("/api/datasets", files={"file": (path.name, f)}).json()["id"]
    response = client.get(f"/api/datasets/{identifier}/schema")
    assert response.status_code == 200
    facts = response.json()["facts"]
    assert {f["table"] for f in facts} == {"first", "second"}
    with Session(app.state.test_engine) as session:
        profile = session.get(DatasetProfile, identifier)
        profile.profile_json = {"tables": {"first": {"row_count": 1}}}
        session.add(profile)
        session.commit()
    schema = client.get(f"/api/datasets/{identifier}/schema").json()
    assert len(schema["tables"]) == 4
    assert schema["tables"][0]["columns"]


def test_timeout_request_audit(client, monkeypatch):
    identifier = upload(client)
    monkeypatch.setattr(settings, "llm_timeout_seconds", 0.01)
    monkeypatch.setattr(settings, "llm_transport_retries", 0)

    class Slow:
        async def request(self, *args):
            await asyncio.sleep(1)

    _, saved = ask(client, identifier, Slow())
    assert saved["status"] == "failed"
    calls = records(client, LLMCall)
    assert len(calls) == 1 and calls[0].status == "timeout"
    assert calls[0].input_tokens is None


def test_redaction_and_bounded_context(monkeypatch):
    from app.agent.context import bound_result, model_result
    from app.llm.redaction import redact

    monkeypatch.setattr(settings, "openai_api_key", "sk-private-secret")
    redacted = redact(
        {
            "question": "private question",
            "reply": "sk-private-secret x@y.com",
            "samples": ["123"],
            "rows": [{"id": "secret"}],
        }
    )
    assert "private-secret" not in json.dumps(redacted)
    assert "x@y.com" not in json.dumps(redacted)
    result = {"columns": ["n"], "rows": [{"n": "x" * 200}], "row_count": 1, "truncated": False}
    assert bound_result(result, 100)["rows"] == []
    assert bound_result(result, 100)["truncated"]
    assert model_result(result)["rows"] == result["rows"]


def test_sdk_responses_parse_interface(client, monkeypatch):
    identifier = upload(client)
    from types import SimpleNamespace

    import app.llm.client as module
    from app.agent.contracts import Plan

    calls = []

    class SDK:
        def __init__(self, **kwargs):
            assert kwargs["max_retries"] == 0
            self.responses = self

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            pass

        async def parse(self, **kwargs):
            calls.append(kwargs)
            assert kwargs["text_format"] is Plan
            assert "response_format" not in kwargs
            return SimpleNamespace(
                status="completed",
                output=[],
                output_parsed=Plan(**plan()),
                usage=SimpleNamespace(input_tokens=100, output_tokens=40),
                model_dump=lambda: {"output": []},
            )

    # Override the autouse network block only with a local stub; no HTTP occurs.
    monkeypatch.setattr(module, "AsyncOpenAI", SDK)
    monkeypatch.setattr(settings, "openai_api_key", "test-key")

    monkeypatch.setattr(OpenAITransport, "request", ORIGINAL_OPENAI_REQUEST)
    result = asyncio.run(
        Client(app.state.test_engine, identifier, OpenAITransport()).generate("plan", {}, Plan)
    )
    assert result.answerable
    row = records(client, LLMCall)[0]
    assert (row.input_tokens, row.output_tokens) == (100, 40)
    assert len(calls) == 1


def test_correction_cannot_remove_filter(client):
    identifier = upload(client)
    fake = Scripted(
        [
            plan(),
            sql("SELECT revenue AS n FROM sales WHERE city='Absent'"),
            sql("SELECT revenue AS n FROM sales"),
            sql("SELECT revenue AS n FROM sales"),
        ]
    )
    _, saved = ask(client, identifier, fake)
    assert saved["status"] == "failed"
    assert saved["steps"][1]["status"] == "validation_error"
    assert "filter" in saved["steps"][1]["error"]
    assert len(records(client, QueryRun)) == 3
