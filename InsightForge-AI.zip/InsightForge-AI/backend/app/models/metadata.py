from datetime import datetime, timezone
from uuid import uuid4

from sqlalchemy import JSON, Column
from sqlmodel import Field, SQLModel


def now():
    return datetime.now(timezone.utc)


class Dataset(SQLModel, table=True):
    __tablename__ = "datasets"
    id: str = Field(default_factory=lambda: str(uuid4()), primary_key=True)
    name: str
    source_type: str
    original_filename: str
    duckdb_path: str
    table_names: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    row_count: int = 0
    created_at: datetime = Field(default_factory=now)
    status: str = "ready"


class DatasetProfile(SQLModel, table=True):
    __tablename__ = "dataset_profiles"
    dataset_id: str = Field(primary_key=True, foreign_key="datasets.id")
    profile_json: dict = Field(sa_column=Column(JSON))
    health_score: int
    created_at: datetime = Field(default_factory=now)


class QueryRun(SQLModel, table=True):
    __tablename__ = "query_runs"
    id: str = Field(default_factory=lambda: str(uuid4()), primary_key=True)
    dataset_id: str = Field(foreign_key="datasets.id", index=True)
    sql: str
    status: str
    error: str | None = None
    row_count: int = 0
    elapsed_ms: float = 0
    created_at: datetime = Field(default_factory=now)
    source: str = "console"
