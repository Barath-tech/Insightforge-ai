"""Install the official SQLite extension once, at setup/build time."""

import duckdb
from app.core.config import settings

folder = settings.data_dir / "extensions"
folder.mkdir(parents=True, exist_ok=True)
with duckdb.connect() as conn:
    conn.execute("SET extension_directory = ?", [str(folder)])
    conn.execute("INSTALL sqlite FROM 'https://extensions.duckdb.org'")
