import asyncio
import json
import logging
import time
from contextlib import asynccontextmanager
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.db import init_db
from app.routers.analyses import router as analyses_router
from app.routers.datasets import router
from app.routers.final import router as final_router


@asynccontextmanager
async def lifespan(app):
    await asyncio.to_thread(init_db)
    yield


app = FastAPI(title="InsightForge AI", version="0.4.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_methods=["GET", "POST", "PATCH"],
    allow_headers=["Content-Type", "X-Request-ID"],
    expose_headers=["X-Request-ID", "X-Analysis-ID", "Retry-After"],
)
app.include_router(router)
app.include_router(analyses_router)
app.include_router(final_router)
logger = logging.getLogger("insightforge")
logger.setLevel(logging.INFO)
if not logger.handlers:
    logger.addHandler(logging.StreamHandler())
logger.propagate = False


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "phase": 4,
        "llm_enabled": bool(settings.openai_api_key) or settings.demo_replay == "replay",
        "demo_replay": settings.demo_replay,
    }


@app.middleware("http")
async def request_logging(request: Request, call_next):
    request_id = str(uuid4())
    request.state.request_id = request_id
    start = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception:
        response = JSONResponse(
            {"detail": "Unexpected server error.", "request_id": request_id}, status_code=500
        )
    response.headers["X-Request-ID"] = request_id
    logger.info(
        json.dumps(
            {
                "request_id": request_id,
                "method": request.method,
                "status": response.status_code,
                "elapsed_ms": round((time.perf_counter() - start) * 1000, 2),
            }
        )
    )
    return response
