"""Evidence provenance and explicit heuristic confidence; not causal probability."""

import math

import numpy as np
import sqlglot
from sqlglot import exp
from sqlmodel import Session

from app.services.ingest import quote
from app.services.query import submit


def confidence(
    sample_size=0,
    effect=0.0,
    variation=0.0,
    consistency=0.5,
    quality_share=0.0,
    corrections=0,
    verified=False,
):
    ratio = abs(effect) / max(abs(variation), 1e-9) if effect else 0.0
    factors = {
        "sample adequacy": 25 * min(1, max(0, sample_size) / 100),
        "effect versus variation": 25 * min(1, ratio / 3),
        "cross-step consistency": 15 * max(0, min(1, consistency)),
        "grounding verified": 35 if verified else 0,
        "data-quality penalty": -30 * max(0, min(1, quality_share)),
        "repair penalty": -min(10, corrections * 2),
    }
    score = round(max(0, min(100, sum(factors.values()))))
    if not verified:
        score = min(score, 39)
    return {
        "score": score,
        "label": "High" if score >= 75 else "Medium" if score >= 50 else "Low",
        "breakdown": [{"factor": k, "contribution": round(v, 2)} for k, v in factors.items()],
        "method": "Heuristic evidence strength, not a probability or proof of causation.",
    }


MARGIN_SIGN = {"revenue": 1, "cogs": -1, "delivery_cost": -1, "refund_amount": -1}
CONSISTENCY_METHOD = (
    "Share of agreeing pairs among independent directional signals, each mapped to its "
    "implied effect on gross margin. Neutral (0.5) when fewer than two comparable signals."
)


def margin_direction(column):
    """Implied effect on gross margin of an increase in this measure; None if unknown."""
    name = column.lower()
    if name in MARGIN_SIGN:
        return MARGIN_SIGN[name]
    if "margin" in name or "profit" in name:
        return 1
    return None


def direction(value, tolerance=1e-9):
    return 0 if abs(value) <= tolerance else (1 if value > 0 else -1)


def directional_agreement(decomposition, series):
    """Compare the margin direction implied by each independent executed result."""
    signals = []
    if decomposition and decomposition.get("complete"):
        sign = direction(decomposition["observed_margin_change"])
        if sign:
            signals.append(
                {
                    "source": "decomposition",
                    "measure": "gross_margin",
                    "change": decomposition["target_margin"] - decomposition["baseline_margin"],
                    "margin_direction": sign,
                }
            )
    for step_id, column, values in series:
        implied = margin_direction(column)
        change = values[-1] - float(np.mean(values[:-1]))
        if implied is None or not direction(change):
            continue
        signals.append(
            {
                "source": step_id,
                "measure": column,
                "change": change,
                "margin_direction": implied * direction(change),
            }
        )
    pairs = [
        a["margin_direction"] == b["margin_direction"]
        for i, a in enumerate(signals)
        for b in signals[i + 1 :]
    ]
    return {
        "score": sum(pairs) / len(pairs) if pairs else 0.5,
        "comparable": bool(pairs),
        "signals": signals,
        "method": CONSISTENCY_METHOD,
    }


def decompose(rows):
    """Contract: period=baseline|target, dimension, n, and sums of margin components.

    Standardize baseline group means to target group counts. The separately reported
    mix effect reconciles the target-population counterfactual to baseline averages.
    """
    groups = {}
    for row in rows:
        groups.setdefault(str(row.get("dimension", "All")), {})[row.get("period")] = row
    total_target = sum(v.get("target", {}).get("n", 0) for v in groups.values())
    total_base = sum(v.get("baseline", {}).get("n", 0) for v in groups.values())
    drivers, effects, sizes = [], [], []
    if not total_target or not total_base:
        return {"drivers": [], "effects": [], "sample_sizes": [], "complete": False}
    complete = True
    for dimension, periods in groups.items():
        b, t = periods.get("baseline"), periods.get("target")
        if not b or not t or not b.get("n") or not t.get("n"):
            complete = False
            continue
        sizes.append({"group": dimension, "baseline": b["n"], "target": t["n"]})
        for component, sign in [
            ("revenue", 1),
            ("cogs", -1),
            ("delivery_cost", -1),
            ("refund_amount", -1),
        ]:
            if not all(isinstance(r.get(component), (int, float)) for r in [b, t]):
                complete = False
                continue
            before, after = b[component] / b["n"], t[component] / t["n"]
            delta = after - before
            impact = sign * delta * t["n"]
            pct = delta / abs(before) * 100 if before else None
            drivers.append(
                {
                    "component": component,
                    "dimension": dimension,
                    "baseline": before,
                    "target": after,
                    "absolute_change": delta,
                    "change_pct": pct,
                    "margin_impact": impact,
                    "per_order_contribution": impact / total_target,
                }
            )
            effects.append(
                {"metric": component, "group": dimension, "absolute": delta, "percent": pct}
            )
    drivers.sort(key=lambda d: d["margin_impact"])
    negative = [d for d in drivers if d["margin_impact"] < -1e-9]
    for driver in drivers:
        driver["rank"] = (
            "primary"
            if negative and driver is negative[0]
            else "secondary"
            if len(negative) > 1 and driver is negative[1]
            else "other"
        )

    def margin(r):
        return r["revenue"] - r["cogs"] - r["delivery_cost"] - r["refund_amount"]

    bmean = sum(margin(v["baseline"]) for v in groups.values() if "baseline" in v) / total_base
    tmean = sum(margin(v["target"]) for v in groups.values() if "target" in v) / total_target
    observed = (tmean - bmean) * total_target
    explained = sum(d["margin_impact"] for d in drivers)
    return {
        "drivers": drivers,
        "effects": effects,
        "sample_sizes": sizes,
        "complete": complete,
        "baseline_n": total_base,
        "target_n": total_target,
        "baseline_margin": bmean,
        "target_margin": tmean,
        "observed_margin_change": observed,
        "within_group_change": explained,
        "mix_residual": observed - explained,
        "margin_lost": max(0, -observed),
        "unit": "GBP on target-order count",
        "definition": "Target vs baseline mean margin",
    }


def build_evidence(engine, dataset, schema, records, grounded, retries=0):
    used, tables, supporting, counts = set(), set(), [], []
    decomposition = None
    for record in records:
        sql = record.normalized_sql or record.generated_sql
        tree = sqlglot.parse_one(sql, read="duckdb")
        used.update(c.name for c in tree.find_all(exp.Column))
        tables.update(t.name for t in tree.find_all(exp.Table) if t.name in dataset.table_names)
        result = record.result_json
        supporting.append(
            {
                "step_id": record.step_id,
                "attempt": record.attempt_no,
                "sql": sql,
                "query_run_id": record.query_run_id,
                "returned_rows": result["row_count"],
                "truncated": result.get("truncated", False),
            }
        )
        required = {"period", "dimension", "n", "revenue", "cogs", "delivery_cost", "refund_amount"}
        if required <= set(result["columns"]) and not result.get("truncated"):
            decomposition = decompose(result["rows"])
    # These are source-table population counts, not DuckDB physical scan instrumentation.
    for table in sorted(tables):
        sql = f"SELECT COUNT(*) AS source_rows FROM {quote(table)}"
        with Session(engine) as session:
            outcome = submit(session, dataset, sql, source="agent")
        counts.append(
            {
                "table": table,
                "sql": sql,
                "query_run_id": outcome["run"]["id"],
                "rows": outcome["result"]["rows"][0]["source_rows"] if outcome["result"] else None,
                "error": outcome["run"]["error"],
            }
        )
    issues = [i for i in schema.get("issues", []) if i["column"] in used and i["table"] in tables]
    population = sum(c["rows"] or 0 for c in counts)
    # Conservative upper bound; overlapping issue populations must not be claimed disjoint.
    quality = min(
        1.0,
        sum(
            i["count"]
            for i in issues
            if i["code"] not in {"inconsistent_casing", "currency_strings", "mixed_dates"}
        )
        / max(population, 1),
    )
    effect = 0.0
    variance = 0.0
    series = []
    for record in records:
        r = record.result_json
        if r.get("chart", {}).get("type") == "line":
            for col in r["chart"]["y"]:
                values = [
                    row[col] for row in r["chart"]["rows"] if isinstance(row.get(col), (int, float))
                ]
                if len(values) >= 4:
                    series.append((record.step_id, col, values))
    if decomposition and decomposition.get("complete"):
        effect = decomposition["target_margin"] - decomposition["baseline_margin"]
    if series:
        baseline = series[0][2][:-1]
        variance = float(np.std(baseline))
        if not decomposition:
            effect = series[0][2][-1] - float(np.mean(baseline))
    # Without measured baseline variation, withhold the effect contribution.
    if not series:
        variance = math.inf
    agreement = directional_agreement(decomposition, series)
    conf = confidence(
        sample_size=min(
            (decomposition or {}).get("target_n", 0), (decomposition or {}).get("baseline_n", 0)
        ),
        effect=effect,
        variation=variance,
        consistency=agreement["score"],
        quality_share=quality,
        corrections=retries,
        verified=grounded["grounding_status"] == "verified",
    )
    return {
        "supporting_steps": supporting,
        "rows_scanned": counts,
        "count_definition": "Unfiltered source-table row counts, not physical rows scanned",
        "key_numbers": grounded["key_numbers"],
        "used_columns": sorted(used),
        "quality_issues": issues,
        "quality_share_upper_bound": quality,
        "sample_sizes": (decomposition or {}).get("sample_sizes", []),
        "effects": (decomposition or {}).get("effects", []),
        "confidence": conf,
        "consistency": agreement,
        "decomposition": decomposition,
    }
