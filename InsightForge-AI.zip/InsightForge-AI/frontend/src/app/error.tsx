"use client";
import Link from "next/link";
import { ErrorBox } from "@/components/shared";
export default function Error({
  error,
  reset,
}: {
  error: Error;
  reset: () => void;
}) {
  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-semibold mb-4">Something went wrong</h1>
      <ErrorBox error={error} retry={reset} />
      <p className="subtle mt-4">
        If the backend was restarted, try again. Otherwise{" "}
        <Link className="text-primary underline" href="/">
          return to your data library
        </Link>
        .
      </p>
    </div>
  );
}