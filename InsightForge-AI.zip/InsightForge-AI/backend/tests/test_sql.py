import duckdb
import pytest
from app.services.executor import execute
from app.services.sql_guard import SQLValidationError, validate_sql


@pytest.mark.parametrize(
    "sql",
    [
        "SELECT 1; DROP TABLE x",
        "SELECT 1; SELECT 2",
        "-- comment\nDELETE FROM x",
        "INSERT INTO x VALUES (1)",
        "UPDATE x SET a=1",
        "DROP TABLE x",
        "ALTER TABLE x ADD a INT",
        "CREATE TABLE y AS SELECT * FROM x",
        "TRUNCATE x",
        "COPY x TO '/tmp/export.csv'",
        "COPY x FROM '/tmp/import.csv'",
        "ATTACH '/tmp/a.db' AS a",
        "DETACH a",
        "INSTALL httpfs",
        "LOAD httpfs",
        "PRAGMA version",
        "SET threads=4",
        "BEGIN",
        "COMMIT",
        "ROLLBACK",
        "VACUUM",
        "CALL checkpoint()",
        "EXPORT DATABASE '/tmp/x'",
        "WITH a AS (DELETE FROM x RETURNING *) SELECT * FROM a",
        "WITH a AS (SELECT 1) INSERT INTO x SELECT * FROM a",
        "SELECT * FROM read_csv('/etc/passwd')",
        "SELECT * FROM sqlite_scan('/tmp/x','x')",
        "SELECT * FROM range(100)",
        "SELECT * FROM information_schema.tables",
        "SELECT * FROM '/tmp/file.csv'",
        "SELECT getenv('HOME')",
        "SELECT nextval('seq')",
        "SELECT * FROM query('DELETE FROM x')",
        "SELECT * INTO y FROM x",
        "SELECT * FROM x; /* harmless */ DROP TABLE x",
        "SELECT * FROM unknown",
        "SELECT * FROM duckdb_settings()",
        "SELECT * FROM glob('/tmp/*')",
    ],
)
def test_guard_blocks(sql):
    with pytest.raises(SQLValidationError):
        validate_sql(sql, ["x"])


@pytest.mark.parametrize(
    "sql",
    [
        "SELECT * FROM x",
        "-- safe comment\nSELECT COUNT(*) FROM x",
        "WITH a AS (SELECT * FROM x) SELECT * FROM a",
        "SELECT 'DROP TABLE x' AS text",
        "SELECT a FROM x UNION ALL SELECT a FROM x",
        "SELECT AVG(a), SUM(a) FROM x",
        "SELECT EXTRACT(MONTH FROM CAST('2024-10-01' AS DATE))",
        "SELECT 1 /* comment */",
    ],
)
def test_guard_allows(sql):
    assert validate_sql(sql, ["x"])


@pytest.fixture
def database(tmp_path):
    path = str(tmp_path / "test.duckdb")
    with duckdb.connect(path) as conn:
        conn.execute("CREATE TABLE x AS SELECT range AS a FROM range(10000)")
    return path


def test_executor_results_and_readonly(database):
    result = execute(database, "SELECT * FROM x ORDER BY a", ["x"], timeout=10, limit=10)
    assert result["row_count"] == 10
    assert result["truncated"]
    assert result["rows"][0]["a"] == 0
    with pytest.raises(SQLValidationError):
        execute(database, "DELETE FROM x", ["x"])
    with duckdb.connect(database, read_only=True) as conn:
        assert conn.execute("SELECT COUNT(*) FROM x").fetchone()[0] == 10000


def test_executor_timeout_and_recovery(database):
    with pytest.raises(TimeoutError):
        execute(database, "SELECT SUM(a.a * b.a * c.a) FROM x a, x b, x c", ["x"], timeout=1)
    assert execute(database, "SELECT COUNT(*) AS n FROM x", ["x"], timeout=10)["rows"] == [
        {"n": 10000}
    ]


def test_worker_startup_is_not_query_time(database):
    # Spawning a fresh interpreter usually exceeds this budget; only the query is timed.
    result = execute(database, "SELECT COUNT(*) AS n FROM x", ["x"], timeout=0.3)
    assert result["rows"] == [{"n": 10000}]


@pytest.mark.parametrize(
    "sql", ["INSERT INTO x VALUES (1)", "SELECT * FROM read_csv('/etc/passwd')"]
)
def test_worker_independently_enforces_readonly_and_no_external_access(database, sql):
    import multiprocessing as mp

    from app.services.executor import _worker

    reader, writer = mp.Pipe(duplex=False)
    _worker(database, sql, 10, writer)
    result = reader.recv()
    reader.close()
    assert "error" in result
    with duckdb.connect(database, read_only=True) as conn:
        assert conn.execute("SELECT COUNT(*) FROM x").fetchone()[0] == 10000
