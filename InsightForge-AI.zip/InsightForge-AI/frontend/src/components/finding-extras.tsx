"use client";
import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bar,
  BarChart,
  Cell,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Finding, finalApi } from "@/lib/api";
import { AnalysisChart } from "./analysis-chart";
import { Button } from "./ui/button";
import { ErrorBox } from "./shared";
export function FindingExtras({
  finding: f,
  analysisId,
  datasetId,
  challengeTest = false,
}: {
  finding: Finding;
  analysisId: string;
  datasetId: string;
  challengeTest?: boolean;
}) {
  const cache = useQueryClient(),
    abort = useRef<AbortController | null>(null);
  const [busy, setBusy] = useState(false),
    [trace, setTrace] = useState<string[]>([]),
    [error, setError] = useState("");
  const challenges = useQuery({
    queryKey: ["challenges", analysisId],
    queryFn: () => finalApi.challenges(analysisId),
    enabled: !!analysisId,
  });
  const pins = useQuery({
    queryKey: ["pins", datasetId],
    queryFn: () => finalApi.pins(datasetId),
  });
  const pin = useMutation({
    mutationFn: ({
      kind,
      id,
      pinned,
    }: {
      kind: string;
      id: string;
      pinned: boolean;
    }) => finalApi.pin(kind, id, pinned),
    onSuccess: () => {
      void cache.invalidateQueries({ queryKey: ["pins", datasetId] });
      void cache.invalidateQueries({ queryKey: ["progress", datasetId] });
    },
  });
  const isPinned = (id: string) =>
    !!pins.data?.some((p) => p.item_id === id && p.pinned);
  const completedChallenge = challenges.data?.find(
    (c) => c.status === "completed",
  );
  const nextStep = !completedChallenge
    ? "Test this insight against alternative explanations with Challenge My Insight."
    : !isPinned(analysisId)
      ? "Pin this finding (and its challenge below) so it is included in the executive brief."
      : completedChallenge && !isPinned(completedChallenge.id)
        ? "Optionally pin the challenge below, then generate the executive brief."
        : "Ready: generate the executive brief.";
  useEffect(() => () => abort.current?.abort(), []);
  async function challenge() {
    setBusy(true);
    setTrace([]);
    setError("");
    abort.current = new AbortController();
    try {
      await finalApi.challenge(analysisId, abort.current.signal, (e) => {
        if (e.type === "error") setError(String(e.payload.message));
        setTrace((t) => [
          ...t,
          `${e.type}${e.payload.hypothesis_id ? `: ${e.payload.hypothesis_id}` : ""}`,
        ]);
      });
      await challenges.refetch();
      void cache.invalidateQueries({ queryKey: ["progress", datasetId] });
      void cache.invalidateQueries({ queryKey: ["analyses", datasetId] });
    } catch (e) {
      if (!abort.current.signal.aborted) setError(String(e));
    } finally {
      setBusy(false);
    }
  }
  const decomposition = (f.evidence?.decomposition || {}) as Record<
    string,
    unknown
  >;
  const numberOr = (value: unknown) =>
    typeof value === "number" && Number.isFinite(value) ? value : null;
  const mix = numberOr(decomposition.mix_residual);
  const observed = numberOr(decomposition.observed_margin_change);
  const targetOrders = numberOr(decomposition.target_n);
  const drivers = f.drivers || [];
  const material = drivers.filter((d) => Math.abs(d.margin_impact) >= 0.005);
  const steps = [
    ...material.map((d) => ({
      label: `${d.dimension} ${d.component.replaceAll("_", " ")}`,
      impact: d.margin_impact,
      perOrder: d.per_order_contribution ?? null,
      total: false,
    })),
    ...(mix !== null && Math.abs(mix) > 1e-9
      ? [
          {
            label: "Population mix",
            impact: mix,
            perOrder: targetOrders ? mix / targetOrders : null,
            total: false,
          },
        ]
      : []),
  ];
  let running = 0;
  const waterfall = steps.map((s) => {
    const before = running;
    running += s.impact;
    return { ...s, range: [before, running] as [number, number] };
  });
  if (waterfall.length > 0 && observed !== null)
    waterfall.push({
      label: "Observed change",
      impact: observed,
      perOrder: targetOrders ? observed / targetOrders : null,
      total: true,
      range: [0, observed],
    });
  const gbp = (v: number) =>
    `${v < 0 ? "−" : "+"}£${Math.abs(v).toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
  return (
    <div className="mt-5">
      {!challengeTest && (
        <p
          className="mb-3 rounded-lg border border-amber-200 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-900 px-4 py-2 text-sm"
          aria-live="polite"
        >
          <strong>Next step:</strong> {nextStep}{" "}
          {nextStep.startsWith("Ready") && (
            <a href="#brief" className="underline text-primary">
              Go to Generate Executive Brief ↑
            </a>
          )}
        </p>
      )}
      <div className="flex flex-wrap gap-3">
        {!challengeTest && (
          <>
            <Button disabled={busy || !analysisId} onClick={challenge}>
              {busy ? "Testing alternatives…" : "Challenge My Insight"}
            </Button>
            {busy && (
              <Button variant="outline" onClick={() => abort.current?.abort()}>
                Cancel challenge
              </Button>
            )}
            <Button
              variant="outline"
              disabled={pin.isPending || !pins.data}
              onClick={() =>
                pin.mutate({
                  kind: "analyses",
                  id: analysisId,
                  pinned: !isPinned(analysisId),
                })
              }
            >
              {isPinned(analysisId) ? "Unpin finding" : "Pin to brief"}
            </Button>
          </>
        )}
        {f.confidence && (
          <details className="border rounded-lg p-2 text-sm">
            <summary className="cursor-pointer">
              Confidence {f.confidence.score} · {f.confidence.label}
            </summary>
            <ul className="p-3">
              {f.confidence.breakdown.map((b) => (
                <li key={b.factor}>
                  {b.factor}: {b.contribution > 0 ? "+" : ""}
                  {b.contribution}
                </li>
              ))}
            </ul>
            <p>{f.confidence.method}</p>
            {f.evidence?.consistency && (
              <div className="mt-2 subtle text-xs">
                <p>
                  Cross-step agreement{" "}
                  {f.evidence.consistency.comparable
                    ? `${Math.round(f.evidence.consistency.score * 100)}%`
                    : "not comparable (neutral)"}
                  : {f.evidence.consistency.method}
                </p>
                <ul>
                  {f.evidence.consistency.signals.map((s, i) => (
                    <li key={i}>
                      {s.source} · {s.measure} implies margin{" "}
                      {s.margin_direction > 0 ? "up" : "down"}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </details>
        )}
      </div>
      {(error || pin.error || challenges.error) && (
        <ErrorBox error={error || pin.error || challenges.error} />
      )}
      {f.primary_chart && <AnalysisChart chart={f.primary_chart} />}
      {f.driver_summary && (
        <p className="border-l-4 border-primary p-4 font-medium">
          {f.driver_summary}
        </p>
      )}
      {waterfall.length > 0 && (
        <div className="panel p-4 mt-4">
          <h3 className="font-semibold">
            Margin bridge · contribution to total gross-margin change (GBP)
          </h3>
          <p className="subtle text-xs mt-1">
            Each bar is the change in total gross margin across
            {targetOrders !== null
              ? ` ${targetOrders.toLocaleString()} target-period orders`
              : " the target-period orders"}{" "}
            from one component, holding baseline per-order levels as the
            reference. Orange reduces margin; green increases it. Bars stack
            from zero to the observed change; population mix reconciles group
            composition.
            {drivers.length > material.length &&
              ` ${drivers.length - material.length} components with no measurable change are omitted.`}
          </p>
          <div
            className="h-80"
            role="figure"
            aria-label={`Margin bridge: ${waterfall
              .map((w) => `${w.label} ${gbp(w.impact)}`)
              .join("; ")}`}
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={waterfall}
                accessibilityLayer
                margin={{ top: 10, right: 20, bottom: 10, left: 10 }}
              >
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 9 }}
                  interval={0}
                  angle={-20}
                  textAnchor="end"
                  height={80}
                />
                <YAxis
                  tick={{ fontSize: 10 }}
                  tickFormatter={(v: number) => `£${v.toLocaleString()}`}
                  width={80}
                />
                <ReferenceLine y={0} stroke="#5b7066" />
                <Tooltip
                  formatter={(_value, _name, item) => {
                    const p = item.payload as (typeof waterfall)[number];
                    return [
                      `${gbp(p.impact)} total${p.perOrder !== null ? ` · ${gbp(p.perOrder)} per order` : ""}`,
                      p.total ? "Observed margin change" : "Contribution",
                    ];
                  }}
                />
                <Bar dataKey="range" isAnimationActive={false}>
                  {waterfall.map((d, i) => (
                    <Cell
                      key={i}
                      fill={
                        d.total
                          ? "#183d32"
                          : d.impact < 0
                            ? "#d8794b"
                            : "#227b66"
                      }
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
      {f.evidence && (
        <details className="panel p-5 mt-4">
          <summary className="cursor-pointer font-semibold">
            Inspect evidence & data-quality caveats
          </summary>
          <p className="subtle my-3">{f.evidence.count_definition}</p>
          {f.evidence.rows_scanned.map((r) => (
            <div key={r.table}>
              <p>
                {r.table}: {r.rows ?? "unavailable"} rows
              </p>
              <pre className="overflow-auto text-xs my-2">{r.sql}</pre>
            </div>
          ))}
          {f.evidence.supporting_steps.map((s) => (
            <div key={s.step_id} className="border-t py-3">
              <p>
                {s.step_id} · {s.returned_rows} returned rows
                {s.truncated ? " · truncated" : ""}
              </p>
              <pre className="overflow-auto text-xs my-2">{s.sql}</pre>
            </div>
          ))}
          {f.evidence.sample_sizes.map((s) => (
            <p key={s.group}>
              {s.group}: baseline {s.baseline}, target {s.target}
            </p>
          ))}
          {f.evidence.quality_issues.map((q, i) => (
            <p className="subtle" key={i}>
              {q.column}: {q.message} ({q.count} rows)
            </p>
          ))}
          <pre className="overflow-auto text-xs mt-3">
            {JSON.stringify(f.evidence.decomposition, null, 2)}
          </pre>
        </details>
      )}
      {busy && (
        <div className="panel p-4 mt-4" aria-live="polite">
          <h3>Challenge trace</h3>
          <p className="subtle">{trace.slice(-5).join(" → ")}</p>
        </div>
      )}
      {challenges.data?.map((c) => (
        <section className="panel p-5 mt-5" key={c.id}>
          <div className="flex justify-between gap-3">
            <h3 className="font-semibold">
              Confidence {c.result_json.original_confidence} →{" "}
              {c.result_json.revised_confidence ?? "…"}
            </h3>
            <Button
              variant="outline"
              disabled={pin.isPending || !pins.data}
              onClick={() =>
                pin.mutate({
                  kind: "challenges",
                  id: c.id,
                  pinned: !isPinned(c.id),
                })
              }
            >
              {isPinned(c.id) ? "Unpin challenge" : "Pin challenge"}
            </Button>
          </div>
          <p className="my-2">{c.result_json.verdict_summary}</p>
          <p className="subtle">
            {c.result_json.surviving_explanation}{" "}
            {c.result_json.confidence_explanation}
          </p>
          {c.result_json.error && <ErrorBox error={c.result_json.error} />}
          {c.result_json.hypotheses.map((h) => (
            <details className="border rounded-lg p-4 mt-3" key={h.id}>
              <summary className="cursor-pointer font-medium">
                {h.verdict} · {h.hypothesis}
              </summary>
              <p className="subtle mt-3">{h.rationale}</p>
              <p className="my-3">{h.explanation}</p>
              {h.chart && <AnalysisChart chart={h.chart} />}
              {h.steps.map((s) => (
                <pre
                  className="text-xs overflow-auto p-3 bg-muted my-2"
                  key={s.id}
                >
                  {s.generated_sql}
                </pre>
              ))}
            </details>
          ))}
          {c.result_json.quality_checks.map((q) => (
            <details className="border rounded p-4 mt-3" key={q.name}>
              <summary>
                {q.verdict} · {q.name}
              </summary>
              <p className="my-2">{q.explanation}</p>
              <pre className="text-xs overflow-auto">{q.sql}</pre>
            </details>
          ))}
        </section>
      ))}
    </div>
  );
}
