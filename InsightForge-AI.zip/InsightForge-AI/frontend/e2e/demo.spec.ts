import { test, expect } from "@playwright/test";
import { mkdir, readFile } from "node:fs/promises";
const question = "Why did profit margin decline in London in October?";
test("offline data-to-executive-brief flow", async ({ page }) => {
  const capture = async (name: string) => {
    if (process.env.CAPTURE_SCREENSHOTS) {
      await mkdir("../docs/screenshots", { recursive: true });
      await page.screenshot({
        path: `../docs/screenshots/${name}.png`,
        fullPage: true,
      });
    }
  };
  await page.goto("/");
  await page
    .getByRole("button", { name: "Load demo dataset", exact: true })
    .click();
  await expect(page).toHaveURL(/\/datasets\/[\w-]+$/, { timeout: 120000 });
  await expect(
    page.getByRole("heading", {
      name: "UK Retail Operations",
      exact: true,
      level: 1,
    }),
  ).toBeVisible({ timeout: 60000 });
  await expect(
    page.getByText(/delivered orders missing timestamps/i).first(),
  ).toBeVisible({ timeout: 60000 });
  await expect(page.getByText(/23/).first()).toBeVisible();
  await expect(page.getByText(/47/).first()).toBeVisible();
  await expect(
    page.getByText(/Preparing a grounded profile summary/),
  ).toBeHidden({ timeout: 60000 });
  // Orientation: breadcrumb, mode badge, and journey tracker.
  const journey = page.getByRole("navigation", { name: "Analysis journey" });
  await expect(journey).toBeVisible();
  await expect(journey.getByRole("link", { name: /Inspect health/ })).toHaveAttribute(
    "aria-current",
    "step",
  );
  await expect(
    page.getByRole("navigation", { name: "Breadcrumb" }).getByText("Data library"),
  ).toBeVisible();
  await expect(page.getByRole("status", { name: /Mode: Offline replay/ })).toBeVisible();
  await expect(page).toHaveTitle(/Data health · UK Retail Operations/);
  await capture("01-health");
  await page.getByRole("link", { name: /Next: Ask a question/ }).click();
  await expect(page.getByText(/Offline replay mode\./)).toBeVisible();
  await page.getByRole("button", { name: "Use the demo question", exact: true }).click();
  await expect(
    page.getByPlaceholder("Ask a business question about this dataset…"),
  ).toHaveValue(question);
  await expect(
    page.getByRole("button", { name: "Generate Executive Brief", exact: true }),
  ).toBeDisabled();
  await page.getByRole("button", { name: "Analyze", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Challenge My Insight", exact: true }),
  ).toBeVisible({ timeout: 90000 });
  await expect(page).toHaveURL(/\?analysis=[\w-]+$/);
  await expect(page.getByText(/Next step: Test this insight/)).toBeVisible();
  await expect(page.getByText(/primary: Peak delivery_cost/)).toBeVisible();
  await expect(page.getByText(/18.7%/).first()).toBeVisible();
  await expect(page.getByText(/Margin bridge/)).toBeVisible();
  await capture("02-finding");
  const pngDownload = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Export PNG", exact: true })
    .first()
    .click();
  const png = await pngDownload;
  expect(png.suggestedFilename()).toBe("insightforge-chart.png");
  const pngPath = await png.path();
  const header = (await readFile(pngPath!)).subarray(0, 8).toString("hex");
  expect(header).toBe("89504e470d0a1a0a");
  await page
    .getByRole("button", { name: "Challenge My Insight", exact: true })
    .click();
  await expect(page.getByText(/alternatives refuted/)).toBeVisible({
    timeout: 120000,
  });
  await expect(page.getByText(/Deduplicated \+ valid dates/)).toBeVisible();
  await expect(page.getByText("Challenge test", { exact: true }).first()).toBeVisible({
    timeout: 30000,
  });
  await capture("03-challenge");
  await page.getByRole("button", { name: "Pin to brief", exact: true }).click();
  await page
    .getByRole("button", { name: "Pin challenge", exact: true })
    .first()
    .click();
  await expect(
    page.getByRole("button", { name: "Unpin finding", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Unpin challenge", exact: true }).first(),
  ).toBeVisible();
  await expect(page.getByText(/1 finding and 1 challenge pinned/)).toBeVisible();
  await page
    .getByRole("button", { name: "Generate Executive Brief", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Executive brief", exact: true }),
  ).toBeVisible({ timeout: 60000 });
  await expect(page.getByText("Grounding: verified")).toBeVisible();
  await expect(page.getByText("Evidence behind this brief")).toBeVisible();
  await expect(
    page
      .getByRole("navigation", { name: "Analysis journey" })
      .getByRole("link", { name: /Executive brief/ }),
  ).toHaveAttribute("aria-current", "step");
  await capture("04-brief");
  // Structured sections are edited in token form, so unchanged evidence stays verified.
  await page
    .getByRole("button", { name: "Edit recommended actions", exact: true })
    .click();
  await page.getByRole("button", { name: "Add action", exact: true }).click();
  await page.getByLabel("Action 3 owner role").fill("Finance");
  await page
    .getByLabel("Action 3 expected impact")
    .fill("Track peak delivery cost against the baseline every month.");
  await page.getByRole("button", { name: "Save section", exact: true }).click();
  await expect(page.getByText("Finance · Medium")).toBeVisible();
  await page.getByRole("button", { name: "Edit evidence", exact: true }).click();
  await page.getByRole("button", { name: "Save section", exact: true }).click();
  await expect(page.getByText("Grounding: verified")).toBeVisible();
  const downloadPromise = page.waitForEvent("download");
  await page.getByRole("link", { name: "Download PDF", exact: true }).click();
  const download = await downloadPromise;
  expect(await download.path()).toBeTruthy();
  const link = await page
    .getByRole("link", { name: "Download Markdown", exact: true })
    .getAttribute("href");
  const md = await (await page.request.get(link!)).text();
  for (const section of [
    "Situation",
    "Evidence",
    "Root Cause",
    "Business Impact",
    "Recommended Actions",
  ])
    expect(md).toContain("## " + section);
  await page.goto("/audit");
  await expect(
    page.getByRole("heading", { name: "Every model call, accounted for." }),
  ).toBeVisible();
  await expect(page.getByText("Correction attempts")).toBeVisible({
    timeout: 30000,
  });
  await expect(page.getByText(/Showing \d+ of \d+ calls/)).toBeVisible();
  await capture("05-audit");
});
