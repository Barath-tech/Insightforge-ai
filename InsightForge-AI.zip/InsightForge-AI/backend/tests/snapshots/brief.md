# Test brief
01 January 2024 | Test dataset | Leaders

## Situation
Situation text

## Evidence

## Root Cause
Root text

## Business Impact
Impact text

## Recommended Actions

### Data quality & confidence
Limited evidence


Grounding: verified

<!-- APPENDIX -->
## SQL Appendix
