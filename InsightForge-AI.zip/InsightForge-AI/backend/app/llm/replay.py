"""Content-addressed exact prompt replay. Never falls through to the network."""

import hashlib
import json
from pathlib import Path

from app.core.config import settings

VOLATILE = {
    "analysis_id",
    "dataset_id",
    "query_run_id",
    "created_at",
    "completed_at",
    "updated_at",
    "elapsed_ms",
    "latency_ms",
}
# Model name the committed scripted fixtures are keyed by; offline demo/tests pin it.
FIXTURE_MODEL = "gpt-4.1"


def canonical(value):
    if isinstance(value, dict):
        return {
            k: canonical(v)
            for k, v in sorted(value.items())
            if k not in VOLATILE and not (k == "id" and isinstance(v, str) and len(v) == 36)
        }
    if isinstance(value, list):
        return [canonical(v) for v in value]
    return value


def cache_key(purpose, context, response_model):
    from app.llm.client import PROMPT, PROMPT_VERSION

    payload = {
        "purpose": purpose,
        "context": canonical(context),
        "schema": response_model.model_json_schema(),
        "prompt": PROMPT,
        "prompt_version": PROMPT_VERSION,
        "model": settings.openai_model,
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()


class ReplayTransport:
    def __init__(self, mode="replay", upstream=None, directory=None, provenance="live_recording"):
        self.mode, self.upstream, self.provenance = mode, upstream, provenance
        self.directory = Path(directory or settings.data_dir / "demo_cache")

    async def request(self, purpose, context, response_model):
        from app.llm.client import LLMError

        path = self.directory / (cache_key(purpose, context, response_model) + ".json")
        if self.mode == "replay":
            if not path.exists():
                raise LLMError(
                    "replay_miss",
                    "No exact replay for this request. Use the scripted "
                    "demo question or record this flow with a live key.",
                )
            value = json.loads(path.read_text())
            return value["response"]
        response = await self.upstream.request(purpose, context, response_model)
        raw = response if isinstance(response, dict) else response.output_parsed.model_dump()
        response_model.model_validate(raw)
        self.directory.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {"purpose": purpose, "provenance": self.provenance, "response": raw},
                indent=2,
                default=str,
            )
        )
        return response
