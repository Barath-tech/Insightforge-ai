"""Small explicit pipeline; asynchronous model calls and isolated synchronous SQL work."""

import asyncio
import threading

from sqlmodel import Session

from app.agent import store
from app.agent.checks import check_result, preserve_filters
from app.agent.context import bound_result, model_result
from app.agent.contracts import Finding, Plan, SQLProposal
from app.analysis.charts import select_chart
from app.analysis.evidence import build_evidence
from app.analysis.outliers import enrich_chart
from app.core.config import settings
from app.llm.client import Client, LLMError
from app.models.analysis import AnalysisStep
from app.models.metadata import now
from app.services.grounding import check_finding
from app.services.query import submit
from app.services.sql_guard import SAFE_FUNCTIONS


async def run(engine, dataset, schema, analysis, transport, events, preset_plan=None):
    cancel = threading.Event()
    llm = Client(engine, dataset.id, transport, analysis.id)
    status, worker = "failed", None
    loop = asyncio.get_running_loop()
    evidence, summaries = {}, {}
    successful_records = []

    async def persist(**kwargs):
        await asyncio.to_thread(store.update, engine, analysis.id, **kwargs)

    try:
        await persist(status="running")
        context = {
            "question": analysis.question,
            "schema": schema,
            "max_steps": settings.agent_max_steps,
            "allowed_functions": sorted(SAFE_FUNCTIONS),
        }
        plan = preset_plan or await llm.generate("plan", context, Plan)
        if len(plan.steps) > settings.agent_max_steps:
            raise LLMError("plan_limit", "Plan exceeds the configured step limit.")
        await persist(plan_json=plan.model_dump())
        await events.emit("plan", plan.model_dump())
        if not plan.answerable:
            raise LLMError("unsupported", "Question cannot be answered from the available schema.")
        for step in plan.steps:
            attempts = []
            success = False
            original_sql = None
            for attempt in range(1, 4):
                base = {"step_id": step.id, "attempt_no": attempt, "purpose": step.purpose}
                await events.emit("step_started", base)
                previous = {k: summaries[k] for k in step.depends_on if k in summaries}
                proposal = await llm.generate(
                    "sql" if attempt == 1 else "correction",
                    {
                        **context,
                        "plan": plan.model_dump(),
                        "step": step.model_dump(),
                        "previous_results": previous,
                        "previous_attempts": attempts,
                    },
                    SQLProposal,
                )
                if original_sql is None:
                    original_sql = proposal.sql
                record = AnalysisStep(
                    analysis_id=analysis.id,
                    step_id=step.id,
                    attempt_no=attempt,
                    purpose=step.purpose,
                    rationale=proposal.rationale,
                    generated_sql=proposal.sql,
                )
                await asyncio.to_thread(store.save, engine, record)
                await events.emit("sql_generated", {**base, **proposal.model_dump()})

                def validated(value):
                    asyncio.run_coroutine_threadsafe(
                        events.emit("validation", {**base, **value}), loop
                    ).result()

                def execute_attempt():
                    with Session(engine) as session:
                        return submit(
                            session,
                            dataset,
                            proposal.sql,
                            source="agent",
                            cancel=cancel,
                            on_validation=validated,
                            policy_check=lambda normalized: preserve_filters(
                                original_sql, normalized
                            ),
                        )

                worker = asyncio.create_task(asyncio.to_thread(execute_attempt))
                try:
                    outcome = await asyncio.shield(worker)
                except asyncio.CancelledError:
                    cancel.set()
                    outcome = await worker  # Join/terminate query worker before releasing capacity.
                    record.query_run_id = outcome["run"]["id"]
                    record.status, record.error = "cancelled", "Analysis cancelled."
                    record.completed_at = now()
                    await asyncio.to_thread(store.save, engine, record)
                    raise
                worker = None
                result, query = outcome["result"], outcome["run"]
                if result is not None:
                    result = bound_result(result)
                    result["chart"] = select_chart(result, step.purpose)
                    result["outliers"] = enrich_chart(result, result["chart"])
                record.query_run_id = query["id"]
                record.normalized_sql = outcome["normalized_sql"]
                record.validation_json = {
                    "status": "failed" if query["status"] == "validation_error" else "ok"
                }
                problems = check_result(result, proposal, plan) if result else [query["error"]]
                record.result_json = result
                record.execution_summary_json = {
                    "status": query["status"],
                    "row_count": query["row_count"],
                    "elapsed_ms": query["elapsed_ms"],
                    "truncated": bool(result and result["truncated"]),
                    "checks": problems,
                }
                record.status = "suspicious" if problems and result else query["status"]
                record.error = "; ".join(p for p in problems if p) or None
                record.completed_at = now()
                await asyncio.to_thread(store.save, engine, record)
                await events.emit("execution", {**base, **record.model_dump(mode="json")})
                if not problems:
                    successful_records.append(record)
                    evidence[(step.id, attempt)] = result
                    summaries[step.id] = {"attempt": attempt, **model_result(result)}
                    success = True
                    await events.emit("step_done", {**base, "status": "ok"})
                    break
                attempts.append({"sql": proposal.sql, "error": record.error, "attempt": attempt})
                if proposal.no_matching_data and result is not None and not result["rows"]:
                    break
                if attempt < 3:
                    await events.emit(
                        "correction", {**base, "status": "retrying", "error": record.error}
                    )
            if not success:
                await events.emit("step_done", {**base, "status": "failed"})
                raise LLMError(
                    "insufficient_evidence",
                    "Required step failed or has insufficient evidence; see attempts.",
                )
        finding_context = {
            "question": analysis.question,
            "plan": plan.model_dump(),
            "evidence": summaries,
        }
        for retry in range(2):
            finding = await llm.generate("finding", finding_context, Finding)
            grounded = check_finding(finding, evidence)
            if grounded["grounding_status"] == "verified":
                break
            finding_context["grounding_failures"] = grounded["grounding_errors"]
        bundle = await asyncio.to_thread(
            build_evidence,
            engine,
            dataset,
            schema,
            successful_records,
            grounded,
            retry + sum(r.attempt_no - 1 for r in successful_records),
        )
        grounded["evidence"] = bundle
        grounded["confidence"] = bundle["confidence"]
        grounded["drivers"] = (bundle["decomposition"] or {}).get("drivers", [])
        ranked = [d for d in grounded["drivers"] if d["rank"] in {"primary", "secondary"}]
        if ranked:
            grounded["driver_summary"] = "; ".join(
                f"{d['rank']}: {d['dimension']} {d['component']} "
                + (f"{d['change_pct']:+.1f}%" if d["change_pct"] is not None else "baseline zero")
                + f", margin impact £{d['margin_impact']:+.2f}"
                for d in ranked
            )
        grounded["outliers"] = [o for r in evidence.values() for o in r.get("outliers", [])]
        grounded["primary_chart"] = next(
            (r["chart"] for r in evidence.values() if r.get("chart", {}).get("type") == "line"),
            next((r["chart"] for r in evidence.values() if r.get("chart")), None),
        )
        await persist(finding_json=grounded, grounding_status=grounded["grounding_status"])
        await events.emit("finding", grounded)
        status = "completed"
        await persist(status=status)
    except asyncio.CancelledError:
        cancel.set()
        status = "cancelled"
        await persist(status=status, error="Analysis cancelled.")
        raise
    except Exception as exc:
        message = str(exc) if isinstance(exc, LLMError) else "Analysis failed. Please try again."
        await persist(status="failed", error=message)
        await events.emit(
            "error",
            {
                "status": "failed",
                "message": message,
                "code": exc.code if isinstance(exc, LLMError) else "internal",
            },
        )
    finally:
        cancel.set()
        await events.emit("done", {"status": status})
