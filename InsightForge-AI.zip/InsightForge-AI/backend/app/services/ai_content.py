"""Bounded TTL cache coalesces rerenders and concurrent requests; explicit refresh supported."""

import asyncio
import time
from collections import OrderedDict

from app.agent.contracts import Narrative, Suggestions
from app.llm.client import Client, LLMError
from app.services.grounding import check_narrative, fallback_narrative
from app.services.schema import Fact

_cache = OrderedDict()
_locks = {}


async def content(engine, dataset, schema, transport, purpose, refresh=False):
    key = (str(engine.url), dataset.id, purpose)
    # A single-process app; bounded cache and no session held across awaits.
    lock = _locks.setdefault(key, asyncio.Lock())
    try:
        async with lock:
            cached = _cache.get(key)
            if cached and (time.monotonic() - cached[0] < (5 if refresh else 900)):
                return cached[1]
            client = Client(engine, dataset.id, transport)
            if purpose == "narrative":
                facts = [Fact.model_validate(f) for f in schema["facts"]]
                context = {"facts": schema["facts"], "issues": schema["issues"]}
                result = None
                try:
                    for attempt in range(2):
                        narrative = await client.generate("narrative", context, Narrative)
                        result = check_narrative(narrative, facts)
                        if not result["errors"]:
                            break
                        context["grounding_failures"] = result["errors"]
                    if result["errors"]:
                        result = fallback_narrative(facts, "AI grounding failed after repair.")
                except LLMError as exc:
                    result = fallback_narrative(facts, str(exc))
            else:
                clean = [t for t in schema["tables"] if t["role"] == "clean"]
                table = clean[0]
                name, cols = table["name"], [c["name"] for c in table["columns"]]
                numeric = next(
                    (
                        c["name"]
                        for c in table["columns"]
                        if c["semantic_type"] in {"numeric", "currency"}
                    ),
                    None,
                )
                category = next(
                    (c["name"] for c in table["columns"] if c["semantic_type"] == "categorical"),
                    cols[0],
                )
                date = next(
                    (c["name"] for c in table["columns"] if c["semantic_type"] == "datetime"), None
                )
                fallback = [
                    f"How many rows are in {name}?",
                    f"How are rows distributed across {category} in {name}?",
                    f"How many missing values does each column in {name} have?",
                    (
                        f"How does average {numeric} differ by {category} in {name}?"
                        if numeric
                        else f"Which values of {category} occur most often in {name}?"
                    ),
                    (
                        f"How does the row count change over {date} in {name}?"
                        if date
                        else f"How many duplicate rows are present in {name}?"
                    ),
                ]
                result = {
                    "questions": [{"question": q, "table": name, "columns": []} for q in fallback],
                    "status": "fallback",
                }
                try:
                    generated = await client.generate(
                        "suggestions", {"schema": schema}, Suggestions
                    )
                    allowed = {t["name"]: {c["name"] for c in t["columns"]} for t in clean}
                    if all(
                        q.table in allowed
                        and set(q.columns) <= allowed[q.table]
                        and q.question.endswith("?")
                        for q in generated.questions
                    ):
                        result = {**generated.model_dump(), "status": "generated"}
                except LLMError:
                    pass
            _cache[key] = (time.monotonic(), result)
            _cache.move_to_end(key)
            while len(_cache) > 128:
                _cache.popitem(last=False)
            return result
    finally:
        # Keep locks with waiting callers; discard once unused.
        if not lock.locked() and not getattr(lock, "_waiters", None):
            _locks.pop(key, None)
