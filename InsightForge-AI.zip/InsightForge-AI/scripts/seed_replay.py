"""Seed honest scripted demo recordings by executing the full application services."""

import asyncio
import json
import tempfile
from pathlib import Path

from app.agent import store
from app.agent.events import Events
from app.agent.pipeline import run
from app.challenge.service import challenge_run
from app.core.config import settings
from app.llm.replay import FIXTURE_MODEL, ReplayTransport
from app.main import app  # noqa: F401 -- register all additive models
from app.models.analysis import Analysis
from app.models.final import Challenge, Pin
from app.report.service import create_brief, render_markdown, render_pdf
from app.routers.final import BriefRequest
from app.services.ai_content import content
from app.services.ingest import ingest
from app.services.schema import describe
from sqlmodel import Session, SQLModel, create_engine

from scripts.demo_responses import QUESTION, DemoResponses


async def seed(replay=False):
    # Scripted fixtures are always keyed by the fixture model, whatever .env targets live.
    settings.openai_model = FIXTURE_MODEL
    with tempfile.TemporaryDirectory() as directory:
        engine = create_engine(
            f"sqlite:///{directory}/metadata.sqlite", connect_args={"check_same_thread": False}
        )
        SQLModel.metadata.create_all(engine)
        with Session(engine) as session:
            path = settings.data_dir / "samples" / "UK Retail Operations.csv"
            dataset = ingest(path, path.name, session)
            schema = describe(dataset, session)
        transport = ReplayTransport(
            "replay" if replay else "record", DemoResponses(), provenance="scripted_fixture"
        )
        await content(engine, dataset, schema, transport, "narrative")
        await content(engine, dataset, schema, transport, "suggestions")
        analysis = Analysis(dataset_id=dataset.id, question=QUESTION)
        store.save(engine, analysis)
        await run(
            engine, dataset, schema, analysis, transport, Events(analysis.id, asyncio.Queue())
        )
        with Session(engine) as session:
            original = session.get(Analysis, analysis.id)
            if original.status != "completed":
                raise RuntimeError(str(store.detail(engine, analysis.id)))
            finding = original.finding_json
        print("Finding", finding["grounding_status"], "confidence", finding["confidence"]["score"])
        print(finding.get("driver_summary"))
        challenge = Challenge(analysis_id=analysis.id)
        store.save(engine, challenge)

        async def emit(kind, payload):
            if kind in {"hypothesis", "quality_check", "error"}:
                print(kind, payload.get("verdict", payload.get("message")))

        await challenge_run(engine, dataset, schema, original, transport, challenge, emit)
        if challenge.status != "completed":
            raise RuntimeError(challenge.result_json)
        store.save(
            engine, Pin(item_id=analysis.id, kind="analyses", dataset_id=dataset.id, pinned=True)
        )
        store.save(
            engine, Pin(item_id=challenge.id, kind="challenges", dataset_id=dataset.id, pinned=True)
        )
        brief = await create_brief(engine, dataset, BriefRequest(), transport)
        print("Brief", brief.grounding_json)
        out = Path("work/demo-proof")
        out.mkdir(parents=True, exist_ok=True)
        (out / "brief.pdf").write_bytes(render_pdf(brief))
        (out / "brief.md").write_text(render_markdown(brief))
        (out / "finding.json").write_text(json.dumps(finding, indent=2))
        (out / "challenge.json").write_text(json.dumps(challenge.result_json, indent=2))
        Path(dataset.duckdb_path).unlink(missing_ok=True)
        engine.dispose()


if __name__ == "__main__":
    import sys

    asyncio.run(seed("--replay" in sys.argv))
