from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    data_dir: Path = Path(__file__).resolve().parents[3] / "data"
    max_upload_mb: int = 50
    max_rows: int = 100_000
    query_timeout_seconds: float = 5
    query_max_rows: int = 1000
    cors_origins: list[str] = ["http://localhost:3000"]
    openai_api_key: str = ""
    demo_replay: Literal["off", "record", "replay"] = "off"
    openai_model: str = "gpt-4.1"
    # Optional OpenAI-compatible gateway (for example a LiteLLM proxy); empty = api.openai.com.
    openai_base_url: str = ""
    # Extra PEM bundle trusted for the model endpoint, for TLS-inspecting proxies/gateways.
    openai_ca_bundle: str = ""
    # Last resort for gateways with untrusted certificates; prefer OPENAI_CA_BUNDLE.
    openai_verify_ssl: bool = True

    llm_timeout_seconds: float = Field(default=45, ge=1, le=120)
    llm_transport_retries: int = Field(default=1, ge=0, le=2)
    llm_max_output_tokens: int = Field(default=4000, ge=256, le=8000)
    llm_context_chars: int = Field(default=48000, ge=2000, le=100000)
    agent_max_steps: int = Field(default=5, ge=1, le=5)
    ask_per_minute: int = Field(default=6, ge=1, le=60)
    ask_concurrency: int = Field(default=2, ge=1, le=8)


settings = Settings()
