"""Trusted metadata inspection and table-scoped deterministic profile facts."""

from copy import deepcopy
from typing import Literal

import duckdb
from pydantic import BaseModel

from app.models.metadata import DatasetProfile
from app.services.ingest import quote


class Fact(BaseModel):
    id: str
    table: str
    column: str | None
    label: str
    value: int | float | str
    category: Literal["number", "date", "identifier"] = "number"


def facts_from_profile(profile):
    facts = []
    for table, p in profile.get("tables", {}).items():

        def add(key, label, value, column=None, category="number"):
            if value is not None:
                facts.append(
                    Fact(
                        id=f"{table}:{key}",
                        table=table,
                        column=column,
                        label=label,
                        value=value,
                        category=category,
                    )
                )

        add("rows", "Total imported rows", p.get("row_count"))
        id_col = next(
            (c["name"] for c in p.get("columns", []) if c.get("semantic_type") == "id"), None
        )
        if id_col:
            add("unique_ids", f"Unique identifiers in {id_col}", p.get("unique_ids"), id_col)
        for c in p.get("columns", []):
            name = c["name"]
            if c.get("semantic_type") == "categorical":
                add(f"distinct:{name}", f"Distinct values in {name}", c.get("distinct_count"), name)
            for label, value in zip(["earliest", "latest"], c.get("date_range", [])):
                add(f"{label}:{name}", f"{label.title()} {name}", value, name, "date")
        for issue in p.get("issues", []):
            add(
                f"issue:{issue['code']}:{issue['column']}",
                f"{issue['message']} ({issue['column']})",
                issue["count"],
                issue["column"],
            )
    return facts


def describe(dataset, session):
    stored = session.get(DatasetProfile, dataset.id)
    profile = deepcopy(stored.profile_json) if stored else {"tables": {}}
    tables = []
    # These are application-owned statements, never model SQL. No external access.
    with duckdb.connect(
        dataset.duckdb_path,
        read_only=True,
        config={
            "enable_external_access": "false",
            "autoload_known_extensions": "false",
            "autoinstall_known_extensions": "false",
            "threads": "1",
        },
    ) as conn:
        actual = {r[0] for r in conn.execute("SHOW TABLES").fetchall()}
        for name in dataset.table_names:
            if name not in actual:
                continue
            clean = name[4:] if name.startswith("raw_") and name[4:] in actual else name
            p = profile.setdefault("tables", {}).setdefault(clean, {})
            if name == clean:
                # Older profiles may omit metadata. Derive only missing deterministic facts.
                if "row_count" not in p:
                    p["row_count"] = conn.execute(f"SELECT COUNT(*) FROM {quote(name)}").fetchone()[
                        0
                    ]
                if not p.get("columns"):
                    p["columns"] = []
                    for col, dtype, *_ in conn.execute(f"DESCRIBE {quote(name)}").fetchall():
                        kind = (
                            "id"
                            if col == "id" or col.endswith("_id")
                            else ("datetime" if "DATE" in dtype or "TIMESTAMP" in dtype else None)
                        )
                        cp = {"name": col, "semantic_type": kind}
                        if kind == "id" and "unique_ids" not in p:
                            p["unique_ids"] = conn.execute(
                                f"SELECT COUNT(DISTINCT {quote(col)}) FROM {quote(name)}"
                            ).fetchone()[0]
                        if kind == "datetime":
                            cp["date_range"] = [
                                str(v) if v is not None else None
                                for v in conn.execute(
                                    f"SELECT MIN({quote(col)}), MAX({quote(col)}) "
                                    f"FROM {quote(name)}"
                                ).fetchone()
                            ]
                        p["columns"].append(cp)
            columns = []
            semantic = {c["name"]: c for c in p.get("columns", [])}
            for col, dtype, *_ in conn.execute(f"DESCRIBE {quote(name)}").fetchall():
                cp = semantic.get(col, {})
                kind = cp.get("semantic_type")
                # Only low-cardinality categories receive samples, never free text/IDs.
                samples = []
                if name == clean and kind == "categorical":
                    samples = [
                        str(r[0])[:80]
                        for r in conn.execute(
                            f"SELECT DISTINCT {quote(col)} FROM {quote(name)} "
                            f"WHERE {quote(col)} IS NOT NULL ORDER BY 1 LIMIT 5"
                        ).fetchall()
                    ]
                columns.append(
                    {"name": col, "type": dtype, "semantic_type": kind, "samples": samples}
                )
            tables.append(
                {
                    "name": name,
                    "role": "clean" if name == clean else "raw",
                    "clean_table": clean,
                    "raw_table": f"raw_{clean}",
                    "columns": columns,
                    "column_mapping": p.get("column_mapping", {}),
                    "cleaning_notes": p.get("cleaning_log", [])[:60],
                }
            )
    return {
        "dataset": {"id": dataset.id, "name": dataset.name},
        "tables": tables,
        "facts": [f.model_dump() for f in facts_from_profile(profile)],
        "issues": [
            {"table": t, **{k: v for k, v in i.items() if k != "samples"}}
            for t, p in profile.get("tables", {}).items()
            for i in p.get("issues", [])
        ],
    }
