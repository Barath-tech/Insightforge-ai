/** SSE framing independent of network chunk boundaries. The API validates each JSON envelope. */
export async function* readSSE(
  body: ReadableStream<Uint8Array>,
  signal?: AbortSignal,
): AsyncGenerator<unknown> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let data: string[] = [];
  const abort = () => {
    void reader.cancel();
  };
  signal?.addEventListener("abort", abort);
  function line(value: string): unknown | undefined {
    if (value === "") {
      if (!data.length) return;
      const result = JSON.parse(data.join("\n"));
      data = [];
      return result;
    }
    if (value.startsWith("data:")) data.push(value.slice(5).replace(/^ /, ""));
  }
  try {
    while (true) {
      if (signal?.aborted) throw new DOMException("Cancelled", "AbortError");
      const { value, done } = await reader.read();
      buffer += done
        ? decoder.decode()
        : decoder.decode(value, { stream: true });
      if (buffer.length > 4_000_000)
        throw new Error("Stream event is too large");
      let index: number;
      while ((index = buffer.indexOf("\n")) >= 0) {
        const event = line(buffer.slice(0, index).replace(/\r$/, ""));
        buffer = buffer.slice(index + 1);
        if (event !== undefined) yield event;
      }
      if (done) {
        if (signal?.aborted) throw new DOMException("Cancelled", "AbortError");
        if (buffer) line(buffer.replace(/\r$/, ""));
        const final = line("");
        if (final !== undefined) yield final;
        break;
      }
    }
  } finally {
    signal?.removeEventListener("abort", abort);
    await reader.cancel().catch(() => undefined);
    reader.releaseLock();
  }
}
