"""Disclosed scripted transport used ONLY to seed offline demonstration recordings.
No planted numeric facts: response numbers are copied from real runtime evidence.
This is not a claim to contain responses recorded from a live OpenAI model.
"""

from app.services.grounding import format_number

QUESTION = "Why did profit margin decline in London in October?"


def plan(steps, intent="why"):
    return {
        "intent": intent,
        "answerable": True,
        "explanation": "Compare measured periods and components.",
        "metrics": [
            {
                "name": "gross_margin",
                "definition": "revenue - cogs - delivery_cost - refund_amount",
                "unit": "GBP",
                "nonnegative": False,
            }
        ],
        "dimensions": ["delivery_slot"],
        "filters": [],
        "time_range": "Target month versus preceding months in the same year",
        "steps": [
            {"id": s, "purpose": p, "expected_output": p, "depends_on": []} for s, p in steps
        ],
        "assumptions": [
            "Average gross margin per order in GBP; not margin percentage.",
            "Retained duplicates; invalid dates excluded. Observational evidence.",
        ],
    }


def component_sql(table):
    return f'''SELECT CASE WHEN EXTRACT(MONTH FROM order_date)=10 THEN 'target'
        ELSE 'baseline' END AS period,
        delivery_slot AS dimension, COUNT(*) AS n, SUM(revenue) AS revenue, SUM(cogs) AS cogs,
        SUM(delivery_cost) AS delivery_cost, SUM(refund_amount) AS refund_amount
        FROM "{table}" WHERE city='London' AND EXTRACT(YEAR FROM order_date)=2024
        AND EXTRACT(MONTH FROM order_date)<=10 GROUP BY 1,2 ORDER BY 1,2'''


class DemoResponses:
    async def request(self, purpose, context, response_model):
        if purpose == "narrative":
            facts = [
                f
                for f in context["facts"]
                if f["id"].endswith((":rows", ":unique_ids"))
                or ":issue:duplicate_ids:" in f["id"]
                or ":issue:missing_delivery_timestamp:" in f["id"]
            ]
            return {
                "introduction": "Profile summary by table.",
                "claims": [
                    {"fact_id": f["id"], "label": f["label"], "value": str(f["value"])}
                    for f in facts
                ],
            }
        schema = context.get("schema", {})
        table = next(
            (t["name"] for t in schema.get("tables", []) if t["role"] == "clean"),
            "uk_retail_operations",
        )
        if purpose == "suggestions":
            return {
                "questions": [
                    {"question": q, "table": table, "columns": []}
                    for q in [
                        QUESTION,
                        "Which cities have the highest refund rates?",
                        "How does delivery cost change by month?",
                        "Which stores account for the most refunds?",
                        "How many duplicate orders are present?",
                    ]
                ]
            }
        if purpose == "plan":
            if context["question"] != QUESTION:
                return {
                    **plan([]),
                    "answerable": False,
                    "explanation": "Use the scripted demo question.",
                }
            return plan(
                [
                    ("components", "Compare margin component sums by slot"),
                    ("trend", "Peak delivery cost through the target month"),
                    ("refunds", "Refund rates by city"),
                ]
            )
        if purpose in {"sql", "correction"}:
            step = context["step"]["id"]
            if step == "components":
                query = component_sql(table)
                if purpose == "sql":
                    query = query.replace("SUM(delivery_cost)", "SUM(delivery_fee_typo)")
            elif step == "trend":
                query = f'''SELECT DATE_TRUNC('month',order_date) AS period_start,
                  AVG(delivery_cost) AS delivery_cost FROM "{table}" WHERE city='London'
                  AND delivery_slot='Peak' AND EXTRACT(YEAR FROM order_date)=2024
                  AND EXTRACT(MONTH FROM order_date)<=10 GROUP BY 1 ORDER BY 1'''
            elif step == "refunds":
                query = f'''SELECT city, AVG(CAST(refund_flag AS DOUBLE)) AS refund_rate,
                  SUM(refund_amount) AS refund_amount FROM "{table}" GROUP BY city ORDER BY city'''
            else:
                metrics = {
                    "seasonality": "AVG(delivery_cost)",
                    "product_mix": "AVG(CASE WHEN category='Electronics' THEN 1.0 ELSE 0.0 END)",
                    "concentration": "AVG(CASE WHEN channel='Online' THEN 1.0 ELSE 0.0 END)",
                    "pricing": "AVG(unit_price)",
                }
                metric = metrics[step]
                # Prior-year October data is absent in the demo, so seasonality is inconclusive.
                bfilter = (
                    "EXTRACT(YEAR FROM order_date)=2023 AND EXTRACT(MONTH FROM order_date)=10"
                    if step == "seasonality"
                    else "EXTRACT(YEAR FROM order_date)=2024 AND EXTRACT(MONTH FROM order_date)<10"
                )
                query = f'''WITH b AS (SELECT {metric} AS value, COUNT(*) AS n FROM "{table}"
                  WHERE city='London' AND {bfilter}),
                  t AS (SELECT {metric} AS value, COUNT(*) AS n FROM "{table}" WHERE city='London'
                  AND EXTRACT(YEAR FROM order_date)=2024 AND EXTRACT(MONTH FROM order_date)=10)
                  SELECT b.value AS baseline_value,t.value AS target_value,b.n AS baseline_n,
                  t.n AS target_n FROM b,t'''
            return {
                "sql": query,
                "rationale": "Compare the prespecified populations using guarded SQL.",
                "measure_columns": [],
                "nonnegative_columns": [],
                "no_matching_data": False,
            }
        if purpose == "finding":
            evidence = context["evidence"]
            step = "trend" if "trend" in evidence else next(iter(evidence))
            r = evidence[step]
            row = r["rows"][-1]
            column = next(
                (
                    k
                    for k, v in row.items()
                    if isinstance(v, (int, float)) and not isinstance(v, bool)
                ),
                None,
            )
            keys = []
            if column:
                keys = [
                    {
                        "label": column,
                        "value": format_number(row[column], "number", "identity", 3),
                        "unit": "number",
                        "source_step_id": step,
                        "source_attempt": r["attempt"],
                        "column": column,
                        "row_index": len(r["rows"]) - 1,
                        "conversion": "identity",
                        "decimals": 3,
                    }
                ]
            return {
                "headline": "Measured delivery cost and margin evidence"
                if step == "trend"
                else "Alternative explanation tested",
                "answer": "Review the executed comparison" + (": {{n0}}." if keys else "."),
                "key_numbers": keys,
                "caveats": [
                    (
                        "Observed associations do not establish causality. Review the "
                        "population and data-quality checks."
                    )
                ],
            }
        if purpose == "hypotheses":
            specs = [
                ("seasonality", "A calendar effect explains the change"),
                ("product_mix", "A product mix shift explains the change"),
                ("concentration", "A channel concentration explains the change"),
                ("pricing", "Pricing changes explain the change"),
            ]
            return {
                "hypotheses": [
                    {
                        "id": k,
                        "hypothesis": h,
                        "rationale": "Test measured baseline and target populations.",
                        "category": k,
                        "metric": k,
                        "direction": "either",
                        "threshold_pct": 10.0,
                        "test_plan": plan([(k, h)], "comparison"),
                    }
                    for k, h in specs
                ]
            }
        if purpose == "brief":
            paths = context["allowed_evidence"]
            impact = next((k for k in paths if k.endswith("business_impact")), None)
            confidence = next((k for k in paths if k.endswith("finding.confidence.score")), None)
            change = next((k for k in paths if ".drivers.0.change_pct" in k), None)

            def token(k):
                return "{{e:" + k + "}}"

            return {
                "situation": (
                    "The measured target-period margin declined against the selected baseline."
                ),
                "evidence": [
                    {
                        "text": "Primary driver change: " + token(change) + "%."
                        if change
                        else "See the executed component comparison.",
                        "source": "finding:0",
                    }
                ],
                "root_cause": (
                    "Within the measured components, peak delivery cost is the primary "
                    "adverse driver; refunds are secondary. Population mix is reported "
                    "separately."
                ),
                "business_impact": "Estimated margin lost at the target-order count: £"
                + token(impact)
                + "."
                if impact
                else "No comparable monetary impact was measured.",
                "recommended_actions": [
                    {
                        "owner_role": "Operations",
                        "priority": "High",
                        "expected_impact": (
                            "Review peak-slot delivery pricing; validate achievable savings "
                            "before committing a target."
                        ),
                        "linked_evidence": "finding:0",
                    },
                    {
                        "owner_role": "Customer experience",
                        "priority": "Medium",
                        "expected_impact": (
                            "Investigate refund causes and monitor affected locations."
                        ),
                        "linked_evidence": "finding:0",
                    },
                ],
                "risks_and_caveats": [
                    (
                        "Retained duplicates and invalid dates require review. Calendar "
                        "effects remain inconclusive when prior-year observations are "
                        "unavailable."
                    ),
                    "Observational comparison; savings are not guaranteed.",
                ],
                "confidence_statement": "Evidence confidence: "
                + token(confidence)
                + " / "
                + "{{e:scale_max}}"
                if confidence
                else "Evidence remains limited.",
            }
        raise ValueError("Unsupported demo response purpose: " + purpose)
