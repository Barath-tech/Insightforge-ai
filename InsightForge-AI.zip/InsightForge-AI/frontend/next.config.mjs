import { PHASE_DEVELOPMENT_SERVER } from "next/constants.js";

/** Separate output folders let `next dev`, `next build`, and E2E runs coexist safely. */
export default function nextConfig(phase) {
  /** @type {import('next').NextConfig} */
  return {
    output: "standalone",
    experimental: { cpus: 2 },
    distDir:
      process.env.NEXT_DIST_DIR ||
      (phase === PHASE_DEVELOPMENT_SERVER ? ".next-dev" : ".next"),
  };
}
