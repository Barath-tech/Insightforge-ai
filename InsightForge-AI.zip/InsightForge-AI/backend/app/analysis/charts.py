"""Deterministic visualization rules over executed result cells, never model hints."""

import math
from datetime import date, datetime

from pydantic import BaseModel, Field


class ChartSpec(BaseModel):
    type: str
    x: str | None = None
    y: list[str] = Field(default_factory=list)
    series: str | None = None
    title: str
    x_label: str = ""
    y_label: str = ""
    reason: str
    highlights: list[dict] = Field(default_factory=list)
    secondary_y: list[str] = Field(default_factory=list)
    horizontal: bool = False
    compatible_types: list[str] = Field(default_factory=list)
    rows: list[dict] = Field(default_factory=list)


def numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def secondary_measures(rows, measures, ratio=20):
    """Measures far smaller than the largest one would be flattened on a shared axis."""
    peaks = {m: max((abs(r[m]) for r in rows if numeric(r.get(m))), default=0.0) for m in measures}
    top = max(peaks.values(), default=0.0)
    if len(measures) < 2 or not top:
        return []
    return [m for m in measures if peaks[m] * ratio < top]


def select_chart(result, title="Executed evidence", chart_hint=None):
    rows, columns = result.get("rows", []), result.get("columns", [])
    types = dict(zip(columns, result.get("column_types", [])))
    numbers, dates, categories = [], [], []
    for col in columns:
        values = [r.get(col) for r in rows if r.get(col) is not None]
        if values and all(numeric(v) for v in values):
            numbers.append(col)
        elif (
            "DATE" in types.get(col, "")
            or "TIMESTAMP" in types.get(col, "")
            or (values and all(isinstance(v, (date, datetime)) for v in values))
        ):
            dates.append(col)
        elif values and len({str(v) for v in values}) <= 20:
            categories.append(col)
    spec = ChartSpec(
        type="table", title=title, reason="table: no compatible chart shape", rows=rows
    )
    if len(rows) == 1 and numbers:
        spec.type, spec.y, spec.reason = "kpi", numbers, "KPI: a single result row"
    elif dates and numbers:
        spec.type, spec.x, spec.y = "line", dates[0], numbers[:4]
        spec.reason = "line: date column + numeric measure"
        spec.rows = sorted(rows, key=lambda r: str(r.get(spec.x) or ""))
        spec.compatible_types = ["line", "bar"]
    elif categories and numbers and len(numbers) <= 4:
        spec.type = "grouped_bar" if len(numbers) > 1 else "bar"
        spec.x, spec.y = categories[0], numbers
        spec.reason = f"{spec.type}: categorical column + numeric measures"
        spec.horizontal = any(len(str(r.get(spec.x, ""))) > 18 for r in rows)
        spec.rows = sorted(rows, key=lambda r: r.get(numbers[0]) or 0, reverse=True)
        spec.compatible_types = [spec.type, "table"]
    elif len(numbers) >= 2:
        spec.type, spec.x, spec.y = "scatter", numbers[0], [numbers[1]]
        spec.series = categories[0] if categories else None
        spec.reason = "scatter: numeric x and y measures"
        spec.compatible_types = ["scatter", "table"]
    if spec.type in {"line", "grouped_bar"}:
        spec.secondary_y = secondary_measures(spec.rows, spec.y)
        if spec.secondary_y:
            spec.reason += "; secondary axis for smaller-scale " + ", ".join(spec.secondary_y)
    spec.x_label = spec.x or ""
    spec.y_label = ", ".join(m for m in spec.y if m not in spec.secondary_y)
    if not spec.compatible_types:
        spec.compatible_types = [spec.type, "table"] if spec.type != "table" else ["table"]
    return spec.model_dump()
