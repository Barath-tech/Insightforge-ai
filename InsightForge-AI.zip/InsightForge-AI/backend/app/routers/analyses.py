import asyncio
import time
from collections import deque

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, field_validator
from sqlmodel import Session, select

from app.agent import store
from app.agent.events import Events, frame
from app.agent.pipeline import run
from app.core.config import settings
from app.core.db import get_session
from app.llm.client import OpenAITransport, get_transport
from app.models.analysis import Analysis
from app.routers.datasets import get_dataset
from app.services.ai_content import content
from app.services.schema import describe

router = APIRouter(prefix="/api", tags=["analysis"])


class Limiter:
    def __init__(self):
        self.active = 0
        self.starts = deque()

    def acquire(self):
        now = time.monotonic()
        while self.starts and now - self.starts[0] > 60:
            self.starts.popleft()
        if self.active >= settings.ask_concurrency or len(self.starts) >= settings.ask_per_minute:
            raise HTTPException(
                429, "Analysis capacity reached. Try again shortly.", headers={"Retry-After": "60"}
            )
        self.active += 1
        self.starts.append(now)

    def release(self):
        self.active = max(0, self.active - 1)


limiter = Limiter()


def context(identifier, session):
    dataset = get_dataset(identifier, session)
    return dataset, describe(dataset, session), session.get_bind()


@router.get("/datasets/{identifier}/schema")
def schema(identifier: str, session: Session = Depends(get_session)):
    return describe(get_dataset(identifier, session), session)


@router.get("/analyses/{identifier}")
def analysis(identifier: str, session: Session = Depends(get_session)):
    value = store.detail(session.get_bind(), identifier)
    if value is None:
        raise HTTPException(404, "Analysis not found.")
    return value


@router.get("/datasets/{identifier}/analyses")
def history(identifier: str, session: Session = Depends(get_session)):
    get_dataset(identifier, session)
    children = store.challenge_children(session, identifier)
    rows = session.exec(
        select(Analysis)
        .where(Analysis.dataset_id == identifier)
        .order_by(Analysis.created_at.desc())
        .limit(50)
    ).all()
    return [{**a.model_dump(mode="json"), "challenge_of": children.get(a.id)} for a in rows]


@router.post("/datasets/{identifier}/narrative")
async def narrative(
    identifier: str,
    refresh: bool = False,
    session: Session = Depends(get_session),
    transport=Depends(get_transport),
):
    dataset, schema, engine = await asyncio.to_thread(context, identifier, session)
    return await content(engine, dataset, schema, transport, "narrative", refresh)


@router.get("/datasets/{identifier}/suggestions")
async def suggestions(
    identifier: str, session: Session = Depends(get_session), transport=Depends(get_transport)
):
    dataset, schema, engine = await asyncio.to_thread(context, identifier, session)
    return await content(engine, dataset, schema, transport, "suggestions")


class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)

    @field_validator("question")
    @classmethod
    def not_blank(cls, value):
        if len(value.strip()) < 3:
            raise ValueError("Enter a question of at least three characters.")
        return value.strip()


@router.post("/datasets/{identifier}/ask")
async def ask(
    identifier: str,
    body: AskRequest,
    request: Request,
    session: Session = Depends(get_session),
    transport=Depends(get_transport),
):
    dataset, schema, engine = await asyncio.to_thread(context, identifier, session)
    if isinstance(transport, OpenAITransport) and not settings.openai_api_key:
        raise HTTPException(
            503, "AI unavailable. Configure OPENAI_API_KEY or switch to DEMO_REPLAY=replay."
        )
    limiter.acquire()
    analysis = Analysis(dataset_id=identifier, question=body.question)
    try:
        await asyncio.to_thread(store.save, engine, analysis)
    except BaseException:
        limiter.release()
        raise

    async def stream():
        queue = asyncio.Queue()
        events = Events(analysis.id, queue)
        task = asyncio.create_task(run(engine, dataset, schema, analysis, transport, events))
        try:
            yield ": connected\n\n"
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=1)
                except TimeoutError:
                    if await request.is_disconnected():
                        break
                    yield ": heartbeat\n\n"
                    continue
                yield frame(event)
                if event["type"] == "done":
                    break
        finally:
            if not task.done():
                task.cancel()
            # Shield cleanup against Starlette's disconnect cancellation scope.
            import anyio

            with anyio.CancelScope(shield=True):
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                finally:
                    limiter.release()

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
            "X-Analysis-ID": analysis.id,
        },
    )
