import asyncio

import sqlglot
from pydantic import Field
from sqlmodel import Session

from app.agent import store
from app.agent.contracts import Contract, Plan
from app.agent.events import Events
from app.agent.pipeline import run
from app.analysis.charts import select_chart
from app.analysis.evidence import decompose
from app.llm.client import Client
from app.models.analysis import Analysis
from app.services.query import submit


class Hypothesis(Contract):
    id: str
    hypothesis: str = Field(max_length=400)
    rationale: str = Field(max_length=600)
    category: str
    metric: str
    direction: str
    threshold_pct: float = Field(ge=0, le=100)
    test_plan: Plan


class Hypotheses(Contract):
    hypotheses: list[Hypothesis] = Field(min_length=3, max_length=5)


def verdict(rows, direction, threshold):
    if len(rows) != 1:
        return "INCONCLUSIVE", "Test must return a single aggregate comparison."
    r = rows[0]
    required = ["baseline_value", "target_value", "baseline_n", "target_n"]
    if any(not isinstance(r.get(k), (int, float)) for k in required):
        return "INCONCLUSIVE", "Comparison or sample-size evidence is missing."
    if min(r["baseline_n"], r["target_n"]) < 5 or not r["baseline_value"]:
        return "INCONCLUSIVE", "Insufficient samples or zero baseline."
    delta = 100 * (r["target_value"] - r["baseline_value"]) / abs(r["baseline_value"])
    directional = (
        delta if direction == "increase" else -delta if direction == "decrease" else abs(delta)
    )
    return (
        "SUPPORTED" if directional > threshold else "REFUTED",
        f"Measured change {delta:+.2f}%; prespecified threshold {threshold:.2f}%. "
        "This tests association, not causal attribution.",
    )


def final_result(detail, plan):
    """Return the final planned step's checked result, or why no verdict is allowed.

    A partially failed test must not fall back to an earlier step's result.
    """
    if detail["status"] != "completed":
        return None, (
            f"Test analysis {detail['status']}; partial results cannot support a verdict."
        )
    ok = {
        s["step_id"]: s
        for s in detail["steps"]
        if s["status"] == "ok" and s["result_json"] is not None
    }
    if not plan.steps or any(step.id not in ok for step in plan.steps):
        return None, "A planned test step has no successful result; no verdict is drawn."
    return ok[plan.steps[-1].id], None


def quality_sql(sql, table, dedup):
    tree = sqlglot.parse_one(sql, read="duckdb")
    for node in tree.find_all(sqlglot.exp.Table):
        if node.name == table:
            node.set("this", sqlglot.exp.to_identifier("__quality_source"))
    source = f'SELECT * FROM "{table}" WHERE order_date IS NOT NULL'
    if dedup:
        source = (
            f"SELECT * EXCLUDE (__quality_rank) FROM (SELECT *, ROW_NUMBER() OVER "
            f"(PARTITION BY order_id ORDER BY order_date NULLS LAST) AS __quality_rank "
            f'FROM "{table}") WHERE __quality_rank = 1 AND order_date IS NOT NULL'
        )
    # Nest original WITH clauses inside a subquery to avoid duplicate WITH syntax.
    return f"WITH __quality_source AS ({source}) SELECT * FROM ({tree.sql(dialect='duckdb')})"


async def challenge_run(engine, dataset, schema, original, transport, challenge, emit):
    result = {
        "original_confidence": original.finding_json.get("confidence", {}).get("score", 0),
        "hypotheses": [],
        "quality_checks": [],
    }

    async def save(status="running"):
        challenge.status, challenge.result_json = status, dict(result)
        await asyncio.to_thread(store.save, engine, challenge)

    try:
        llm = Client(engine, dataset.id, transport, original.id)
        proposed = await llm.generate(
            "hypotheses",
            {
                "question": original.question,
                "finding": original.finding_json,
                "schema": schema,
                "issues": schema["issues"],
            },
            Hypotheses,
        )
        for hypothesis in proposed.hypotheses:
            # Model-proposed labels are not evidence; reject unsupported numeric assertions.
            import re

            if re.search(r"\d", hypothesis.hypothesis + hypothesis.rationale):
                raise ValueError("Hypothesis prose contains unsupported numeric claims.")
            child = Analysis(dataset_id=dataset.id, question=hypothesis.hypothesis)
            await asyncio.to_thread(store.save, engine, child)
            queue = asyncio.Queue()
            task = asyncio.create_task(
                run(
                    engine,
                    dataset,
                    schema,
                    child,
                    transport,
                    Events(child.id, queue),
                    preset_plan=hypothesis.test_plan,
                )
            )
            try:
                while True:
                    event = await queue.get()
                    await emit("challenge_step", {"hypothesis_id": hypothesis.id, "event": event})
                    if event["type"] == "done":
                        break
                await task
            finally:
                if not task.done():
                    task.cancel()
                    try:
                        await task
                    except asyncio.CancelledError:
                        pass
            detail = await asyncio.to_thread(store.detail, engine, child.id)
            last, missing = final_result(detail, hypothesis.test_plan)
            if last is None:
                decision, explanation = "INCONCLUSIVE", missing
            else:
                decision, explanation = verdict(
                    last["result_json"]["rows"], hypothesis.direction, hypothesis.threshold_pct
                )
            item = {
                **hypothesis.model_dump(),
                "analysis_id": child.id,
                "verdict": decision,
                "explanation": explanation,
                "steps": detail["steps"],
                "chart": last["result_json"].get("chart") if last else None,
            }
            result["hypotheses"].append(item)
            await save()
            await emit("hypothesis", item)
        evidence = original.finding_json.get("evidence", {})
        components = next(
            (
                s
                for s in evidence.get("supporting_steps", [])
                if "dimension" in s["sql"] and "refund_amount" in s["sql"]
            ),
            None,
        )
        table = next(
            (
                t["name"]
                for t in schema["tables"]
                if t["role"] == "clean"
                and {"order_id", "order_date"} <= {c["name"] for c in t["columns"]}
            ),
            None,
        )
        for dedup in [False, True]:
            item = {
                "name": "Deduplicated + valid dates" if dedup else "Valid dates only",
                "verdict": "INCONCLUSIVE",
                "explanation": "Metric contract unavailable.",
            }
            if components and table:
                sql = quality_sql(components["sql"], table, dedup)

                def execute():
                    with Session(engine) as session:
                        return submit(session, dataset, sql, source="agent")

                outcome = await asyncio.to_thread(execute)
                item.update(sql=sql, query_run=outcome["run"])
                if outcome["result"] and not outcome["result"].get("truncated"):
                    d = decompose(outcome["result"]["rows"])
                    original_d = evidence.get("decomposition") or {}
                    if d.get("complete") and original_d.get("complete"):
                        before = original_d["target_margin"] - original_d["baseline_margin"]
                        after = d["target_margin"] - d["baseline_margin"]
                        changed = before * after < 0 or abs(after - before) > max(
                            abs(before) * 0.1, 1e-9
                        )
                        item.update(
                            verdict="SUPPORTED" if changed else "REFUTED",
                            explanation=f"Data-quality artifact test: margin change "
                            f"£{before:+.4f} → £{after:+.4f} per order.",
                            evidence=d,
                            chart=select_chart(outcome["result"], item["name"]),
                        )
            result["quality_checks"].append(item)
            await emit("quality_check", item)
        supported = sum(h["verdict"] == "SUPPORTED" for h in result["hypotheses"])
        refuted = sum(h["verdict"] == "REFUTED" for h in result["hypotheses"])
        artifacts = sum(h["verdict"] == "SUPPORTED" for h in result["quality_checks"])
        original_score = result["original_confidence"]
        revised = max(
            0, min(100, original_score + min(6, refuted * 2) - supported * 5 - artifacts * 15)
        )
        result.update(
            revised_confidence=revised,
            verdict_summary=f"{refuted} alternatives refuted; {supported} supported. "
            "Inconclusive tests add no confidence.",
            surviving_explanation=(
                "Alternative explanations remain; review supported tests."
                if supported or artifacts
                else "Original measured explanation survives tested alternatives."
            ),
            confidence_explanation="+2 per refuted alternative (max +6), -5 per supported "
            "alternative, -15 per supported data-quality artifact; inconclusive = 0.",
        )
        await save("completed")
        await emit("challenge", {"id": challenge.id, **result})
    except asyncio.CancelledError:
        await save("cancelled")
        raise
    except Exception as exc:
        result["error"] = str(exc)[:500]
        await save("failed")
        await emit("error", {"message": result["error"]})
    finally:
        await emit("done", {"status": challenge.status})
