"""Fail-closed AST policy for the Phase 1 SQL console and future agents."""

import sqlglot
from sqlglot import exp


class SQLValidationError(ValueError):
    pass


# Scalar/aggregate functions only; unknown UDFs, external readers, and table functions are denied.
SAFE_FUNCTIONS = set(
    """ABS AVG CEIL CEILING FLOOR ROUND SUM COUNT MIN MAX MEDIAN STDDEV STDDEV_POP
STDDEV_SAMP VARIANCE COALESCE NULLIF IF CASE CAST TRY_CAST EXTRACT DATE_TRUNC TIMESTAMP_TRUNC
DATE_DIFF
DATEDIFF STRFTIME TIME_TO_STR LOWER UPPER TRIM LENGTH CHAR_LENGTH SUBSTRING CONCAT
CONCAT_WS REPLACE ROW_NUMBER RANK DENSE_RANK LAG LEAD FIRST_VALUE LAST_VALUE
PERCENTILE_CONT PERCENTILE_DISC QUANTILE_CONT QUANTILE_DISC GREATEST LEAST
YEAR MONTH DAY MONTHNAME DAYNAME COUNT_IF BOOL_AND BOOL_OR ISNAN POWER SQRT
""".split()
)
FORBIDDEN = set(
    """insert update delete create drop alter merge copy command pragma attach detach
transaction commit rollback set use grant revoke into load install execute truncate analyze vacuum
export import lock unlock pivot unpivot""".split()
)


def validate_sql(sql: str, tables: list[str]) -> str:
    if not sql.strip() or len(sql) > 20000:
        raise SQLValidationError("Enter a single SELECT query (maximum 20,000 characters).")
    try:
        statements = sqlglot.parse(sql, read="duckdb")
    except sqlglot.errors.SqlglotError as exc:
        raise SQLValidationError(f"SQL could not be parsed: {exc}") from exc
    if len(statements) != 1 or not isinstance(
        statements[0], (exp.Select, exp.Union, exp.Intersect, exp.Except)
    ):
        raise SQLValidationError("Guard blocked query: only one read-only SELECT is allowed.")
    tree = statements[0]
    ctes = {c.alias.lower() for c in tree.find_all(exp.CTE)}
    allowed = {t.lower() for t in tables} | ctes
    for node in tree.walk():
        if node.key in FORBIDDEN:
            raise SQLValidationError(f"Guard blocked forbidden SQL operation: {node.key.upper()}.")
        if isinstance(node, exp.Table):
            if not isinstance(node.this, exp.Identifier) or node.db or node.catalog:
                raise SQLValidationError("Guard blocked external or qualified table access.")
            if node.name.lower() not in allowed:
                raise SQLValidationError(f"Guard blocked unknown table: {node.name}.")
        # SQLGlot represents boolean connectors as Func subclasses. They cannot
        # access data or invoke UDFs; their children still receive full AST checks.
        if isinstance(node, exp.Func) and not isinstance(node, (exp.And, exp.Or, exp.Not)):
            name = node.name.upper() if isinstance(node, exp.Anonymous) else node.sql_name()
            if name not in SAFE_FUNCTIONS:
                raise SQLValidationError(f"Guard blocked function: {name}.")
    return tree.sql(dialect="duckdb")
