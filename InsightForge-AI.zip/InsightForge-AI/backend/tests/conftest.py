import pytest
from app.core.config import settings
from app.core.db import get_session
from app.main import app
from fastapi.testclient import TestClient
from sqlmodel import Session, SQLModel, create_engine

from scripts.generate_uk_retail import write


@pytest.fixture(scope="session")
def samples(tmp_path_factory):
    path = tmp_path_factory.mktemp("fixtures")
    write(path)
    return path


@pytest.fixture
def client(tmp_path, monkeypatch, samples):
    monkeypatch.setattr(settings, "data_dir", tmp_path)
    # Reuse the installed extension without depending on network in tests.
    from pathlib import Path

    extensions = Path(__file__).resolve().parents[2] / "data" / "extensions"
    (tmp_path / "extensions").symlink_to(extensions, target_is_directory=True)
    (tmp_path / "samples").symlink_to(samples / "samples", target_is_directory=True)
    engine = create_engine(
        f"sqlite:///{tmp_path / 'metadata.sqlite'}", connect_args={"check_same_thread": False}
    )
    monkeypatch.setattr("app.core.db.engine", engine)
    app.state.test_engine = engine
    from app.routers.analyses import limiter

    limiter.starts.clear()
    limiter.active = 0
    SQLModel.metadata.create_all(engine)

    def session_override():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_session] = session_override
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
    engine.dispose()


@pytest.fixture(autouse=True)
def no_live_network(request, monkeypatch):
    # Even with a developer key present, default tests cannot call OpenAI.
    if request.node.get_closest_marker("live"):
        return
    from app.llm.client import LLMError, OpenAITransport
    from app.llm.replay import FIXTURE_MODEL

    # Local .env may target a live gateway/model; offline tests use the fixture model.
    monkeypatch.setattr(settings, "openai_model", FIXTURE_MODEL)
    monkeypatch.setattr(settings, "openai_base_url", "")

    async def disabled(*args, **kwargs):
        raise LLMError("unavailable", "AI disabled in offline tests.")

    monkeypatch.setattr(OpenAITransport, "request", disabled)
