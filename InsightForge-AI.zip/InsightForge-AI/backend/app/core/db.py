from sqlmodel import Session, SQLModel, create_engine

from app.core.config import settings

settings.data_dir.mkdir(parents=True, exist_ok=True)
engine = create_engine(
    f"sqlite:///{settings.data_dir / 'metadata.sqlite'}", connect_args={"check_same_thread": False}
)


def init_db():
    from app.agent.store import recover

    SQLModel.metadata.create_all(engine)
    recover(engine)


def get_session():
    with Session(engine) as session:
        yield session
