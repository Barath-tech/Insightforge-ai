# OpenAI usage

InsightForge uses a language model only to **propose** structured artefacts: plans, SQL, corrections, findings, narratives, suggested questions, alternative hypotheses, and brief wording. Every number the user sees comes from executed, guarded SQL or deterministic profiling. The model never computes, invents, or is trusted for a figure.

## What the model is asked to do

| Purpose | Response contract | Used by | What the server does with it |
|---|---|---|---|
| `narrative` | `Narrative` (fact references) | Data Health summary | Each claim must match a profile fact's label and value; otherwise a deterministic fallback is shown. |
| `suggestions` | `Suggestions` (five questions) | Ask workspace chips | Tables/columns must exist; otherwise schema-derived fallback questions. |
| `plan` | `Plan` | Ask | Validated step graph, at most `AGENT_MAX_STEPS` steps. |
| `sql` / `correction` | `SQLProposal` | Ask, Challenge | Parsed by `sql_guard`, executed read-only; corrections must preserve the original WHERE/HAVING filters. |
| `finding` | `Finding` (`{{n0}}` placeholders + cited cells) | Ask | Each cited cell must exist in a successful attempt; the server renders the numbers. |
| `hypotheses` | `Hypotheses` (3–5 testable alternatives) | Challenge My Insight | Prose may not contain digits; each test plan runs through the same pipeline. Verdicts are computed in Python. |
| `brief` | `BriefContent` (`{{e:path}}` tokens) | Executive brief | Tokens resolve to stored evidence values; unknown tokens, untokenised numbers, and unknown sources are removed and flagged. |

All payloads use **Structured Outputs** with Pydantic models through `AsyncOpenAI.responses.parse(..., text_format=Model)` in [`backend/app/llm/client.py`](../backend/app/llm/client.py). The system prompt is versioned (`backend/app/llm/prompts/system_v2.txt`, `PROMPT_VERSION = "system_v2"`); change the version with any prompt change.

## Bounds and retries

- SDK automatic retries are **zero**. The client owns three separate bounds: one schema repair, a shared transport retry allowance (`LLM_TRANSPORT_RETRIES`, default 1), and pipeline-level bounds (three SQL attempts per step, one finding/narrative/brief grounding repair).
- Default worst case per generation: three actual requests. Refusals, authentication errors, and incomplete responses never retry.
- Context larger than `LLM_CONTEXT_CHARS` fails before sending. Output is capped by `LLM_MAX_OUTPUT_TOKENS`.
- Ask/Challenge admission: `ASK_PER_MINUTE` and `ASK_CONCURRENCY`, process-wide.

## What is sent and what is logged

- Sent: question, schema (table/column names, types, semantic types), small categorical samples (never identifiers or free text), profile facts, bounded executed results for the current analysis, and plan/evidence summaries.
- Never sent: credentials, generator ground truth, file paths, full tables.
- Every actual request writes an `llm_calls` row: purpose, model (`replay:<model>` for replays), prompt version, latency, status, sanitised error, redacted request/response, and token usage (NULL when unknown). Redaction removes keys/secrets, configured credentials, `sk-` tokens, e-mail addresses, filesystem paths, identifier values, questions, rows, and samples. It is a debugging aid, not a PII detector.
- The **AI Transparency** page (`/audit`) lists these calls with totals and correction success rate, and exports them as CSV (formula-injection safe).

## Modes

`DEMO_REPLAY` selects the transport:

| Mode | Behaviour |
|---|---|
| `replay` (default in `.env.example` and Docker) | Offline. Responses are read from `data/demo_cache/<sha256>.json`, keyed by purpose, canonical context (volatile IDs/timings removed), response schema, prompt text/version, and model. A miss is an error; it never falls through to the network. |
| `off` | Live OpenAI calls; requires `OPENAI_API_KEY`. |
| `record` | Live calls whose validated responses are saved for later replay. Review recordings before sharing: they can contain business data. |

### Replay provenance

The committed cache is **scripted**, not a recording of a live model. `make seed-replay` runs the real ingestion, guard, executor, evidence, challenge, and brief services against the demo CSV, with the disclosed `scripts/demo_responses.py` transport supplying model-shaped responses. Each file records `"provenance": "scripted_fixture"`. Scripted responses contain no planted numbers: numeric values are copied from runtime evidence or referenced by token. The first SQL attempt deliberately misspells a column so the correction loop is exercised.

Replay matches exact contexts only. Arbitrary questions, other datasets, model/prompt changes, or edited sample data produce a replay miss. Use `make seed-replay` after changing prompts, contracts, or the demo flow; it rewrites the cache in place. Delete `data/demo_cache/*.json` first to drop stale entries.

## Live operation

```dotenv
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-4.1
DEMO_REPLAY=off
```

### OpenAI-compatible gateways (LiteLLM)

`OPENAI_BASE_URL` points the same audited client at an OpenAI-compatible gateway; `OPENAI_API_KEY` then holds the gateway key and `OPENAI_MODEL` the gateway's model name. For the TCS GenAI Lab proxy:

```dotenv
OPENAI_API_KEY=your_gateway_key_here
OPENAI_BASE_URL=https://genailab.tcs.in/
OPENAI_MODEL=genailab-openai-gpt-5.6-luna
DEMO_REPLAY=off
```

No other code path changes: requests still use `responses.parse` with Pydantic Structured Outputs, zero SDK retries, the same bounds, and the same `llm_calls` audit (the audit records the configured model name). The app does not use an agent framework. TLS is verified against the system trust store plus optional `OPENAI_CA_BUNDLE`; `OPENAI_VERIFY_SSL=false` disables verification and should only be used temporarily. The gateway must support Responses API Structured Outputs; otherwise requests fail with a schema or service error and are audited as such.

The key is read only by the backend. Live operation **has not been validated** with a real key in this project; validate with the opt-in test before relying on it:

```bash
INSIGHTFORGE_LIVE_TEST=1 .venv/bin/python -m pytest backend/tests -m live -q
```

Default tests block the OpenAI transport even when a key is present. Live requests incur charges.
