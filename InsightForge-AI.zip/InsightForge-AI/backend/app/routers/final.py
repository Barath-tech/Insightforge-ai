import asyncio
import json

import anyio
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlmodel import Session, select

from app.agent import store
from app.challenge.service import challenge_run
from app.core.db import get_session
from app.llm.client import get_transport
from app.models.analysis import Analysis
from app.models.final import Challenge, Pin
from app.routers.analyses import limiter
from app.routers.datasets import get_dataset
from app.services.schema import describe

router = APIRouter(prefix="/api", tags=["final"])


@router.post("/analyses/{identifier}/challenge")
async def challenge(
    identifier: str,
    request: Request,
    session: Session = Depends(get_session),
    transport=Depends(get_transport),
):
    original = session.get(Analysis, identifier)
    if not original or not original.finding_json:
        raise HTTPException(404, "Completed finding not found.")
    dataset = get_dataset(original.dataset_id, session)
    schema, engine = describe(dataset, session), session.get_bind()
    limiter.acquire()
    value = Challenge(analysis_id=identifier)
    try:
        await asyncio.to_thread(store.save, engine, value)
    except BaseException:
        limiter.release()
        raise

    async def stream():
        queue = asyncio.Queue()

        async def emit(kind, payload):
            await queue.put({"type": kind, "payload": payload, "challenge_id": value.id})

        task = asyncio.create_task(
            challenge_run(engine, dataset, schema, original, transport, value, emit)
        )
        try:
            yield ": connected\n\n"
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), 1)
                except TimeoutError:
                    if await request.is_disconnected():
                        break
                    yield ": heartbeat\n\n"
                    continue
                yield "data: " + json.dumps(event, default=str) + "\n\n"
                if event["type"] == "done":
                    break
        finally:
            if not task.done():
                task.cancel()
            with anyio.CancelScope(shield=True):
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                finally:
                    limiter.release()

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/analyses/{identifier}/challenges")
def challenges(identifier: str, session: Session = Depends(get_session)):
    return session.exec(
        select(Challenge)
        .where(Challenge.analysis_id == identifier)
        .order_by(Challenge.created_at.desc())
    ).all()


class PinRequest(BaseModel):
    pinned: bool


@router.patch("/{kind}/{identifier}/pin")
def pin(kind: str, identifier: str, body: PinRequest, session: Session = Depends(get_session)):
    if kind not in {"analyses", "challenges"}:
        raise HTTPException(404, "Unknown item type.")
    item = session.get(Analysis if kind == "analyses" else Challenge, identifier)
    if not item:
        raise HTTPException(404, "Item not found.")
    dataset_id = (
        item.dataset_id
        if kind == "analyses"
        else session.get(Analysis, item.analysis_id).dataset_id
    )
    value = Pin(item_id=identifier, kind=kind, dataset_id=dataset_id, pinned=body.pinned)
    session.merge(value)
    session.commit()
    return value


@router.get("/datasets/{identifier}/pins")
def pins(identifier: str, session: Session = Depends(get_session)):
    return session.exec(select(Pin).where(Pin.dataset_id == identifier, Pin.pinned)).all()


@router.get("/datasets/{identifier}/progress")
def progress(identifier: str, session: Session = Depends(get_session)):
    """Read-only workflow summary that lets the UI show where the user is and what is next."""
    from app.models.final import Brief

    get_dataset(identifier, session)
    children = store.challenge_children(session, identifier)
    analyses = [
        a
        for a in session.exec(
            select(Analysis.id, Analysis.status)
            .where(Analysis.dataset_id == identifier)
            .order_by(Analysis.created_at.desc())
        ).all()
        if a.id not in children
    ]
    completed = [a.id for a in analyses if a.status == "completed"]
    challenged = (
        session.exec(
            select(Challenge.analysis_id).where(
                Challenge.analysis_id.in_(completed), Challenge.status == "completed"
            )
        ).all()
        if completed
        else []
    )
    pinned = session.exec(select(Pin).where(Pin.dataset_id == identifier, Pin.pinned)).all()
    briefs = session.exec(
        select(Brief).where(Brief.dataset_id == identifier).order_by(Brief.created_at.desc())
    ).all()
    return {
        "analyses": len(analyses),
        "completed_analyses": len(completed),
        "latest_completed_analysis_id": completed[0] if completed else None,
        "challenged_analyses": len(set(challenged)),
        "pinned_findings": sum(p.kind == "analyses" for p in pinned),
        "pinned_challenges": sum(p.kind == "challenges" for p in pinned),
        "briefs": [
            {
                "id": b.id,
                "title": b.title,
                "created_at": b.created_at,
                "grounding_status": b.grounding_json.get("status", "unverified"),
            }
            for b in briefs[:10]
        ],
    }


class BriefRequest(BaseModel):
    analysis_ids: list[str] | None = None
    title: str | None = None
    audience: str = "Executive leadership"


@router.post("/datasets/{identifier}/briefs")
async def create_brief(
    identifier: str,
    body: BriefRequest,
    session: Session = Depends(get_session),
    transport=Depends(get_transport),
):
    from app.report.service import create_brief as generate

    dataset = get_dataset(identifier, session)
    try:
        return await generate(session.get_bind(), dataset, body, transport)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    except Exception as exc:
        from app.llm.client import LLMError

        if isinstance(exc, LLMError):
            raise HTTPException(503, str(exc)) from exc
        raise


def get_brief(identifier, session):
    from app.models.final import Brief

    value = session.get(Brief, identifier)
    if not value:
        raise HTTPException(404, "Brief not found.")
    return value


@router.get("/briefs/{identifier}")
def brief(identifier: str, session: Session = Depends(get_session)):
    return get_brief(identifier, session)


@router.get("/briefs/{identifier}/{format}")
def download(identifier: str, format: str, session: Session = Depends(get_session)):
    from fastapi.responses import Response

    from app.report.service import render_markdown, render_pdf

    value = get_brief(identifier, session)
    if format not in {"markdown", "pdf"}:
        raise HTTPException(404, "Unknown export format.")
    data = render_pdf(value) if format == "pdf" else render_markdown(value)
    return Response(
        data,
        media_type="application/pdf" if format == "pdf" else "text/markdown",
        headers={
            "Content-Disposition": (
                'attachment; filename="brief.' + ("pdf" if format == "pdf" else "md") + '"'
            )
        },
    )


@router.patch("/briefs/{identifier}")
def edit_brief(identifier: str, body: dict, session: Session = Depends(get_session)):
    from app.report.service import edit_content

    value = get_brief(identifier, session)
    try:
        content, templates, grounding = edit_content(value, body)
    except ValueError as exc:
        raise HTTPException(422, "Invalid brief sections.") from exc
    # Edited text must use evidence tokens for numbers; unsupported numbers are removed and
    # the brief is marked unverified until corrected.
    value.content_json, value.grounding_json = content, grounding
    if templates is not None:
        value.evidence_json = {**value.evidence_json, "templates": templates}
    session.add(value)
    session.commit()
    session.refresh(value)
    return value


@router.get("/audit")
def audit(analysis_id: str | None = None, session: Session = Depends(get_session)):
    from app.models.analysis import AnalysisStep, LLMCall

    query = select(LLMCall).order_by(LLMCall.created_at.desc())
    if analysis_id:
        query = query.where(LLMCall.analysis_id == analysis_id)
    calls = session.exec(query).all()
    steps_query = select(AnalysisStep)
    if analysis_id:
        steps_query = steps_query.where(AnalysisStep.analysis_id == analysis_id)
    steps = session.exec(steps_query).all()
    corrected = {(s.analysis_id, s.step_id) for s in steps if s.attempt_no > 1}
    successes = {(s.analysis_id, s.step_id) for s in steps if s.attempt_no > 1 and s.status == "ok"}
    return {
        "calls": [c.model_dump(mode="json") for c in calls],
        "totals": {
            "calls": len(calls),
            "input_tokens": sum(c.input_tokens or 0 for c in calls),
            "output_tokens": sum(c.output_tokens or 0 for c in calls),
            "unknown_usage_calls": sum(c.input_tokens is None for c in calls),
            "latency_ms": sum(c.latency_ms for c in calls),
            "correction_attempts": sum(s.attempt_no > 1 for s in steps),
            "corrected_steps": len(corrected),
            "correction_success_rate": len(successes) / len(corrected) if corrected else None,
        },
    }


@router.get("/audit/export")
def audit_export(analysis_id: str | None = None, session: Session = Depends(get_session)):
    import csv
    import io

    from fastapi.responses import Response

    data = audit(analysis_id, session)["calls"]
    output = io.StringIO()
    fields = [
        "id",
        "analysis_id",
        "purpose",
        "model",
        "prompt_version",
        "input_tokens",
        "output_tokens",
        "latency_ms",
        "status",
        "created_at",
        "request_json",
        "response_json",
    ]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for call in data:
        for key in ["request_json", "response_json"]:
            call[key] = json.dumps(call[key])
        writer.writerow(
            {
                k: "'" + v if isinstance(v, str) and v.startswith(("=", "+", "-", "@")) else v
                for k, v in call.items()
            }
        )
    return Response(
        output.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="llm-audit.csv"'},
    )
