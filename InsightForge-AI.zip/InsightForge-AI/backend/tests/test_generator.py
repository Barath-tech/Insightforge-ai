import pandas as pd
from app.services.profiling import clean_and_profile

from scripts.generate_uk_retail import generate


def test_determinism_and_planted_facts():
    messy, clean, truth = generate()
    again, _, again_truth = generate()
    pd.testing.assert_frame_equal(messy, again)
    assert truth == again_truth
    assert len(messy) == 4873
    assert messy.order_id.nunique() == 4850
    assert messy.order_id.duplicated().sum() == 23
    assert ((messy.delivery_slot != "none") & messy.delivery_timestamp.isna()).sum() == 47
    df, profile = clean_and_profile(messy)
    london = df[(df.city == "London") & (df.delivery_slot == "Peak")]
    baseline = london[london.order_date.dt.month < 10].delivery_cost.mean()
    october = london[london.order_date.dt.month == 10].delivery_cost.mean()
    assert 17 < (october / baseline - 1) * 100 < 20
    by_city = clean.groupby("city").agg(
        rate=("refund_flag", "mean"), amount=("refund_amount", "sum")
    )
    assert set(by_city.nlargest(2, "rate").index) == {"Leeds", "Cardiff"}
    assert set(by_city.nlargest(2, "amount").index) == {"Leeds", "Cardiff"}
    assert len(clean) == 4850
    assert not clean.order_id.duplicated().any()
    assert len(profile["issues"]) > 0


def test_profile_discovers_issues_without_ground_truth():
    messy, _, _ = generate()
    cleaned, profile = clean_and_profile(messy)
    found = {i["code"]: i for i in profile["issues"]}
    for code, count in [
        ("duplicate_ids", 23),
        ("missing_delivery_timestamp", 47),
        ("invalid_dates", 5),
        ("negative_quantity", 3),
        ("impossible_discount", 3),
    ]:
        assert found[code]["count"] == count
    for code in ["mixed_dates", "currency_strings", "inconsistent_casing"]:
        assert found[code]["count"] > 0
    assert cleaned.revenue.dtype.kind == "f"
    assert len(cleaned) == len(messy)
    assert cleaned.order_date.isna().sum() == 5
    assert cleaned.city.str.strip().equals(cleaned.city)


def test_generic_cleaning():
    frame = pd.DataFrame(
        {
            "Item ID": ["a", "a"],
            "Value £": ["£1,234.50", "£20"],
            "City": [" a ", "A"],
            "date": ["12/10/2024", "bad"],
        }
    )
    clean, profile = clean_and_profile(frame)
    assert clean.columns.tolist() == ["item_id", "value", "city", "date"]
    assert clean.value.iloc[0] == 1234.5
    assert clean.date.iloc[0].month == 10
    assert profile["unique_ids"] == 1


def test_london_margin_attribution():
    _, clean, _ = generate()
    london = clean[clean.city == "London"].copy()
    london["month"] = pd.to_datetime(london.order_date).dt.month
    london["gross_margin"] = (
        london.revenue - london.cogs - london.delivery_cost - london.refund_amount
    )
    baseline = london[london.month < 10].select_dtypes("number").mean()
    october = london[london.month == 10].select_dtypes("number").mean()
    delivery_increase = october.delivery_cost - baseline.delivery_cost
    refund_increase = october.refund_amount - baseline.refund_amount
    assert october.gross_margin < baseline.gross_margin
    assert delivery_increase > refund_increase > 0
    assert (
        abs((baseline.gross_margin - october.gross_margin) - (delivery_increase + refund_increase))
        < 1e-8
    )


def test_iso_dates_do_not_swap_day_and_month():
    frame = pd.DataFrame(
        {
            "timestamp": [
                "2024-01-09 12:00:00",
                "2024-01-09T12:00:00",
                "09/01/2024",
                "09 Jan 2024",
                "invalid",
            ]
        }
    )
    clean, _ = clean_and_profile(frame)
    assert clean.timestamp.iloc[:4].dt.month.tolist() == [1, 1, 1, 1]
    assert clean.timestamp.iloc[:4].dt.day.tolist() == [9, 9, 9, 9]
    assert pd.isna(clean.timestamp.iloc[4])
