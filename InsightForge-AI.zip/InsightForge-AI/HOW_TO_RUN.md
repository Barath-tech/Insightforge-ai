# How to run InsightForge AI

## Setup

Requirements: Python 3.11, Node.js 20, npm, Make, Linux/WSL. On Ubuntu/Debian install PDF libraries:

```bash
sudo apt-get update
sudo apt-get install -y libpango-1.0-0 libpangoft2-1.0-0 libharfbuzz-subset0 fonts-dejavu-core
cd /path/to/InsightForge-AI
cp .env.example .env
make setup
make gen-data
```

Setup needs internet for dependencies and the DuckDB SQLite extension. Keep secrets in `.env`, never commit it.

On Windows without a WSL Linux distribution, use the Docker container route below.

## Offline demo — no API key

Set `DEMO_REPLAY=replay` in `.env` (the default in `.env.example`), leave `OPENAI_API_KEY` empty, then:

```bash
make demo
```

The launcher starts both servers (or reuses InsightForge servers already running in the same replay mode), uploads demo data, runs the London analysis and challenge, pins results, generates a brief, waits until the frontend responds, and prints its URLs.

- App: http://localhost:3000
- API docs: http://localhost:8000/docs
- Health: http://localhost:8000/api/health
- Audit: http://localhost:3000/audit

Services keep running in the background. Logs and PID records are under `work/`. Stop them with:

```bash
make demo-stop
```

`demo-stop` stops only processes this launcher started, after re-checking their command line and working directory. It never touches unrelated services. The launcher refuses to reuse a port held by another application, an older InsightForge, or a backend in a different replay mode.

For foreground development instead, run `make dev` and stop with Ctrl+C. Development, production build, and E2E use separate Next.js output folders (`.next-dev`, `.next`, `.next-e2e`), so a build can run while the development server is up.

## Manual startup

Terminal one, from the project root:

```bash
DEMO_REPLAY=replay .venv/bin/python -m uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8000
```

Terminal two:

```bash
cd frontend
npm run dev
```

## Windows: run in a Docker container

Use this when Make, Python 3.11, or a WSL distribution is not available. Docker Desktop must be running.

1. Build a development image with Python 3.11 and Node 20 (save as `Dockerfile` in an empty folder outside the project):

   ```dockerfile
   FROM node:20-bookworm-slim AS node
   FROM python:3.11-slim-bookworm
   COPY --from=node /usr/local/bin/node /usr/local/bin/node
   COPY --from=node /usr/local/lib/node_modules /usr/local/lib/node_modules
   RUN ln -s /usr/local/lib/node_modules/npm/bin/npm-cli.js /usr/local/bin/npm \
    && ln -s /usr/local/lib/node_modules/npm/bin/npx-cli.js /usr/local/bin/npx
   RUN apt-get update && apt-get install -y --no-install-recommends make curl procps \
       libpango-1.0-0 libpangoft2-1.0-0 libharfbuzz-subset0 fonts-dejavu-core \
    && rm -rf /var/lib/apt/lists/*
   WORKDIR /work
   ```

   ```powershell
   docker build -t insightforge-dev <folder>
   ```

2. Start a container with the project mounted. Named volumes keep the Linux virtual environment and `node_modules` out of the Windows folder. Choose free host ports; this example uses 13000/18000 because 8000 is often taken:

   ```powershell
   docker run -d --name ifdev -v "${PWD}:/work" -v ifdev-venv:/work/.venv -v ifdev-nm:/work/frontend/node_modules `
     -p 127.0.0.1:13000:3000 -p 127.0.0.1:18000:8000 insightforge-dev sleep infinity
   docker exec ifdev bash -lc "cd /work && cp -n .env.example .env; python3.11 -m venv .venv && make setup"
   ```

3. Start the backend and frontend, binding to `0.0.0.0` inside the container. The browser calls the API through the host port, so set `NEXT_PUBLIC_API_URL` and `CORS_ORIGINS` to the host-side URLs:

   ```powershell
   docker exec -d ifdev bash -lc "cd /work && DEMO_REPLAY=replay CORS_ORIGINS='[\"http://localhost:13000\"]' .venv/bin/python -m uvicorn app.main:app --app-dir backend --host 0.0.0.0 --port 8000 > work/backend.log 2>&1"
   docker exec -d ifdev bash -lc "cd /work/frontend && NEXT_PUBLIC_API_URL=http://localhost:18000 npx next dev -H 0.0.0.0 -p 3000 > ../work/frontend.log 2>&1"
   ```

4. Optionally run the scripted flow inside the container (it reuses both servers): `docker exec ifdev bash -lc "cd /work && make demo"`. Printed `localhost:3000` links map to `localhost:13000` on Windows.

5. Open http://localhost:13000. After a reboot, run `docker start ifdev` and repeat step 3.

Notes:

- **Corporate TLS inspection** (for example Zscaler) breaks `pip`, `npm`, and Playwright downloads inside containers. Export the proxy root certificate from Windows, copy it to `/usr/local/share/ca-certificates/` in the container, run `update-ca-certificates`, and set `PIP_CERT`, `SSL_CERT_FILE`, and `NODE_EXTRA_CA_CERTS` to `/etc/ssl/certs/ca-certificates.crt`.
- Some proxies block `extensions.duckdb.org`. `make setup` then stops at the extension step; finish with `docker exec ifdev bash -lc "cd /work/frontend && npm ci"`. Without the SQLite extension, CSV workflows work but SQLite uploads and the **SQLite fallback** demo fail.
- Bind-mounted OneDrive folders are slow and can return I/O errors for heavy writes. If `next build` fails copying files, build from a container-local copy of `frontend/`.
- A low `.wslconfig` limit (for example `processors=1`, `memory=2GB`) makes Docker Desktop unstable under browser tests and slows queries. Raise it if your machine allows. Otherwise host **lean**: build the frontend once (`npx next build`, with the dev server stopped), serve `.next/standalone/server.js` (about 300 MB total with the backend instead of 1 GB+ for `next dev`), and run Playwright from Windows against it with the installed Edge (`channel: "msedge"`, `baseURL: "http://localhost:13000"`, no `webServer`).
- **Per-user disk quotas** can make Windows report "not enough space" while the drive has plenty free. Docker Desktop's virtual disk lives in `%LOCALAPPDATA%\Docker\wsl` and counts against that quota; when it cannot grow, Docker Desktop stops responding. Free space in your profile (`docker builder prune -af`, delete build outputs), then restart Docker Desktop.
- The production Next.js server renames its process to `next-server`; stop it by that name, not `node server.js`.

## Demo walkthrough

Every dataset page shows an **Analysis journey** bar (Inspect health → Ask a question → Challenge it → Pin evidence → Executive brief). Completed steps get a tick, the next step is highlighted in amber with a one-line hint, and each step is a link. The badge at the top right shows the mode (**Offline replay**, **Live AI**, or **API offline**), and the breadcrumb shows where you are.

1. Select **Messy CSV**, then **Load demo dataset**. Clean CSV and SQLite are fallback options. Returning users can use **Continue where you left off** on the home page.
2. Inspect health, cleaning log, schema, preview, and narrative. Expect 23 duplicate IDs and 47 missing delivery timestamps in the messy sample. Click **Next: Ask a question**.
3. In offline replay mode, click **Use the demo question** (it fills `Why did profit margin decline in London in October?`), then **Analyze** (or Ctrl+Enter). The URL updates to `?analysis=<id>`, so reloads and shared links reopen the same analysis.
4. Review the SQL correction, charts, outlier callouts, confidence breakdown (81, including cross-step agreement), evidence, and the margin bridge. Peak delivery cost rises approximately 18.7%. The **Next step** hint under the finding tells you what to do next.
5. Click **Challenge My Insight**. Three alternatives are refuted; seasonality is inconclusive without prior-year data; duplicate/date reruns do not change the result. Confidence becomes 87. The individual tests appear in history labelled **Challenge test**; opening one offers **Back to the original finding**.
6. Click **Pin to brief** and **Pin challenge**. **Generate Executive Brief** stays disabled until a finding is pinned and shows what is pinned.
7. Edit any section, including the structured Evidence and Recommended Actions lists (add, remove, choose a source). Write numbers as evidence tokens (listed under *Evidence tokens for manual editing*); untokenised numbers are removed and the brief is marked unverified until corrected. Download PDF or Markdown. **Evidence behind this brief** links back to each included analysis; **Other briefs for this dataset** lists earlier versions.
8. Open **AI Transparency** for call records (25 at a time, newest first) and CSV export. Each call links to its analysis or dataset. Chart cards provide compatible chart switches and PNG export.
9. Use **SQL workspace** for guarded, read-only queries.

Replay fixtures are explicitly scripted, not live-model recordings. SQL and statistics execute for real. Replay matches exact contexts: arbitrary questions, changed data/models/prompts, and fallback datasets may lack cache entries.

## Live mode and own data

Edit `.env` for the official OpenAI API:

```dotenv
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-4.1
DEMO_REPLAY=off
```

Or for an OpenAI-compatible gateway such as the TCS GenAI Lab LiteLLM proxy (the local `.env` is already set up this way; paste only the key):

```dotenv
OPENAI_API_KEY=your_gateway_key_here
OPENAI_BASE_URL=https://genailab.tcs.in/
OPENAI_MODEL=genailab-openai-gpt-5.6-luna
DEMO_REPLAY=off
```

The gateway's certificate verifies against the system trust store (including the corporate proxy root), so certificate checks stay on. If a gateway uses a private CA, set `OPENAI_CA_BUNDLE=/path/to/ca.pem`; `OPENAI_VERIFY_SSL=false` is a last resort because it exposes the key to interception. The gateway must support the Responses API with Structured Outputs (`text_format`); if it rejects them, every AI step fails with a clear error and the deterministic features keep working.

Offline replay fixtures are keyed by model `gpt-4.1`. `make demo`, `make e2e`, `make seed-replay`, and the tests pin that model automatically, so a live model in `.env` does not break them. To run the backend in replay mode by hand, also set `OPENAI_MODEL=gpt-4.1 OPENAI_BASE_URL=` on the command line.

Restart the backend (environment variables override `.env`, so remove any `DEMO_REPLAY=replay` from your start command) and run `make dev`. Live requests may incur charges and have not been validated with a real key. Upload CSV/SQLite through **Choose a file** or drag-and-drop, inspect health, then use SQL or ask any question. Default upload limit: 50 MB. Behind a TLS-inspecting proxy, the backend also needs the proxy certificate to reach OpenAI.

`DEMO_REPLAY=record` saves live responses by prompt hash for future replay. Review recordings before sharing: they may contain business data. See [docs/OPENAI_USAGE.md](docs/OPENAI_USAGE.md).

## Checks

```bash
make test
make lint
make build
cd frontend
npx playwright install --with-deps chromium
cd ..
make e2e
make screenshots
```

E2E uses ports 3100/8100 and its own `.next-e2e` folder. Screenshots target `docs/screenshots/`. If Playwright cannot download Chromium, install a system Chromium and set `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH`. See [REMAINING.md](REMAINING.md) for unfinished checks.

## Troubleshooting

- **Site cannot be reached:** start services; check `work/backend.log`, `work/frontend.log`, and the health URL. Use HTTP.
- **Port occupied:** stop the earlier app instance with `make demo-stop`, or choose another port. The launcher rejects an unrelated or older service.
- **Missing key/rate limit:** restart in replay mode with the exact demo question, or supply a valid live key.
- **Replay miss on the demo question:** preserve sample data/question/model/prompts. On slow machines, a query can hit the 5-second limit, which changes the correction context; set `QUERY_TIMEOUT_SECONDS=30` and restart the backend.
- **PDF error:** install the system libraries above and restart.
- **SQLite extension error:** rerun `make setup` with access to `extensions.duckdb.org`.
- **Inconclusive challenge:** inspect SQL/sample counts; missing evidence does not refute an alternative.
