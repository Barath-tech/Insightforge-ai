"use client";
import { useState } from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { BASE, auditSchema, request } from "@/lib/api";
import { ErrorBox, Loading } from "@/components/shared";
import { Button } from "@/components/ui/button";
export default function Audit() {
  const [filter, setFilter] = useState("");
  const [shown, setShown] = useState(25);
  const q = useQuery({
    queryKey: ["audit", filter],
    queryFn: () =>
      request(
        `/audit${filter ? `?analysis_id=${encodeURIComponent(filter)}` : ""}`,
        auditSchema,
      ),
  });
  return (
    <>
      <p className="eyebrow mb-3">AI Transparency</p>
      <h1 className="page-title">Every model call, accounted for.</h1>
      <p className="subtle mt-3 max-w-3xl">
        Each request to the model is listed with its purpose, timing, and
        redacted inputs and outputs. Expand a row for details, or open the
        analysis it belongs to.
      </p>
      <div className="flex gap-3 my-6">
        <input
          aria-label="Filter by analysis ID"
          className="field flex-1"
          placeholder="Filter by analysis ID"
          value={filter}
          onChange={(e) => {
            setFilter(e.target.value);
            setShown(25);
          }}
        />
        <Button asChild>
          <a
            href={`${BASE}/api/audit/export${filter ? `?analysis_id=${encodeURIComponent(filter)}` : ""}`}
          >
            Export audit CSV
          </a>
        </Button>
      </div>
      {q.error ? (
        <ErrorBox error={q.error} />
      ) : !q.data ? (
        <Loading />
      ) : (
        <>
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            {[
              ["Calls", q.data.totals.calls],
              [
                "Known tokens",
                q.data.totals.input_tokens + q.data.totals.output_tokens,
              ],
              ["Correction attempts", q.data.totals.correction_attempts],
              [
                "Correction success",
                q.data.totals.correction_success_rate === null
                  ? "—"
                  : `${(q.data.totals.correction_success_rate * 100).toFixed(1)}%`,
              ],
            ].map(([k, v]) => (
              <div className="panel p-5" key={k}>
                <p className="subtle">{k}</p>
                <strong className="text-2xl">{v}</strong>
              </div>
            ))}
          </div>
          <p className="subtle mb-4">
            {q.data.totals.unknown_usage_calls} calls have unknown token usage.
            Replay entries are labelled and incur no model usage.
          </p>
          <div className="panel divide-y">
            {q.data.calls.slice(0, shown).map((c) => (
              <details key={c.id} className="p-4">
                <summary className="cursor-pointer text-sm flex flex-wrap gap-4">
                  <strong>{c.purpose}</strong>
                  <span>{c.model}</span>
                  <span>{c.status}</span>
                  <span>
                    {c.input_tokens ?? "—"} / {c.output_tokens ?? "—"} tokens
                  </span>
                  <span>{c.latency_ms.toFixed(0)} ms</span>
                  <span>{c.prompt_version}</span>
                </summary>
                <p className="text-xs mt-3">
                  {c.analysis_id ? (
                    <>
                      Analysis:{" "}
                      <Link
                        className="text-primary underline"
                        href={`/datasets/${c.dataset_id}/ask?analysis=${c.analysis_id}`}
                      >
                        open analysis {c.analysis_id.slice(0, 8)}
                      </Link>{" "}
                      ·{" "}
                      <button
                        type="button"
                        className="underline"
                        onClick={() => {
                          setFilter(c.analysis_id!);
                          setShown(25);
                        }}
                      >
                        show only this analysis
                      </button>
                    </>
                  ) : (
                    <>
                      Dataset content (summary or suggestions) ·{" "}
                      <Link
                        className="text-primary underline"
                        href={`/datasets/${c.dataset_id}`}
                      >
                        open dataset
                      </Link>
                    </>
                  )}
                </p>
                <pre className="overflow-auto text-xs bg-muted p-4 mt-3">
                  {JSON.stringify(
                    { request: c.request_json, response: c.response_json },
                    null,
                    2,
                  )}
                </pre>
              </details>
            ))}
            {!q.data.calls.length && (
              <p className="p-6 subtle">No calls recorded for this filter.</p>
            )}
          </div>
          {q.data.calls.length > 0 && (
            <div className="flex flex-wrap items-center gap-3 mt-4">
              <span className="subtle text-xs" role="status">
                Showing {Math.min(shown, q.data.calls.length)} of{" "}
                {q.data.calls.length} calls, newest first.
              </span>
              {shown < q.data.calls.length && (
                <Button variant="outline" onClick={() => setShown(shown + 25)}>
                  Show 25 more
                </Button>
              )}
            </div>
          )}
        </>
      )}
    </>
  );
}
