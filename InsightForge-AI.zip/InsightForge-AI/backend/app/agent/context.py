"""Bound model evidence independently of query row limits."""

import json


def bound_result(result, max_chars=128000):
    result = dict(result)
    rows, used, shortened = [], 0, False
    for row in result["rows"]:
        # Do not alter any cell: truncated text is not valid evidence.
        size = len(json.dumps(row, default=str))
        if used + size > max_chars:
            shortened = True
            break
        rows.append(row)
        used += size
    result["rows"] = rows
    result["row_count"] = len(rows)
    result["truncated"] = result["truncated"] or shortened
    result["evidence_limited"] = shortened
    return result


def model_result(result):
    reduced = bound_result({**result, "rows": result["rows"][:20]}, max_chars=10000)
    reduced.pop("chart", None)
    reduced.pop("outliers", None)
    reduced["context_truncated"] = len(reduced["rows"]) < result["row_count"]
    return reduced
