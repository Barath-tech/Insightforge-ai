import asyncio
import io
import json
from pathlib import Path

import pytest
from app.analysis.charts import select_chart
from app.analysis.evidence import confidence, decompose, directional_agreement
from app.analysis.outliers import detect_outliers, enrich_chart
from app.challenge.service import final_result
from app.llm.client import OpenAITransport, get_transport
from app.llm.replay import ReplayTransport
from app.main import app
from app.report.service import ground_content, render_markdown
from app.services.sql_guard import SQLValidationError, validate_sql
from pypdf import PdfReader

from scripts.demo_responses import QUESTION, DemoResponses


def result(rows, types=None):
    return {"rows": rows, "columns": list(rows[0]) if rows else [], "column_types": types or []}


@pytest.mark.parametrize(
    "rows,types,kind",
    [
        ([{"n": 3}], None, "kpi"),
        (
            [{"date": "2024-01-01", "n": 3}, {"date": "2024-02-01", "n": 4}],
            ["DATE", "DOUBLE"],
            "line",
        ),
        ([{"city": "A", "n": 3}, {"city": "B", "n": 4}], None, "bar"),
        ([{"city": "A", "n": 3, "m": 4}, {"city": "B", "n": 4, "m": 5}], None, "grouped_bar"),
        ([{"n": 3, "m": 4}, {"n": 4, "m": 5}], None, "scatter"),
        ([{"label": str(i)} for i in range(25)], None, "table"),
        ([], None, "table"),
    ],
)
def test_chart_rules(rows, types, kind):
    assert select_chart(result(rows, types))["type"] == kind


def test_confidence_monotonic():
    kwargs = dict(sample_size=100, variation=2, verified=True)
    assert confidence(effect=6, **kwargs)["score"] > confidence(effect=1, **kwargs)["score"]
    assert (
        confidence(effect=6, quality_share=0.4, **kwargs)["score"]
        < confidence(effect=6, **kwargs)["score"]
    )
    assert confidence(sample_size=100, effect=100, verified=False)["score"] <= 39


def test_consistency_measures_directional_agreement():
    falling = {
        "complete": True,
        "observed_margin_change": -50.0,
        "target_margin": 9.0,
        "baseline_margin": 10.0,
    }
    rising_cost = [("trend", "delivery_cost", [10.0, 10.0, 10.0, 12.0])]
    falling_cost = [("trend", "delivery_cost", [10.0, 10.0, 10.0, 8.0])]
    assert directional_agreement(falling, rising_cost)["score"] == 1.0
    assert directional_agreement(falling, falling_cost)["score"] == 0.0
    # Availability alone earns nothing: one signal or an uninterpretable measure is neutral.
    assert directional_agreement(falling, [])["score"] == 0.5
    unknown = [("trend", "orders", [1.0, 1.0, 1.0, 5.0])]
    assert directional_agreement(falling, unknown)["comparable"] is False
    mixed = rising_cost + [("margin", "gross_margin", [5.0, 5.0, 5.0, 6.0])]
    assert directional_agreement(falling, mixed)["score"] == 1 / 3


def test_outlier_callouts_consolidated_with_timestamp_labels():
    rows = [{"period_start": f"2024-{m:02d}-01T00:00:00.000", "cost": 12.0} for m in range(1, 10)]
    rows.append({"period_start": "2024-10-01T00:00:00.000", "cost": 14.244})
    chart = select_chart(result(rows, ["TIMESTAMP", "DOUBLE"]), "trend")
    outliers = enrich_chart(result(rows, ["TIMESTAMP", "DOUBLE"]), chart)
    assert len(outliers) == 1
    (item,) = outliers
    assert item["row_key"] == "2024-10-01"
    assert item["callout"].startswith("2024-10-01: cost is 14.244")
    assert item["callout"].count("00:00") == 0
    assert set(item["methods"]) >= {"iqr", "rolling_baseline"}
    assert item["method"] == "rolling_baseline"
    assert len(item["detections"]) == len(item["methods"])


def test_scatter_outliers_use_descriptive_labels():
    slots = ["A", "B", "C", "D", "E"]
    rows = [
        {"period": "baseline", "slot": s, "n": 40 + i, "sales": 4000.0 + i}
        for i, s in enumerate(slots)
    ]
    rows.append({"period": "target", "slot": "Peak", "n": 400, "sales": 40000.0})
    chart = {"type": "scatter", "x": "n", "y": ["sales"], "rows": rows}
    labels = {o["row_key"] for o in enrich_chart(result(rows), chart)}
    assert labels == {"target · Peak"}


def test_mixed_scale_measures_use_secondary_axis():
    rows = [
        {"city": "Leeds", "refund_rate": 0.24, "refund_amount": 3763.4},
        {"city": "York", "refund_rate": 0.03, "refund_amount": 402.7},
    ]
    chart = select_chart(result(rows))
    assert chart["type"] == "grouped_bar"
    assert chart["secondary_y"] == ["refund_rate"]
    assert chart["y_label"] == "refund_amount"
    similar = [{"city": "A", "n": 3, "m": 4}, {"city": "B", "n": 4, "m": 5}]
    assert select_chart(result(similar))["secondary_y"] == []


def test_partial_challenge_cannot_use_earlier_step():
    from app.agent.contracts import Plan

    from scripts.demo_responses import plan

    two_steps = Plan.model_validate(plan([("first", "First"), ("final", "Final")]))
    ok = {"step_id": "first", "status": "ok", "result_json": {"rows": [{"x": 1}]}}
    failed_final = {"step_id": "final", "status": "execution_error", "result_json": None}
    failed = {"status": "failed", "steps": [ok, failed_final]}
    assert final_result(failed, two_steps)[0] is None
    assert "partial" in final_result(failed, two_steps)[1]
    incomplete = {"status": "completed", "steps": [ok]}
    assert final_result(incomplete, two_steps)[0] is None
    final = {"step_id": "final", "status": "ok", "result_json": {"rows": [{"x": 2}]}}
    done = {"status": "completed", "steps": [ok, failed_final, final]}
    assert final_result(done, two_steps)[0] is final


def test_grounding_rejects_injected_numbers():
    rendered, checked = ground_content(
        {"situation": "Profit increased 99999%.", "root_cause": "{{e:delta}}"}, {"delta": 18.7}, []
    )
    assert checked["status"] == "unverified"
    assert "99999" not in rendered["situation"]
    assert rendered["root_cause"] == "18.7"


def test_safe_temporal_function_and_negative_guard():
    assert validate_sql("SELECT DATE_TRUNC('month', d) FROM sales", ["sales"])
    for query in [
        "SELECT * FROM read_csv('/etc/passwd')",
        "WITH x AS (DELETE FROM sales RETURNING *) SELECT * FROM x",
    ]:
        with pytest.raises(SQLValidationError):
            validate_sql(query, ["sales"])


def test_outliers_and_drivers_from_executed_demo(client):
    from app.models.metadata import Dataset
    from app.services.query import submit
    from sqlmodel import Session

    from scripts.demo_responses import component_sql

    d = client.post("/api/datasets/demo").json()
    with Session(app.state.test_engine) as session:
        dataset = session.get(Dataset, d["id"])
        r = submit(session, dataset, component_sql("uk_retail_operations"))["result"]
        drivers = decompose(r["rows"])
        assert drivers["drivers"][0]["component"] == "delivery_cost"
        assert drivers["drivers"][0]["dimension"] == "Peak"
        assert drivers["drivers"][1]["component"] == "refund_amount"
        assert 18 < drivers["drivers"][0]["change_pct"] < 19
        assert (
            abs(
                drivers["within_group_change"]
                + drivers["mix_residual"]
                - drivers["observed_margin_change"]
            )
            < 1e-8
        )
        for step in ["trend", "refunds"]:
            response = asyncio.run(DemoResponses().request("sql", {"step": {"id": step}}, None))
            r = submit(session, dataset, response["sql"])["result"]
            x = "period_start" if step == "trend" else "city"
            outliers = detect_outliers(r, x)
            if step == "trend":
                assert any(18 < o["deviation_pct"] < 19 for o in outliers if o["deviation_pct"])
            else:
                assert {"Leeds", "Cardiff"} <= {r["rows"][o["row_index"]]["city"] for o in outliers}


def events(response):
    return [
        json.loads(line[6:]) for line in response.text.splitlines() if line.startswith("data: ")
    ]


def test_full_replay_no_network_exports_and_manual_edit(client, monkeypatch):
    async def forbidden(*args, **kwargs):
        raise AssertionError("OpenAI transport must never be used in replay")

    monkeypatch.setattr(OpenAITransport, "request", forbidden)
    cache = Path(__file__).resolve().parents[2] / "data/demo_cache"
    app.dependency_overrides[get_transport] = lambda: ReplayTransport(
        "replay", OpenAITransport(), cache
    )
    d = client.post("/api/datasets/demo").json()["id"]
    narrative = client.post(f"/api/datasets/{d}/narrative").json()
    assert "23" in narrative["narrative"] and "47" in narrative["narrative"]
    stream = events(client.post(f"/api/datasets/{d}/ask", json={"question": QUESTION}))
    assert stream[-1]["payload"]["status"] == "completed", stream
    assert any(e["type"] == "correction" for e in stream)
    aid = stream[0]["analysis_id"]
    progress = client.get(f"/api/datasets/{d}/progress").json()
    assert progress["completed_analyses"] == 1 and progress["latest_completed_analysis_id"] == aid
    assert progress["pinned_findings"] == 0 and progress["briefs"] == []
    assert client.get("/api/datasets/unknown/progress").status_code == 404
    finding = client.get(f"/api/analyses/{aid}").json()["finding_json"]
    assert finding["confidence"]["label"] in {"High", "Medium"}
    assert "+18.7%" in finding["driver_summary"]
    stream = events(client.post(f"/api/analyses/{aid}/challenge"))
    assert stream[-1]["payload"]["status"] == "completed", stream
    ch = next(e["payload"] for e in stream if e["type"] == "challenge")
    assert len(ch["hypotheses"]) >= 4
    assert len(ch["quality_checks"]) == 2
    assert all(q.get("query_run", {}).get("status") == "ok" for q in ch["quality_checks"])
    assert ch["hypotheses"][0]["verdict"] == "INCONCLUSIVE"
    for kind, identifier in [("analyses", aid), ("challenges", ch["id"])]:
        assert (
            client.patch(f"/api/{kind}/{identifier}/pin", json={"pinned": True}).status_code == 200
        )
    response = client.post(f"/api/datasets/{d}/briefs", json={})
    assert response.status_code == 200, response.text
    brief = response.json()
    bid = brief["id"]
    assert brief["grounding_json"]["status"] == "verified"
    progress = client.get(f"/api/datasets/{d}/progress").json()
    assert progress["challenged_analyses"] == 1
    # Challenge test analyses are labelled in history and excluded from progress counts.
    assert progress["completed_analyses"] == 1 and progress["latest_completed_analysis_id"] == aid
    history = client.get(f"/api/datasets/{d}/analyses").json()
    tests = [a for a in history if a["challenge_of"]]
    assert {a["challenge_of"] for a in tests} == {aid} and len(tests) == len(ch["hypotheses"])
    assert next(a for a in history if a["id"] == aid)["challenge_of"] is None
    assert (progress["pinned_findings"], progress["pinned_challenges"]) == (1, 1)
    assert [b["id"] for b in progress["briefs"]] == [bid]
    assert progress["briefs"][0]["grounding_status"] == "verified"
    md = client.get(f"/api/briefs/{bid}/markdown").text
    for section in [
        "Situation",
        "Evidence",
        "Root Cause",
        "Business Impact",
        "Recommended Actions",
    ]:
        assert "## " + section in md
    pdf = client.get(f"/api/briefs/{bid}/pdf")
    reader = PdfReader(io.BytesIO(pdf.content))
    assert len(reader.pages) >= 2
    assert "Recommended Actions" in reader.pages[0].extract_text()
    assert "SQL Appendix" in reader.pages[1].extract_text()
    edited = client.patch(
        f"/api/briefs/{bid}", json={"business_impact": "We saved £999999."}
    ).json()
    assert edited["grounding_json"]["status"] == "unverified"
    assert "999999" not in edited["content_json"]["business_impact"]
    audit = client.get("/api/audit").json()
    assert audit["totals"]["correction_attempts"] >= 1
    assert all(c["model"].startswith("replay:") for c in audit["calls"])
    assert client.get("/api/audit/export").headers["content-type"].startswith("text/csv")


def synthetic_brief(content, numbers=None, templates=True):
    from datetime import datetime

    from app.models.final import Brief

    evidence = {
        "dataset_name": "Test dataset",
        "sql": [{"step_id": "s1", "sql": "SELECT 'London' AS city WHERE 1 <= 2"}],
        "numbers": numbers or {"findings.0.delta": 18.7},
        "sources": ["finding:0", "finding:0/step:s1"],
        "findings": [],
    }
    if templates:
        evidence["templates"] = content
    return Brief(
        dataset_id="test",
        title="Test brief",
        audience="Leaders",
        created_at=datetime(2024, 1, 1),
        content_json=ground_content(content, evidence["numbers"], evidence["sources"])[0],
        evidence_json=evidence,
        grounding_json={"status": "verified", "errors": []},
    )


BASE_CONTENT = {
    "situation": "Margin declined.",
    "evidence": [{"text": "Delivery cost rose {{e:findings.0.delta}}%.", "source": "finding:0"}],
    "root_cause": "Peak delivery cost.",
    "business_impact": "Margin was lost.",
    "recommended_actions": [
        {
            "owner_role": "Operations",
            "priority": "High",
            "expected_impact": "Review peak pricing.",
            "linked_evidence": "finding:0",
        }
    ],
    "risks_and_caveats": ["Observational evidence."],
    "confidence_statement": "Moderate evidence.",
}


def test_structured_brief_edits_reground_whole_brief():
    from app.report.service import edit_content

    brief = synthetic_brief(BASE_CONTENT)
    assert brief.content_json["evidence"][0]["text"] == "Delivery cost rose 18.7%."
    actions = [
        *BASE_CONTENT["recommended_actions"],
        {
            "owner_role": "Finance",
            "priority": "Medium",
            "expected_impact": "Track the {{e:findings.0.delta}}% change monthly.",
            "linked_evidence": "finding:0/step:s1",
        },
    ]
    content, templates, grounding = edit_content(brief, {"recommended_actions": actions})
    assert grounding == {"status": "verified", "errors": []}
    assert content["recommended_actions"][1]["expected_impact"] == "Track the 18.7% change monthly."
    assert content["evidence"][0]["text"] == "Delivery cost rose 18.7%."
    assert templates["recommended_actions"][1]["expected_impact"].startswith("Track the {{e:")
    bad = [{"text": "Costs rose 42%.", "source": "finding:9"}]
    brief.content_json, brief.evidence_json["templates"] = content, templates
    content, templates, grounding = edit_content(brief, {"evidence": bad})
    assert grounding["status"] == "unverified"
    assert "42" not in content["evidence"][0]["text"]
    assert content["evidence"][0]["source"] == "[UNVERIFIED SOURCE]"
    # Correcting the section restores verification instead of accumulating stale errors.
    brief.content_json, brief.evidence_json["templates"] = content, templates
    fixed = [{"text": "Costs rose {{e:findings.0.delta}}%.", "source": "finding:0"}]
    assert edit_content(brief, {"evidence": fixed})[2]["status"] == "verified"
    with pytest.raises(ValueError):
        edit_content(brief, {"evidence": [{"text": "x"}]})


def test_legacy_brief_edit_without_templates_keeps_prior_errors():
    from app.report.service import edit_content

    brief = synthetic_brief(BASE_CONTENT, templates=False)
    brief.grounding_json = {"status": "unverified", "errors": ["Unknown numeric evidence: x"]}
    content, templates, grounding = edit_content(brief, {"situation": "Updated."})
    assert templates is None and content["situation"] == "Updated."
    assert grounding["status"] == "unverified"


def test_longest_brief_fits_one_page():
    from app.report.service import BriefContent, render_pdf

    limits = {
        name: field.metadata[0].max_length if field.metadata else None
        for name, field in BriefContent.model_fields.items()
    }
    words = "Peak delivery costs rose against baseline across London stores "

    def text(n):
        return (words * (n // len(words) + 1))[: n - 1].rstrip() + "."

    content = {
        "situation": text(limits["situation"]),
        "evidence": [{"text": text(500), "source": "finding:0"}] * 3,
        "root_cause": text(limits["root_cause"]),
        "business_impact": text(limits["business_impact"]),
        "recommended_actions": [
            {
                "owner_role": text(70),
                "priority": "High",
                "expected_impact": text(350),
                "linked_evidence": "finding:0/step:s1",
            }
        ]
        * 3,
        "risks_and_caveats": [text(350)] * 3,
        "confidence_statement": text(limits["confidence_statement"]),
    }
    BriefContent.model_validate(content)
    brief = synthetic_brief(content)
    chart = select_chart(
        result(
            [{"month": f"2024-{m:02d}-01", "cost": 12.0 + m} for m in range(1, 11)],
            ["DATE", "DOUBLE"],
        )
    )
    brief.evidence_json["findings"] = [{"finding": {"primary_chart": chart}}]
    reader = PdfReader(io.BytesIO(render_pdf(brief)))
    first, second = (reader.pages[i].extract_text() for i in range(2))
    assert "Recommended Actions" in first and "Data quality" in first
    assert "Grounding:" in first
    assert second.lstrip().startswith("SQL Appendix") or "SQL Appendix" in second.split("\n")[0]
    assert "SELECT 'London' AS city WHERE 1 <= 2" in second
    assert "&#x27;" not in second and "&lt;" not in second


def test_gateway_client_options(monkeypatch):
    import ssl

    import certifi
    import httpx
    from app.core.config import settings
    from app.llm.client import client_options

    monkeypatch.setattr(settings, "openai_api_key", "test-key")
    for name, value in [("openai_base_url", ""), ("openai_ca_bundle", "")]:
        monkeypatch.setattr(settings, name, value)
    monkeypatch.setattr(settings, "openai_verify_ssl", True)
    default = client_options()
    # Default behaviour is unchanged: official endpoint and the SDK's own HTTP client.
    assert "base_url" not in default and "http_client" not in default
    assert default["max_retries"] == 0 and default["api_key"] == "test-key"

    monkeypatch.setattr(settings, "openai_base_url", "https://gateway.example/")
    monkeypatch.setattr(settings, "openai_ca_bundle", certifi.where())
    gateway = client_options()
    assert gateway["base_url"] == "https://gateway.example/"
    assert isinstance(gateway["http_client"], httpx.AsyncClient)
    context = gateway["http_client"]._transport._pool._ssl_context
    assert isinstance(context, ssl.SSLContext) and context.verify_mode == ssl.CERT_REQUIRED
    asyncio.run(gateway["http_client"].aclose())

    monkeypatch.setattr(settings, "openai_verify_ssl", False)
    insecure = client_options()
    assert insecure["http_client"]._transport._pool._ssl_context.verify_mode == ssl.CERT_NONE
    asyncio.run(insecure["http_client"].aclose())


def test_markdown_snapshot():
    from datetime import datetime

    from app.models.final import Brief

    brief = Brief(
        dataset_id="test",
        title="Test brief",
        audience="Leaders",
        created_at=datetime(2024, 1, 1),
        content_json={
            "situation": "Situation text",
            "evidence": [],
            "root_cause": "Root text",
            "business_impact": "Impact text",
            "recommended_actions": [],
            "risks_and_caveats": [],
            "confidence_statement": "Limited evidence",
        },
        evidence_json={"dataset_name": "Test dataset", "sql": []},
        grounding_json={"status": "verified", "errors": []},
    )
    expected = Path(__file__).with_name("snapshots") / "brief.md"
    assert render_markdown(brief) == expected.read_text()
