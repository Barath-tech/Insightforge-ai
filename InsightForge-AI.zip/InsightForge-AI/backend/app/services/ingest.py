import sqlite3
from pathlib import Path
from uuid import uuid4

import duckdb

from app.core.config import settings
from app.models.metadata import Dataset, DatasetProfile
from app.services.profiling import clean_and_profile, snake


def quote(name):
    return '"' + name.replace('"', '""') + '"'


def ingest(path: Path, filename: str, session):
    extension = Path(filename).suffix.lower()
    if extension not in {".csv", ".sqlite", ".db"}:
        raise ValueError("Upload a .csv, .sqlite, or .db file.")
    identifier = str(uuid4())
    folder = settings.data_dir / "datasets"
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{identifier}.duckdb"
    tables, profiles, total = [], {}, 0
    try:
        with duckdb.connect(str(target)) as conn:
            conn.execute("SET memory_limit='512MB'")
            conn.execute("SET threads=2")
            frames = []
            if extension == ".csv":
                try:
                    frame = conn.execute(
                        "SELECT * FROM read_csv_auto(?, sample_size=-1) LIMIT ?",
                        [str(path), settings.max_rows + 1],
                    ).fetchdf()
                except duckdb.Error:
                    frame = conn.execute(
                        "SELECT * FROM read_csv_auto(?, all_varchar=true) LIMIT ?",
                        [str(path), settings.max_rows + 1],
                    ).fetchdf()
                frames.append((Path(filename).stem, frame))
            else:
                # Inspect names read-only using stdlib; all table data is copied through DuckDB.
                with sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True) as source:
                    names = [
                        r[0]
                        for r in source.execute(
                            "SELECT name FROM sqlite_master WHERE type='table' "
                            "AND name NOT LIKE 'sqlite_%' ORDER BY name"
                        )
                    ]
                if not names:
                    raise ValueError("SQLite database has no user tables.")
                extension_dir = settings.data_dir / "extensions"
                extension_dir.mkdir(exist_ok=True)
                conn.execute("SET extension_directory = ?", [str(extension_dir.resolve())])
                conn.execute("LOAD sqlite")
                for name in names:
                    frame = conn.execute(
                        "SELECT * FROM sqlite_scan(?, ?) LIMIT ?",
                        [str(path), name, settings.max_rows + 1],
                    ).fetchdf()
                    frames.append((name, frame))
                    if sum(len(f) for _, f in frames) > settings.max_rows:
                        raise ValueError(f"Dataset exceeds the {settings.max_rows:,}-row limit.")
            reserved = set()
            for original_name, raw in frames:
                total += len(raw)
                if total > settings.max_rows:
                    raise ValueError(f"Dataset exceeds the {settings.max_rows:,}-row limit.")
                base = snake(original_name)
                name, suffix = base, 2
                while name in reserved or f"raw_{name}" in reserved:
                    name, suffix = f"{base}_{suffix}", suffix + 1
                reserved.update([name, f"raw_{name}"])
                conn.register("upload_frame", raw)
                conn.execute(f"CREATE TABLE {quote('raw_' + name)} AS SELECT * FROM upload_frame")
                cleaned, profile = clean_and_profile(raw)
                conn.register("clean_frame", cleaned)
                conn.execute(f"CREATE TABLE {quote(name)} AS SELECT * FROM clean_frame")
                profile["schema"] = [
                    {"name": r[0], "type": r[1]}
                    for r in conn.execute(f"DESCRIBE {quote(name)}").fetchall()
                ]
                profiles[name] = profile
                tables.extend([name, "raw_" + name])
            conn.unregister("upload_frame")
            conn.unregister("clean_frame")
        dataset = Dataset(
            id=identifier,
            name=Path(filename).stem,
            source_type="csv" if extension == ".csv" else "sqlite",
            original_filename=filename,
            duckdb_path=str(target),
            table_names=tables,
            row_count=total,
        )
        health = round(sum(p["health_score"] for p in profiles.values()) / len(profiles))
        session.add(dataset)
        session.add(
            DatasetProfile(
                dataset_id=identifier, profile_json={"tables": profiles}, health_score=health
            )
        )
        session.commit()
        session.refresh(dataset)
        return dataset
    except Exception:
        session.rollback()
        target.unlink(missing_ok=True)
        raise
