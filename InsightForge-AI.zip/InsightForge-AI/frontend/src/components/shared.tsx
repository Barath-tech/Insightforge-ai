"use client";
import { AlertCircle, Loader2 } from "lucide-react";
import { Button } from "./ui/button";
export function Loading() {
  return (
    <div
      className="panel p-10 flex items-center gap-3 text-muted-foreground"
      role="status"
    >
      <Loader2 className="animate-spin" size={18} />
      Loading your data…
    </div>
  );
}
export function ErrorBox({
  error,
  retry,
}: {
  error: unknown;
  retry?: () => void;
}) {
  return (
    <div
      className="rounded-lg border border-red-300 bg-red-50 dark:bg-red-950/30 p-4 text-red-700 dark:text-red-300 flex gap-3 items-start"
      role="alert"
    >
      <AlertCircle size={18} className="shrink-0 mt-0.5" />
      <div>
        <p className="text-sm whitespace-pre-wrap">
          {error instanceof Error ? error.message : String(error)}
        </p>
        {retry && (
          <Button className="mt-3" variant="outline" onClick={retry}>
            Try again
          </Button>
        )}
      </div>
    </div>
  );
}
export function DataTable({
  columns,
  rows,
}: {
  columns: string[];
  rows: Record<string, unknown>[];
}) {
  return (
    <div className="overflow-auto max-h-[540px]">
      <table className="w-full text-sm text-left">
        <thead className="sticky top-0 bg-muted">
          <tr>
            {columns.map((c) => (
              <th className="px-4 py-3 font-medium whitespace-nowrap" key={c}>
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-t hover:bg-muted/50">
              {columns.map((c) => (
                <td
                  key={c}
                  className="px-4 py-3 whitespace-nowrap max-w-[360px] truncate"
                  title={r[c] === null ? "NULL" : String(r[c])}
                >
                  {r[c] === null ? (
                    <span className="text-muted-foreground italic">NULL</span>
                  ) : (
                    String(r[c])
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {!rows.length && (
        <p className="p-8 subtle text-center">No rows to display.</p>
      )}
    </div>
  );
}
