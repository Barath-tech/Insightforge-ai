"use client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { analysisApi } from "@/lib/api";
import { Button } from "./ui/button";
import { ErrorBox } from "./shared";

export function HealthNarrative({ id }: { id: string }) {
  const cache = useQueryClient();
  const refresh = useMutation({
    mutationFn: () => analysisApi.narrative(id, true),
    onSuccess: (data) => cache.setQueryData(["narrative", id], data),
  });
  const narrative = useQuery({
    queryKey: ["narrative", id],
    queryFn: () => analysisApi.narrative(id),
    staleTime: Infinity,
    retry: false,
    refetchOnWindowFocus: false,
  });
  return (
    <section className="panel p-6 mt-6" aria-label="Data health summary">
      <div className="flex items-center justify-between gap-4">
        <h2 className="font-semibold">What your data tells us</h2>
        <Button
          variant="outline"
          disabled={narrative.isFetching || refresh.isPending}
          onClick={() => refresh.mutate()}
        >
          Refresh summary
        </Button>
      </div>
      {narrative.isPending && (
        <p className="subtle mt-3" role="status">
          Preparing a grounded profile summary…
        </p>
      )}
      {(narrative.error || refresh.error) && (
        <ErrorBox error={narrative.error || refresh.error} />
      )}
      {narrative.data && (
        <>
          <p className="text-sm leading-7 mt-4">{narrative.data.narrative}</p>
          <p className="subtle text-xs mt-3">
            {narrative.data.status === "fallback"
              ? "Deterministic summary · AI unavailable or could not be verified"
              : "Checked against deterministic profile facts"}
          </p>
          <details className="mt-3 text-xs subtle">
            <summary className="cursor-pointer">Supporting facts</summary>
            <ul className="mt-2 space-y-1">
              {narrative.data.fact_refs.map((ref) => (
                <li key={ref}>{ref}</li>
              ))}
            </ul>
          </details>
        </>
      )}
    </section>
  );
}
