# InsightForge AI

An evidence-first analytics workspace for CSV and SQLite exports. InsightForge profiles and cleans data deterministically, lets a language model **plan** analyses and **propose** SQL, executes that SQL through a strict read-only guard, and turns only executed results into cited findings, challenge tests, and a one-page executive brief.

> **The rule:** every number shown to a user comes from executed SQL or deterministic profiling — never from the model.

To run it, see **[HOW_TO_RUN.md](HOW_TO_RUN.md)**. For model usage, contracts, and replay details, see **[docs/OPENAI_USAGE.md](docs/OPENAI_USAGE.md)**. Outstanding work is tracked in **[REMAINING.md](REMAINING.md)**.

## Features

| Area | What it does |
|---|---|
| **Data library** | Upload CSV/SQLite/DB (50 MB default) or load the generated UK retail demo (messy CSV, clean CSV fallback, SQLite fallback). |
| **Data Health** | Health score, row/column/ID/date KPIs, severity-ranked quality issues with samples, column profiles, cleaning log, original→clean schema mapping, paged raw and clean previews, and a fact-checked narrative. Issue links prefill (never submit) an Ask question. |
| **SQL workspace** | Single read-only SELECT (CTEs, joins, set operations) against raw or clean tables, with validation errors, bounded results, and an audited history. |
| **Ask InsightForge** | Question → typed plan → SQL per step → guard → isolated execution → bounded correction (≤3 attempts/step) → finding with cited key numbers. Live SSE timeline, attempt diffs, and saved history. |
| **Charts & evidence** | Deterministic chart selection (KPI, line, bar, grouped bar with secondary axis for mixed scales, scatter, table), consolidated outlier callouts (robust z, IQR, trailing baseline), chart-type switching, PNG export, ranked driver decomposition, a margin bridge (waterfall), and an explained confidence score. |
| **Challenge My Insight** | 3–5 model-proposed alternative explanations, each tested through the same guarded pipeline and judged SUPPORTED / REFUTED / INCONCLUSIVE in code, plus valid-dates and deduplicated reruns. Revises confidence. |
| **Executive brief** | Pin findings and challenges, generate a one-page brief (Situation, Evidence, Root Cause, Business Impact, Recommended Actions, caveats), edit every section inline (including structured Evidence and Actions lists) with re-grounding, and export PDF (with chart and SQL appendix) or Markdown. |
| **AI Transparency** | Every model call with purpose, model, prompt version, latency, status, token usage (NULL when unknown), and redacted request/response; correction metrics; CSV export. |
| **Offline replay** | `DEMO_REPLAY=replay` runs the scripted London demo end to end with no API key and no network. |
| **Orientation** | Breadcrumbs, a mode badge (Offline replay / Live AI / API offline), a dataset-scoped sidebar, and an *Analysis journey* tracker (Inspect health → Ask → Challenge → Pin → Brief) that marks completed steps and highlights the next one. Each finding shows a *Next step* hint; challenge tests are labelled in history and link back to the original finding; analyses are deep-linkable (`/ask?analysis=<id>`); briefs link to their evidence and sibling briefs; audit rows link to their analysis. Page titles name the current page and dataset; skip link, focus outlines, and a mobile navigation menu are included. |

## Architecture

```text
Browser: Next.js 14 App Router / TypeScript / Tailwind / shadcn-style UI
   │  TanStack Query, Zod validation (src/lib/api.ts), Recharts, SSE fetch streaming
   ▼
FastAPI routers (HTTP/SSE only)
   ├─ services/ingest, profiling ─► DuckDB per dataset: raw_<table> + <table> (typed, duplicates kept)
   ├─ services/query ─► sql_guard (sqlglot AST) ─► executor (spawned read-only DuckDB worker)
   ├─ agent/pipeline ─► llm/client (Structured Outputs, audited) ─► query ─► checks ─► grounding
   ├─ analysis/charts, outliers, evidence ─► charts, callouts, decomposition, confidence
   ├─ challenge/service ─► hypotheses ─► pipeline per test ─► verdicts + quality reruns
   ├─ report/service ─► brief grounding, Markdown/PDF (WeasyPrint, matplotlib)
   └─ SQLModel metadata (SQLite): datasets, profiles, query_runs, analyses,
      analysis_steps, llm_calls, challenges, pins, briefs
```

```text
backend/app/routers      HTTP and SSE handling only
backend/app/services     ingestion, profiling, schema, guard, executor, query, grounding, AI content
backend/app/agent        contracts, pipeline, checks, context bounds, events, persistence
backend/app/analysis     charts, outliers, evidence/decomposition/confidence
backend/app/challenge    Challenge My Insight
backend/app/report       brief generation, editing, Markdown/PDF rendering
backend/app/llm          client, replay transport, redaction, versioned prompts
backend/app/models       SQLModel metadata tables (additive only)
frontend/src             App Router pages, components, typed API client
scripts                  data generator, demo launcher, replay seeding
data/samples             generated fixtures (+ test-only ground truth)
data/demo_cache          committed scripted replay fixtures
```

## How an analysis works

1. **Plan.** The model returns a typed `Plan`: intent, metrics, filters, assumptions, and ≤5 ordered steps. Unanswerable questions stop here.
2. **SQL.** For each step the model proposes SQL. `services/query.py` records exactly one `query_runs` row per attempt (`source="agent"`), validates with `sql_guard`, and runs it in the isolated executor.
3. **Check and correct.** Empty results, all-null measures, duplicate aliases, and negative values for declared non-negative metrics trigger correction. Corrections must keep every original WHERE/HAVING predicate. Three failed attempts stop the analysis with *insufficient evidence*.
4. **Finding.** The model writes prose using `{{n0}}` placeholders and cites `step/attempt/column/row` cells. The server verifies each cell and renders the numbers. One grounding repair is allowed; otherwise the finding is saved as **unverified** with reasons.
5. **Evidence.** Charts, outliers, decomposition, source-table counts, quality issues, and confidence are computed in Python from successful results.
6. **Challenge (optional).** Alternative hypotheses run as child analyses. Only a completed test whose final planned step succeeded can produce a verdict; partial failures are INCONCLUSIVE.
7. **Brief (optional).** The model writes sections using `{{e:path}}` evidence tokens and known source references; anything else is removed and flagged.

## Safety model

- **SQL guard:** one SELECT only, full AST inspection including CTEs. Rejects DDL/DML, COPY, ATTACH/DETACH, INSTALL/LOAD, PRAGMA, SET, transactions, SELECT INTO, table functions (e.g. `read_csv`), qualified/external/unknown tables, and unknown functions (deny by default). Policy changes require negative tests.
- **Executor:** separate spawned process; read-only DuckDB; external access and extension autoloading disabled; 256 MB memory; one thread; no disk spill; bounded fetch (`QUERY_MAX_ROWS`). `QUERY_TIMEOUT_SECONDS` measures query execution after the worker connects; worker start-up has its own 30-second bound.
- **No autonomous tools:** no arbitrary Python, shell, or browsing. The model only returns validated structured payloads.
- **Data integrity:** raw tables are preserved; duplicates are retained and disclosed; invalid values are flagged and counted, not silently repaired. Negative profit is valid.
- **Secrets:** only the backend reads `OPENAI_API_KEY`. Audits redact credentials, tokens, e-mails, paths, identifiers, questions, rows, and samples.
- **Ground truth isolation:** `data/samples/ground_truth.json` is read only by generator tests, never by application code or prompts.

## Confidence score

A transparent heuristic of evidence strength — **not** a probability or proof of causation:

| Factor | Contribution |
|---|---|
| Sample adequacy | `25 × min(1, min(baseline_n, target_n) / 100)` |
| Effect vs variation | `25 × min(1, |effect| / (3 × baseline std))`; 0 without a measured baseline series |
| Cross-step consistency | `15 × agreement`, where agreement is the share of agreeing pairs among independent directional signals (decomposition margin change; time-series measures mapped to their implied margin direction). Neutral 0.5 with fewer than two comparable signals |
| Grounding verified | `+35` if numeric grounding passed |
| Data-quality penalty | `−30 × share` of rows in relevant quality issues (conservative upper bound) |
| Repair penalty | `−2` per correction/repair, capped at `−10` |

The score is clamped to 0–100 and capped at 39 when grounding is unverified. Labels: High ≥ 75, Medium ≥ 50, Low otherwise.

**Challenge revision:** +2 per refuted alternative (max +6), −5 per supported alternative, −15 per supported data-quality artefact; inconclusive tests add nothing. In the demo, 81 → 87.

## Demo dataset

`scripts/generate_uk_retail.py` (seed 42) creates **4,850 unique orders + 23 duplicated rows = 4,873 rows** across 12 UK cities for January–December 2024, written to `data/samples/` as a messy CSV, a SQLite copy of the same messy data, and a clean fallback CSV. Regeneration is byte-stable.

Gross margin (GBP) = `revenue − cogs − delivery_cost − refund_amount`.

Planted characteristics: 47 delivered orders missing timestamps, mixed UK/ISO/named-month dates, 5 invalid dates, city casing/whitespace variants, currency strings, 3 negative quantities, 3 discounts over 100%, a London October peak-slot delivery cost uplift of 18.7%, and higher refund rates in Leeds and Cardiff. These are generator facts for tests, not application constants.

### Offline demo results

Question: **"Why did profit margin decline in London in October?"**

- First components query fails on a misspelt column and is corrected on attempt 2.
- Primary driver: Peak delivery cost **+18.7%**; secondary: Peak refunds. Finding verified; confidence **81 (High)**.
- Challenge: product mix, channel concentration, and pricing refuted; seasonality inconclusive (no prior-year data); valid-dates and deduplicated reruns do not change the conclusion. Confidence **81 → 87**.
- Brief: verified; estimated margin lost ≈ £15.54 at the target-order count.

## Profiling and cleaning

Column names become unique snake_case with an original→clean mapping. Categorical text is trimmed and title-cased; identifiers keep their case. Currency symbols and thousands separators are removed before numeric conversion. UK slash dates are day/month/year; ISO and named-month dates are supported; invalid dates become NULL; ISO offsets normalise to UTC. Profiles include semantic types, missing counts, distinct counts, numeric statistics and histograms, top categories, date ranges, schema, and transformation counts.

**Health score** per table: `max(0, 100 − 8 × high − 4 × medium − 1 × low)`; the dataset score is the table mean. It is a triage heuristic, not a statistical guarantee.

## Offline replay and provenance

`DEMO_REPLAY=replay` reads responses from `data/demo_cache/<sha256>.json`, keyed by purpose, canonical context (volatile IDs and timings removed), response schema, prompt, prompt version, and model. A miss is an error and never reaches the network. Committed fixtures are **scripted** (`"provenance": "scripted_fixture"`), produced by `make seed-replay` running the real services with the disclosed `scripts/demo_responses.py` transport; they contain no planted numbers. They are not live-model recordings. See [docs/OPENAI_USAGE.md](docs/OPENAI_USAGE.md).

Replay is exact: other questions, datasets, prompts, or models miss. Error text is part of the correction context, so a timing-dependent failure (for example a query timeout on an overloaded machine) also misses — raise `QUERY_TIMEOUT_SECONDS` on slow hosts.

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Status, phase, AI availability, replay mode |
| GET / POST | `/api/datasets` | List / upload (multipart `file`) |
| POST | `/api/datasets/demo?sample=messy\|clean\|sqlite` | Import a demo fixture |
| GET | `/api/datasets/{id}` · `/profile` · `/schema` | Metadata · profiles/issues/logs · model-facing schema and facts |
| GET | `/api/datasets/{id}/preview?table=&offset=&limit≤100` | Raw or clean preview |
| POST / GET | `/api/datasets/{id}/query` · `/queries` | Run guarded SQL · latest 50 runs |
| POST | `/api/datasets/{id}/narrative?refresh=` | Grounded narrative or deterministic fallback |
| GET | `/api/datasets/{id}/suggestions` | Five validated questions or fallback |
| POST | `/api/datasets/{id}/ask` | `{"question": ...}`; SSE analysis stream |
| GET | `/api/analyses/{id}` · `/api/datasets/{id}/analyses` | Analysis detail with all attempts · latest 50 (each with `challenge_of`: the challenged finding's ID for Challenge test analyses, else `null`) |
| POST / GET | `/api/analyses/{id}/challenge` · `/challenges` | SSE challenge run · stored challenges |
| PATCH | `/api/{analyses\|challenges}/{id}/pin` | `{"pinned": bool}` |
| GET | `/api/datasets/{id}/pins` | Pinned items |
| GET | `/api/datasets/{id}/progress` | Read-only journey summary: question counts (excluding challenge tests), latest completed analysis, challenged/pinned counts, recent briefs |
| POST | `/api/datasets/{id}/briefs` | Generate a brief from pins or `analysis_ids` |
| GET / PATCH | `/api/briefs/{id}` | Read / edit sections (re-grounded) |
| GET | `/api/briefs/{id}/pdf` · `/markdown` | Exports |
| GET | `/api/audit?analysis_id=` · `/api/audit/export` | Model-call audit · CSV |

Interactive docs: `/docs`. Ask/Challenge preflight errors are ordinary JSON (404/422/429/503); after start, failures arrive as SSE `error` events followed by exactly one `done`. Event envelopes carry `analysis_id`, a strictly increasing `sequence`, `timestamp`, and a typed payload (`plan`, `step_started`, `sql_generated`, `validation`, `execution`, `correction`, `step_done`, `finding`, `error`, `done`). Disconnect or cancel stops model work, joins the query worker, persists `cancelled`, and releases capacity.

## Configuration

`pydantic-settings` reads the root `.env` and environment variables (environment wins).

| Variable | Default | Meaning |
|---|---|---|
| `DATA_DIR` | `./data` | Metadata, samples, extensions, uploaded databases, replay cache |
| `MAX_UPLOAD_MB` / `MAX_ROWS` | 50 / 100000 | Upload limits |
| `QUERY_TIMEOUT_SECONDS` / `QUERY_MAX_ROWS` | 5 / 1000 | Executor limits |
| `CORS_ORIGINS` | `["http://localhost:3000"]` | Allowed frontend origins |
| `NEXT_PUBLIC_API_URL` | `http://localhost:8000` | Browser API origin (frontend build-time) |
| `NEXT_DIST_DIR` | `.next-dev` (dev) / `.next` (build) | Next.js output directory; E2E uses `.next-e2e` |
| `OPENAI_API_KEY` / `OPENAI_MODEL` | empty / `gpt-4.1` | Live model access (an OpenAI key, or a gateway key when `OPENAI_BASE_URL` is set) |
| `OPENAI_BASE_URL` | empty | OpenAI-compatible gateway such as LiteLLM (e.g. `https://genailab.tcs.in/`); empty = api.openai.com |
| `OPENAI_CA_BUNDLE` / `OPENAI_VERIFY_SSL` | empty / `true` | Extra PEM bundle for the model endpoint (system trust store is always used); disabling verification is a last resort |
| `DEMO_REPLAY` | `off` in code; `replay` in `.env.example` and Docker | `off`, `record`, or `replay` |
| `LLM_TIMEOUT_SECONDS` / `LLM_TRANSPORT_RETRIES` | 45 / 1 | Per request; shared retry allowance (SDK retries are zero) |
| `LLM_MAX_OUTPUT_TOKENS` / `LLM_CONTEXT_CHARS` | 4000 / 48000 | Output and context bounds |
| `AGENT_MAX_STEPS` | 5 | Plan step limit |
| `ASK_PER_MINUTE` / `ASK_CONCURRENCY` | 6 / 2 | Process-wide admission for Ask and Challenge |
| `INSIGHTFORGE_LIVE_TEST` | 0 | Enables the paid live test (also needs a key) |

Run **one backend process**: caches, admission limits, and restart recovery are in memory. Startup cancels interrupted work and never replays or re-bills it. Metadata changes are additive only; never delete the metadata database to upgrade.

## Development commands

```bash
make setup        # venv + backend lock + DuckDB SQLite extension + npm ci
make gen-data     # regenerate demo fixtures
make dev          # backend :8000 (reload) + frontend :3000
make demo         # start/reuse servers and run the full offline demo
make demo-stop    # stop only launcher-owned servers
make test         # pytest (offline) + frontend stream-parser tests
make lint         # ruff + ESLint
make build        # production Next.js build
make e2e          # Playwright flow on ports 3100/8100
make screenshots  # E2E with screenshots to docs/screenshots/
make seed-replay  # regenerate scripted replay fixtures
```

Default tests use fake or replay transports and make zero OpenAI calls. The paid live test requires both `OPENAI_API_KEY` and `INSIGHTFORGE_LIVE_TEST=1`.

## Verification status (22 November 2026)

Validated in a Linux container (Python 3.11, Node 20):

- Backend: **110 passed**, 1 live test skipped. 3 SQLite-ingestion tests fail only where a proxy blocks DuckDB's extension download; they pass with a matching DuckDB/extension pair.
- Frontend: TypeScript, ESLint, 4 stream-parser tests, and the production build (including standalone output) pass.
- Playwright: the full offline flow passes against the production build (load → health → journey/mode/breadcrumb checks → ask via the demo-question shortcut → deep link → PNG export → challenge → challenge-test labels → pin → brief → structured edit → PDF/Markdown → audit paging). Screenshots in `docs/screenshots/` were recaptured from this run.
- Manual validation of every feature in offline mode: browser checks for home, Data Health, uploads, SQL workspace, and issue links; 80/82 API-level checks for Ask, cancellation, Challenge, pins, briefs, exports, audit, error handling, guard negatives, and admission control (the two misses were incorrect test expectations).
- PDF pages were inspected visually; the decision page fits one A4 page, including maximum-length content.

See [REMAINING.md](REMAINING.md) for what is not yet verified.

## Limitations

- **Live OpenAI operation has not been validated** with a real key. Replay fixtures are scripted.
- Replay supports only the exact scripted demo flow.
- Findings show association, not causation. Numeric verification checks cited cells and formatting, not metric design or business interpretation.
- Confidence and health scores are heuristics.
- Single-process, local software with no authentication. Development and Compose ports bind to loopback.
- The SQLite extension must be installed during setup (needs access to `extensions.duckdb.org`).
- **Dependency advisories:** Next.js is pinned at 14.2.35 because Next.js 14 is a requirement; `npm audit` reports known advisories, including a critical Next.js finding. Upgrade and revalidate before any public deployment. See `dependency-audit.json`.
