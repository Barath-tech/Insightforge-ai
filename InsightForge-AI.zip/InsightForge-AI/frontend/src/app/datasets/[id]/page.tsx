"use client";
import { HealthNarrative } from "@/components/narrative";
import { Journey } from "@/components/journey";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import {
  ArrowRight,
  CheckCircle2,
  Database,
  FileCheck2,
  Terminal,
} from "lucide-react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { api, Column } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { DataTable, ErrorBox, Loading } from "@/components/shared";
function ColumnCard({ column: c }: { column: Column }) {
  return (
    <div className="panel p-5">
      <div className="flex justify-between gap-2">
        <h3 className="font-semibold truncate" title={c.name}>
          {c.name}
        </h3>
        <span className="text-[10px] uppercase text-primary bg-emerald-50 dark:bg-emerald-950 px-2 py-1 rounded">
          {c.semantic_type}
        </span>
      </div>
      <p className="subtle mt-2">
        {c.distinct_count.toLocaleString()} distinct · {c.null_pct}% missing
      </p>
      {c.distribution?.length ? (
        <div className="h-[100px] mt-5">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={c.distribution}>
              <XAxis
                dataKey="name"
                tick={false}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  background: "var(--background)",
                  color: "#227b66",
                  borderRadius: 8,
                }}
              />
              <Bar dataKey="count" fill="#5c9f86" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="h-[100px] mt-5 text-xs text-muted-foreground flex items-center">
          {c.date_range?.map((v) => v?.slice(0, 10)).join(" → ") ||
            "No distribution available"}
        </div>
      )}
      {c.stats && (
        <div className="flex justify-between border-t pt-3 text-xs text-muted-foreground">
          {["min", "mean", "max"].map((k) => (
            <span key={k}>
              {k}
              <strong className="block mt-1 text-foreground font-medium">
                {c.stats?.[k]?.toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                }) ?? "—"}
              </strong>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
export default function Health({ params }: { params: { id: string } }) {
  const id = params.id;
  const [selected, setSelected] = useState(""),
    [tab, setTab] = useState("Quality issues"),
    [offset, setOffset] = useState(0),
    [raw, setRaw] = useState(false);
  const dataset = useQuery({
      queryKey: ["dataset", id],
      queryFn: () => api.dataset(id),
    }),
    profile = useQuery({
      queryKey: ["profile", id],
      queryFn: () => api.profile(id),
    });
  const table = selected || Object.keys(profile.data?.tables || {})[0] || "";
  const p = profile.data?.tables[table];
  const previewTable = raw ? `raw_${table}` : table;
  const preview = useQuery({
    queryKey: ["preview", id, previewTable, offset],
    queryFn: () => api.preview(id, previewTable, offset),
    enabled: !!table,
  });
  if (dataset.error || profile.error)
    return (
      <ErrorBox
        error={dataset.error || profile.error}
        retry={() => {
          dataset.refetch();
          profile.refetch();
        }}
      />
    );
  if (!dataset.data || !p) return <Loading />;
  return (
    <>
      <Journey datasetId={id} current="health" />
      <div className="flex flex-wrap justify-between gap-4 items-end">
        <div>
          <div className="eyebrow mb-3">Dataset / Data health</div>
          <h1 className="page-title">{dataset.data.name}</h1>
          <p className="subtle mt-3">
            A transparent look at what’s in your data, and what needs attention.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline">
            <Link href={`/datasets/${id}/sql`}>
              <Terminal size={16} />
              Open SQL workspace
            </Link>
          </Button>
          <Button asChild>
            <Link href={`/datasets/${id}/ask`}>
              Next: Ask a question
              <ArrowRight size={16} />
            </Link>
          </Button>
        </div>
      </div>
      <HealthNarrative id={id} />
      <div className="flex items-center gap-3 mt-6">
        <Database size={16} className="text-primary" />
        <label htmlFor="table" className="text-sm">
          Table
        </label>
        <select
          id="table"
          className="field"
          value={table}
          onChange={(e) => {
            setSelected(e.target.value);
            setOffset(0);
          }}
        >
          {Object.keys(profile.data!.tables).map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
        <span className="text-xs border rounded-full px-3 py-1">
          Original preserved
        </span>
      </div>
      <div className="grid md:grid-cols-[240px_1fr] gap-5 mt-6">
        <section className="panel p-6 flex items-center gap-5">
          <div
            className="w-[84px] h-[84px] rounded-full flex items-center justify-center shrink-0"
            style={{
              background: `conic-gradient(#227b66 ${p.health_score}%, #e8eee9 0)`,
            }}
          >
            <div className="w-[68px] h-[68px] bg-white dark:bg-[#17211d] rounded-full flex flex-col items-center justify-center">
              <strong className="text-2xl">{p.health_score}</strong>
              <span className="text-[10px] text-muted-foreground">OF 100</span>
            </div>
          </div>
          <div>
            <h2 className="font-semibold text-sm">Health score</h2>
            <p className="subtle mt-1 text-xs">
              {p.issues.length ? "Needs review" : "Looking good"}
            </p>
          </div>
        </section>
        <section className="panel grid grid-cols-2 lg:grid-cols-4 divide-x">
          {[
            { label: "Total rows", value: p.row_count.toLocaleString() },
            { label: "Columns", value: p.column_count },
            {
              label: "Unique IDs",
              value: p.unique_ids?.toLocaleString() ?? "—",
            },
            {
              label: "Date range",
              value:
                p.date_range?.map((v) => v?.slice(0, 10)).join(" → ") || "—",
            },
          ].map((k) => (
            <div className="p-6" key={k.label}>
              <p className="eyebrow text-[10px]">{k.label}</p>
              <p
                className={`mt-3 font-semibold ${k.label === "Date range" ? "text-sm leading-6" : "text-2xl"}`}
              >
                {k.value}
              </p>
            </div>
          ))}
        </section>
      </div>
      <div
        className="flex overflow-auto gap-6 border-b mt-9 mb-6"
        role="tablist"
        aria-label="Dataset details"
      >
        {[
          "Quality issues",
          "Column profiles",
          "Cleaning log",
          "Schema",
          "Data preview",
        ].map((t) => (
          <button
            role="tab"
            aria-selected={tab === t}
            key={t}
            onClick={() => setTab(t)}
            className={`pb-3 whitespace-nowrap text-sm ${tab === t ? "border-b-2 border-primary text-primary font-semibold" : "text-muted-foreground"}`}
          >
            {t}
            {t === "Quality issues" && (
              <span className="ml-2 text-xs bg-muted px-2 py-1 rounded">
                {p.issues.length}
              </span>
            )}
          </button>
        ))}
      </div>
      {tab === "Quality issues" && (
        <section className="panel">
          <div className="p-6 border-b">
            <h2 className="font-semibold">A few things to look into</h2>
            <p className="subtle mt-1">
              Sorted by severity. Expand any issue to inspect the evidence.
            </p>
          </div>
          {!p.issues.length && (
            <p className="p-8 flex gap-3">
              <CheckCircle2 className="text-primary" />
              No issues found by the current checks.
            </p>
          )}
          {p.issues.map((issue, i) => (
            <details key={i} className="border-b last:border-0 group">
              <summary className="p-5 cursor-pointer flex items-center gap-4">
                <span
                  className={`text-[10px] uppercase font-semibold rounded px-2 py-1 w-16 text-center ${issue.severity === "high" ? "bg-orange-100 text-orange-800" : issue.severity === "medium" ? "bg-amber-50 text-amber-800" : "bg-muted text-muted-foreground"}`}
                >
                  {issue.severity}
                </span>
                <div className="flex-1">
                  <p className="font-medium text-sm">{issue.message}</p>
                  <p className="text-xs text-muted-foreground mt-1 font-mono">
                    {issue.column}
                  </p>
                </div>
                <span className="text-sm font-semibold">
                  {issue.count.toLocaleString()}{" "}
                  <span className="font-normal text-muted-foreground">
                    rows
                  </span>
                </span>
                <span className="text-muted-foreground group-open:rotate-90">
                  ›
                </span>
              </summary>
              <div className="px-6 pb-5 text-sm text-muted-foreground">
                <Link
                  className="text-primary underline block mb-3"
                  href={`/datasets/${id}/ask?question=${encodeURIComponent(`Investigate ${issue.message} in ${table}, column ${issue.column}. How does this affect analysis?`)}`}
                >
                  Ask about this issue
                </Link>
                <p className="mb-2">Sample evidence · {issue.code}</p>
                <code className="whitespace-pre-wrap break-all">
                  {issue.samples.length
                    ? issue.samples.join("  ·  ")
                    : "NULL values detected; no non-null sample available."}
                </code>
              </div>
            </details>
          ))}
        </section>
      )}
      {tab === "Column profiles" && (
        <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-5">
          {p.columns.map((c) => (
            <ColumnCard key={c.name} column={c} />
          ))}
        </div>
      )}
      {tab === "Cleaning log" && (
        <section className="panel">
          <div className="p-6 border-b flex gap-3">
            <FileCheck2 className="text-primary" />
            <div>
              <h2 className="font-semibold">
                Every transformation, accounted for
              </h2>
              <p className="subtle mt-1">
                Duplicates and impossible business values remain in place for
                review.
              </p>
            </div>
          </div>
          <DataTable
            columns={["column", "action", "affected_rows"]}
            rows={p.cleaning_log}
          />
        </section>
      )}
      {tab === "Schema" && (
        <section className="panel">
          <DataTable
            columns={["original_name", "clean_name", "type"]}
            rows={p.schema.map((s) => ({
              original_name: Object.entries(p.column_mapping).find(
                ([, v]) => v === s.name,
              )?.[0],
              clean_name: s.name,
              type: s.type,
            }))}
          />
        </section>
      )}
      {tab === "Data preview" && (
        <section className="panel">
          <div className="p-5 flex justify-between items-center">
            <h2 className="font-semibold">{previewTable}</h2>
            <label className="subtle flex gap-2">
              <input
                type="checkbox"
                checked={raw}
                onChange={(e) => {
                  setRaw(e.target.checked);
                  setOffset(0);
                }}
              />
              View raw data
            </label>
          </div>
          {preview.isLoading ? (
            <Loading />
          ) : preview.error ? (
            <ErrorBox error={preview.error} retry={() => preview.refetch()} />
          ) : (
            preview.data && (
              <DataTable
                columns={preview.data.columns}
                rows={preview.data.rows}
              />
            )
          )}
          <div className="p-4 border-t flex items-center justify-between">
            <span className="subtle">
              Rows {p.row_count ? offset + 1 : 0}–
              {Math.min(offset + 50, p.row_count)} of{" "}
              {p.row_count.toLocaleString()}
            </span>
            <div className="flex gap-2">
              <Button
                variant="outline"
                disabled={!offset || preview.isFetching}
                onClick={() => setOffset(Math.max(0, offset - 50))}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                disabled={offset + 50 >= p.row_count || preview.isFetching}
                onClick={() => setOffset(offset + 50)}
              >
                Next
              </Button>
            </div>
          </div>
        </section>
      )}
      <p className="text-xs text-muted-foreground mt-5">
        Health score uses severity-weighted deductions. Findings describe this
        table, including retained duplicates.
      </p>
    </>
  );
}
