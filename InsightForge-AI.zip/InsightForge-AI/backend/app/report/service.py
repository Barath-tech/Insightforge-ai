import asyncio
import io
import re
from pathlib import Path
from typing import Annotated

import markdown
from jinja2 import Environment, FileSystemLoader, select_autoescape
from pydantic import Field
from sqlmodel import Session, select

from app.agent.contracts import Contract
from app.llm.client import Client
from app.models.analysis import Analysis
from app.models.final import Brief, Challenge, Pin


class EvidenceText(Contract):
    text: str = Field(max_length=500)
    source: str


class Action(Contract):
    owner_role: str = Field(max_length=70)
    priority: str = Field(max_length=30)
    expected_impact: str = Field(max_length=350)
    linked_evidence: str


class BriefContent(Contract):
    situation: str = Field(max_length=600)
    evidence: list[EvidenceText] = Field(max_length=3)
    root_cause: str = Field(max_length=600)
    business_impact: str = Field(max_length=500)
    recommended_actions: list[Action] = Field(max_length=3)
    risks_and_caveats: list[Annotated[str, Field(max_length=350)]] = Field(max_length=3)
    confidence_statement: str = Field(max_length=350)


TOKEN = re.compile(r"\{\{e:([\w.]+)\}\}")
FIT_SCALES = (1.0, 0.92, 0.85, 0.78, 0.72, 0.66)
WORDS = re.compile(
    r"\b(zero|one|two|three|four|five|six|seven|eight|nine|ten|hundred|thousand|million|billion|percent)\b",
    re.I,
)


def allowed_numbers(value, prefix="", output=None):
    output = {} if output is None else output
    if isinstance(value, dict):
        for key, item in value.items():
            allowed_numbers(item, f"{prefix}.{key}" if prefix else key, output)
    elif isinstance(value, list):
        for i, item in enumerate(value):
            allowed_numbers(item, f"{prefix}.{i}", output)
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        output[prefix] = value
    return output


def ground_content(content, allowed, sources):
    errors = []

    def visit(value, key=""):
        if isinstance(value, dict):
            return {k: visit(v, k) for k, v in value.items()}
        if isinstance(value, list):
            return [visit(v, key) for v in value]
        if not isinstance(value, str):
            return value
        if key in {"source", "linked_evidence"}:
            if value not in sources:
                errors.append("Unknown evidence reference: " + value)
                return "[UNVERIFIED SOURCE]"
            return value

        def replacement(match):
            path = match[1]
            if path not in allowed:
                errors.append("Unknown numeric evidence: " + path)
                return "[UNVERIFIED NUMBER]"
            number = allowed[path]
            return f"{number:,.2f}".rstrip("0").rstrip(".")

        stripped = TOKEN.sub("", value)
        if re.search(r"\d", stripped) or WORDS.search(stripped):
            errors.append("Unsupported numeric prose: " + key)
            # Do not publish hallucinated digits, even if their value occurs elsewhere.
            chunks = TOKEN.split(value)
            for i in range(0, len(chunks), 2):
                chunks[i] = re.sub(r"\d+(?:[,.]\d+)*", "[UNVERIFIED NUMBER]", chunks[i])
                chunks[i] = WORDS.sub("[UNVERIFIED NUMBER]", chunks[i])
            value = "".join(v if i % 2 == 0 else "{{e:" + v + "}}" for i, v in enumerate(chunks))
        return TOKEN.sub(replacement, value)

    rendered = visit(content)
    return rendered, {"status": "verified" if not errors else "unverified", "errors": errors}


def collect(session, dataset, analysis_ids):
    pins = session.exec(select(Pin).where(Pin.dataset_id == dataset.id, Pin.pinned)).all()
    selected = (
        analysis_ids
        if analysis_ids is not None
        else [p.item_id for p in pins if p.kind == "analyses"]
    )
    if not selected:
        raise ValueError("Pin a finding before generating a brief.")
    if len(selected) > 5:
        raise ValueError("Select at most five findings for a one-page brief.")
    findings, sql = [], []
    for identifier in selected:
        a = session.get(Analysis, identifier)
        if not a or a.dataset_id != dataset.id or a.status != "completed" or not a.finding_json:
            raise ValueError("Select completed findings from this dataset.")
        challenges = session.exec(
            select(Challenge).where(
                Challenge.analysis_id == identifier, Challenge.status == "completed"
            )
        ).all()
        included = [c.result_json for c in challenges if any(p.item_id == c.id for p in pins)]
        finding = a.finding_json
        impact = (finding.get("evidence", {}).get("decomposition") or {}).get("margin_lost")
        findings.append({"finding": finding, "challenges": included, "business_impact": impact})
        sql.extend(finding.get("evidence", {}).get("supporting_steps", []))
        for c in included:
            for h in c.get("hypotheses", []):
                sql.extend(
                    {
                        "step_id": f"{h['id']} · {s['step_id']} · attempt {s['attempt_no']}"
                        f" · {s['status']}",
                        "sql": s["generated_sql"],
                    }
                    for s in h["steps"]
                )
            sql.extend(
                {"step_id": q["name"], "sql": q["sql"]}
                for q in c.get("quality_checks", [])
                if q.get("sql")
            )
    return selected, {"findings": findings, "sql": sql}


async def create_brief(engine, dataset, body, transport):
    with Session(engine) as session:
        selected, bundle = collect(session, dataset, body.analysis_ids)
    compact = []
    for entry in bundle["findings"]:
        finding = entry["finding"]
        compact.append(
            {
                "finding": {
                    k: finding[k]
                    for k in [
                        "headline",
                        "answer",
                        "key_numbers",
                        "confidence",
                        "drivers",
                        "driver_summary",
                        "caveats",
                    ]
                    if k in finding
                },
                "business_impact": entry["business_impact"],
                "quality_caveats": finding.get("evidence", {}).get("quality_issues", []),
                "challenges": [
                    {
                        k: c.get(k)
                        for k in [
                            "original_confidence",
                            "revised_confidence",
                            "verdict_summary",
                            "surviving_explanation",
                        ]
                    }
                    for c in entry["challenges"]
                ],
            }
        )
    numbers = allowed_numbers(compact, "findings")
    numbers["scale_max"] = 100
    sources = [f"finding:{i}" for i in range(len(selected))]
    for i, finding in enumerate(bundle["findings"]):
        sources.extend(
            f"finding:{i}/step:{s['step_id']}"
            for s in finding["finding"].get("evidence", {}).get("supporting_steps", [])
        )
    context = {
        "selected_evidence": compact,
        "allowed_evidence": numbers,
        "allowed_sources": sources,
        "audience": body.audience,
    }
    client = Client(engine, dataset.id, transport, selected[0])
    for attempt in range(2):
        generated = await client.generate("brief", context, BriefContent)
        rendered, grounding = ground_content(generated.model_dump(), numbers, sources)
        if grounding["status"] == "verified":
            break
        context["grounding_failures"] = grounding["errors"]
    value = Brief(
        dataset_id=dataset.id,
        title=body.title or "Executive decision brief",
        audience=body.audience,
        content_json=rendered,
        evidence_json={
            **bundle,
            "numbers": numbers,
            "sources": sources,
            "dataset_name": dataset.name,
            # Token-form sections let edits re-ground the whole brief deterministically.
            "templates": generated.model_dump(),
        },
        grounding_json=grounding,
        analysis_ids=selected,
    )
    from app.agent.store import save

    return await asyncio.to_thread(save, engine, value)


def edit_content(brief, changes):
    """Apply section edits; return (content, grounding) re-checked against stored evidence."""
    content = BriefContent.model_validate({**brief.content_json, **changes}).model_dump()
    edits = {k: v for k, v in content.items() if k in changes}
    numbers, sources = brief.evidence_json["numbers"], brief.evidence_json["sources"]
    templates = brief.evidence_json.get("templates")
    if templates is None:
        # Older briefs lack templates: re-check only edited sections and keep prior errors.
        rendered, status = ground_content(edits, numbers, sources)
        errors = list(dict.fromkeys(brief.grounding_json.get("errors", []) + status["errors"]))
        content = {**brief.content_json, **rendered}
        return content, None, {"status": "unverified" if errors else "verified", "errors": errors}
    templates = {**templates, **edits}
    content, grounding = ground_content(templates, numbers, sources)
    return content, templates, grounding


def render_markdown(brief):
    env = Environment(
        loader=FileSystemLoader(Path(__file__).with_name("templates")), autoescape=False
    )
    return env.get_template("brief.md.j2").render(brief=brief, c=brief.content_json)


def chart_png(chart):
    import matplotlib

    matplotlib.use("Agg")
    from matplotlib.figure import Figure

    fig = Figure(figsize=(6.5, 1.8), dpi=150)
    ax = fig.subplots()
    rows = chart["rows"]
    if not rows or not chart["y"]:
        return None
    x = list(range(len(rows)))
    labels = [str(r.get(chart["x"], i))[:10] for i, r in enumerate(rows)]
    secondary = set(chart.get("secondary_y") or [])
    twin = ax.twinx() if secondary and chart["type"] != "scatter" else None
    for i, col in enumerate(chart["y"][:4]):
        target = twin if col in secondary else ax
        values = [r.get(col) or 0 for r in rows]
        if chart["type"] == "line":
            target.plot(x, values, color=["#227b66", "#568db6", "#b99044", "#9979b7"][i], label=col)
        elif chart["type"] == "scatter":
            ax.scatter([r.get(chart["x"]) for r in rows], values, label=col, color="#227b66")
        else:
            target.bar(
                [v + i * 0.18 for v in x],
                values,
                width=0.18 if len(chart["y"]) > 1 else 0.7,
                label=col,
                color=["#227b66", "#568db6", "#b99044", "#9979b7"][i],
            )
    for h in chart["highlights"]:
        index = h["row_index"]
        if h["column"] in chart["y"] and index < len(rows):
            target = twin if h["column"] in secondary else ax
            target.scatter([index], [rows[index][h["column"]]], color="#e07945", zorder=4)
    if chart["type"] != "scatter":
        ax.set_xticks(x[:: max(1, len(x) // 10)], labels[:: max(1, len(x) // 10)], fontsize=6)
    ax.tick_params(axis="y", labelsize=6)
    handles, names = ax.get_legend_handles_labels()
    if twin:
        twin.tick_params(axis="y", labelsize=6)
        extra, extra_names = twin.get_legend_handles_labels()
        handles, names = handles + extra, names + [n + " (right axis)" for n in extra_names]
        twin.spines[["top"]].set_visible(False)
    ax.legend(handles, names, fontsize=6, loc="best")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    out = io.BytesIO()
    fig.savefig(out, format="png")
    return out.getvalue()


def render_pdf(brief):
    import base64

    # No user/model HTML or remote URL can load resources in the renderer.
    import html

    from weasyprint import HTML

    text = render_markdown(brief)
    main = text.partition("<!-- APPENDIX -->")[0]

    def safe(md):
        return markdown.markdown(html.escape(md), extensions=["tables", "fenced_code"])

    # SQL is rendered directly: escaping before Markdown's own code escaping doubled entities.
    appendix = "<h2>SQL Appendix</h2>" + "".join(
        f"<h3>{html.escape(str(step['step_id']))}</h3><pre>{html.escape(step['sql'])}</pre>"
        for step in brief.evidence_json.get("sql", [])
    )

    chart = next(
        (
            f["finding"].get("primary_chart")
            for f in brief.evidence_json["findings"]
            if f["finding"].get("primary_chart")
        ),
        None,
    )
    png = chart_png(chart) if chart else None
    image = (
        '<img src="data:image/png;base64,' + base64.b64encode(png).decode() + '">' if png else ""
    )
    env = Environment(
        loader=FileSystemLoader(Path(__file__).with_name("templates")),
        autoescape=select_autoescape(),
    )
    from markupsafe import Markup
    from weasyprint.urls import URLFetcher

    fetcher = URLFetcher(allowed_protocols={"data"})

    def source(scale, with_appendix):
        return env.get_template("brief.html.j2").render(
            main=Markup(safe(main)),
            appendix=Markup(appendix) if with_appendix else "",
            chart=Markup(image),
            scale=scale,
        )

    # The decision page must stay on one A4 page; step the type scale down until it fits.
    chosen = FIT_SCALES[-1]
    for scale in FIT_SCALES:
        if len(HTML(string=source(scale, False), url_fetcher=fetcher).render().pages) == 1:
            chosen = scale
            break
    return HTML(string=source(chosen, True), url_fetcher=fetcher).write_pdf()
