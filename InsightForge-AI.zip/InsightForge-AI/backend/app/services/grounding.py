"""Fail-closed numeric grounding with explicit cell provenance and formatting.

Free prose may contain no numeric literals: use {{n0}} tokens. Values are
resolved from a particular successful attempt/row/column, and labels must equal
that SQL column. Numeric tolerance is half a unit at the requested decimal place
(Decimal ROUND_HALF_UP), never a fuzzy percentage. Dates/IDs are exact strings.
"""

import re
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

TOKEN = re.compile(r"\{\{n(\d+)\}\}")
NUMBER = re.compile(r"(?<!\w)[−+-]?[£$€]?\s*\d[\d,]*(?:\.\d+)?%?")


def normalize(value, category="number"):
    text = str(value).strip()
    if category in {"date", "identifier", "text"}:
        return text
    text = text.replace(",", "").replace("−", "-").replace(" ", "")
    for symbol in "£$€%":
        text = text.replace(symbol, "")
    return Decimal(text)


def format_number(value, unit, conversion, decimals):
    if unit in {"date", "identifier", "text"}:
        if conversion != "identity":
            raise ValueError("Non-numeric conversion")
        return str(value)
    number = normalize(value)
    if not number.is_finite():
        raise ValueError("Non-finite evidence")
    if conversion == "fraction_to_percent":
        if unit != "percent":
            raise ValueError("Fraction conversion requires percent unit")
        number *= 100
    rounded = number.quantize(Decimal(10) ** -decimals, rounding=ROUND_HALF_UP)
    prefix = {"GBP": "£", "USD": "$", "EUR": "€"}.get(unit, "")
    return f"{prefix}{rounded:,.{decimals}f}" + ("%" if unit == "percent" else "")


def check_finding(finding, evidence):
    errors, rendered = [], []
    for i, key in enumerate(finding.key_numbers):
        try:
            result = evidence[(key.source_step_id, key.source_attempt)]
            if key.column not in result["columns"] or key.label != key.column:
                raise ValueError("Label must equal the cited metric column")
            if key.column == "id" or key.column.endswith("_id"):
                if key.unit != "identifier":
                    raise ValueError("Identifier evidence requires identifier category")
            types = result.get("column_types", [])
            dtype = types[result["columns"].index(key.column)] if types else ""
            if ("DATE" in dtype or "TIMESTAMP" in dtype) and key.unit != "date":
                raise ValueError("Date evidence requires date category")
            value = result["rows"][key.row_index][key.column]
            if value is None:
                raise ValueError("Null evidence")
            expected = format_number(value, key.unit, key.conversion, key.decimals)
            if normalize(expected, key.unit) != normalize(key.value, key.unit):
                raise ValueError("Value does not match cited cell and rounding")
            rendered.append(f"{key.label}: {expected}")
        except (KeyError, IndexError, ValueError, InvalidOperation, TypeError) as exc:
            errors.append(f"n{i}: {exc}")
            rendered.append("[unsupported evidence]")

    def check(text):
        stripped = TOKEN.sub("", text)
        if re.search(r"\d", stripped):
            errors.append("Numeric text must use evidence placeholders")
        # Number words cannot be used to evade literal checking.
        if re.search(
            r"\b(zero|one|two|three|four|five|six|seven|eight|nine|ten|hundred|"
            r"eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|thousand|million|billion|percent)\b",
            stripped,
            re.I,
        ):
            errors.append("Use evidence placeholders for quantities")

        def replace(match):
            index = int(match[1])
            if index >= len(rendered):
                errors.append("Unknown evidence placeholder")
                return "[unsupported evidence]"
            return rendered[index]

        return TOKEN.sub(replace, text)

    output = finding.model_dump()
    output["headline"] = check(finding.headline)
    output["answer"] = check(finding.answer)
    output["caveats"] = [check(c) for c in finding.caveats]
    # Numeric evidence is tied to its metric at rendering, not matched to a bag of numbers.
    output["grounding_status"] = "unverified" if errors else "verified"
    output["grounding_errors"] = errors
    return output


def check_narrative(narrative, facts):
    lookup = {f.id: f for f in facts}
    errors = []
    # The introduction is deliberately fixed to avoid unsupported business claims.
    if narrative.introduction != "Profile summary by table.":
        errors.append("Use the fixed profile introduction")
    lines, refs = [], []
    for claim in narrative.claims:
        fact = lookup.get(claim.fact_id)
        if not fact or claim.label != fact.label:
            errors.append(f"Unknown or misattributed fact: {claim.fact_id}")
            continue
        try:
            if normalize(claim.value, fact.category) != normalize(fact.value, fact.category):
                raise ValueError()
        except (InvalidOperation, ValueError):
            errors.append(f"Incorrect value: {claim.fact_id}")
            continue
        lines.append(f"{fact.table} — {fact.label}: {fact.value}.")
        refs.append(fact.id)
    if not lines:
        errors.append("No supported claims")
    return {
        "narrative": "Profile summary by table. " + " ".join(lines),
        "fact_refs": refs,
        "errors": errors,
        "status": "verified",
    }


def fallback_narrative(facts, reason):
    selected = [
        f
        for f in facts
        if f.id.endswith((":rows", ":unique_ids"))
        or ":issue:duplicate_ids:" in f.id
        or ":issue:missing_delivery_timestamp:" in f.id
    ]
    if not selected:
        selected = facts[:8]
    return {
        "narrative": " ".join(f"{f.table} — {f.label}: {f.value}." for f in selected),
        "fact_refs": [f.id for f in selected],
        "status": "fallback",
        "errors": [reason],
    }
