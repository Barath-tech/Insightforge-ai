"""Reproducible fixtures. Ground truth is never consumed by application code."""

import argparse
import json
import random
import sqlite3
from contextlib import closing
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

CITIES = [
    "London",
    "Manchester",
    "Birmingham",
    "Leeds",
    "Glasgow",
    "Liverpool",
    "Bristol",
    "Edinburgh",
    "Sheffield",
    "Cardiff",
    "Newcastle",
    "Nottingham",
]


def generate(seed=42):
    rng = random.Random(seed)
    rows = []
    for i in range(4850):
        city = CITIES[i % 12]
        month = (i // 12) % 12 + 1
        date = datetime(2024, month, rng.randint(1, 28), 12)
        channel = ["online", "in-store", "click-collect"][(i // 144) % 3]
        slot = ("peak" if (i // 432) % 2 == 0 else "off-peak") if channel == "online" else "none"
        quantity = rng.randint(1, 4)
        price = rng.choice([25.0, 40.0, 60.0, 85.0])
        discount = rng.choice([0, 5, 10])
        revenue = round(quantity * price * (1 - discount / 100), 2)
        # Stable unit economics make the delivery and refund effects independently measurable.
        cost = 12.0 if slot == "peak" else 5.0 if slot == "off-peak" else 0.0
        if city == "London" and month == 10 and slot == "peak":
            cost = round(cost * 1.187, 3)
        probability = 0.24 if city in ["Leeds", "Cardiff"] else 0.025
        refund = rng.random() < probability
        rows.append(
            dict(
                order_id=f"ORD-{i + 1:05}",
                order_date=date.isoformat(),
                city=city,
                store_id=f"{city[:3].upper()}-{i % 3 + 1}",
                channel=channel,
                category="Home" if i % 2 else "Electronics",
                product="Desk lamp" if i % 2 else "Wireless speaker",
                quantity=quantity,
                unit_price=price,
                discount_pct=discount,
                revenue=revenue,
                cogs=round(revenue * 0.65, 2),
                delivery_slot=slot,
                delivery_cost=cost,
                delivery_timestamp=(date + timedelta(days=2)).isoformat()
                if slot != "none"
                else None,
                refund_flag=refund,
                refund_amount=round(revenue * 0.3, 2) if refund else 0.0,
                customer_id=f"C-{rng.randint(1, 1700):04}",
                payment_method=rng.choice(["card", "paypal", "bank transfer"]),
            )
        )
    clean = pd.DataFrame(rows)
    # Hold London basket economics constant so margin attribution is unambiguous.
    london_mask = clean.city == "London"
    clean.loc[london_mask, ["quantity", "unit_price", "discount_pct", "revenue", "cogs"]] = [
        2,
        50.0,
        0,
        100.0,
        65.0,
    ]
    clean.loc[london_mask & clean.refund_flag, "refund_amount"] = 3.0
    # A modest London refund-rate rise with small refund amounts, secondary to delivery.
    london_oct = clean.index[(clean.city == "London") & clean.order_date.str.startswith("2024-10")]
    clean.loc[london_oct, ["refund_flag", "refund_amount"]] = [False, 0.0]
    clean.loc[london_oct[:2], ["refund_flag", "refund_amount"]] = [True, 3.0]
    messy = clean.copy()
    for i in messy.index:
        dt = datetime.fromisoformat(messy.at[i, "order_date"])
        messy.at[i, "order_date"] = dt.strftime(["%Y-%m-%d", "%d/%m/%Y", "%d %b %Y"][i % 3])
        if i % 5 == 0:
            messy.at[i, "city"] = " " + messy.at[i, "city"].upper() + " "
        elif i % 7 == 0:
            messy.at[i, "city"] = messy.at[i, "city"].lower()
    messy["revenue"] = messy.revenue.astype(object)
    for i in range(19, 4800, 37):
        messy.at[i, "revenue"] = f"£{messy.at[i, 'revenue']:,.2f}"
    for i in [101, 503, 1001, 2003, 4001]:
        messy.at[i, "order_date"] = "not-a-date"
    for i in [121, 721, 1441]:
        messy.at[i, "quantity"] = -2
    for i in [122, 722, 1442]:
        messy.at[i, "discount_pct"] = 125
    delivered = messy.index[messy.delivery_slot != "none"]
    messy.loc[delivered[100:147], "delivery_timestamp"] = None
    # Duplicate only complete rows, so the missing-timestamp count remains exactly 47.
    messy = pd.concat([messy, messy.iloc[2100:2123]], ignore_index=True)
    truth = {
        "seed": seed,
        "rows": len(messy),
        "unique_orders": 4850,
        "duplicate_order_id_rows": 23,
        "missing_delivered_timestamps": 47,
        "invalid_dates": 5,
        "negative_quantities": 3,
        "impossible_discounts": 3,
        "london_peak_october_uplift_pct": 18.7,
        "high_refund_cities": ["Leeds", "Cardiff"],
        "gross_margin": "revenue - cogs - delivery_cost - refund_amount",
    }
    return messy, clean, truth


def write(output: Path):
    output.mkdir(parents=True, exist_ok=True)
    samples = output / "samples"
    samples.mkdir(exist_ok=True)
    messy, clean, truth = generate()
    messy.to_csv(output / "UK Retail Operations.csv", index=False)
    messy.to_csv(samples / "UK Retail Operations.csv", index=False)
    clean.to_csv(samples / "uk_retail_clean.csv", index=False)
    # Build a fresh file, then replace: rewriting in place leaves byte-level churn.
    target = samples / "uk_retail.sqlite"
    staging = target.with_suffix(".sqlite.tmp")
    staging.unlink(missing_ok=True)
    with closing(sqlite3.connect(staging)) as conn:
        messy.to_sql("uk_retail_operations", conn, index=False)
        conn.commit()
    staging.replace(target)
    (samples / "ground_truth.json").write_text(json.dumps(truth, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "data")
    write(parser.parse_args().output)
