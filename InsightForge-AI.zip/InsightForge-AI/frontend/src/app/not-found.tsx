import Link from "next/link";
export default function NotFound() {
  return (
    <div className="panel p-10 max-w-2xl">
      <p className="eyebrow mb-3">404</p>
      <h1 className="text-2xl font-semibold">We couldn’t find that page</h1>
      <p className="subtle mt-3">
        The link may be out of date, or the dataset, analysis, or brief may
        belong to a different InsightForge data folder.
      </p>
      <div className="flex flex-wrap gap-4 mt-6 text-sm">
        <Link className="text-primary underline" href="/">
          Go to your data library
        </Link>
        <Link className="text-primary underline" href="/audit">
          Open AI Transparency
        </Link>
      </div>
    </div>
  );
}