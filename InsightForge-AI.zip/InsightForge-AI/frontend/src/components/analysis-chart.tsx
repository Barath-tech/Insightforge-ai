"use client";
import { useRef, useState } from "react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { Chart } from "@/lib/api";
import { DataTable } from "./shared";
import { Button } from "./ui/button";
const palette = ["#227b66", "#568db6", "#b99044", "#9979b7"];
const highlightColor = "#e07945";
const midnight = /^(\d{4}-\d{2}-\d{2})[T ]00:00:00(\.0+)?(Z|[+-]00:?00)?$/;
export function tickLabel(value: unknown) {
  const text = String(value ?? "");
  return midnight.exec(text)?.[1] ?? text;
}
function seriesName(chart: Chart, y: string) {
  return chart.secondary_y.includes(y) ? `${y} (right axis)` : y;
}
export function AnalysisChart({ chart }: { chart: Chart }) {
  const [kind, setKind] = useState(chart.type),
    [error, setError] = useState("");
  const ref = useRef<HTMLDivElement>(null);
  const highlights = new Set(chart.highlights.map((h) => h.row_index));
  const flagged = new Set(
    chart.highlights.map((h) => `${h.row_index}|${h.column}`),
  );
  const isFlagged = (index: number, y: string) => flagged.has(`${index}|${y}`);
  const secondary = new Set(chart.secondary_y);
  const hasSecondary = chart.secondary_y.length > 0 && kind !== "scatter";
  const horizontal = chart.horizontal && kind !== "line";
  const primaryLabel = chart.y.filter((y) => !secondary.has(y)).join(", ");
  const secondaryLabel = chart.secondary_y.join(", ");
  const describe = `${kind} chart of ${chart.y.join(", ")}${chart.x ? ` by ${chart.x}` : ""}; ${chart.rows.length} rows${chart.highlights.length ? `; ${chart.highlights.length} outlier callouts listed below` : ""}. Choose “table” to read every value.`;
  async function png() {
    setError("");
    try {
      const width = 1400,
        footer = Math.min(chart.highlights.length, 6) * 30;
      const height = 700 + footer;
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Canvas unavailable");
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, width, height);
      ctx.fillStyle = "#183d32";
      ctx.font = "26px Arial";
      ctx.fillText(chart.title, 30, 40);
      const svg = ref.current?.querySelector<SVGSVGElement>(
        "svg.recharts-surface",
      );
      if (svg) {
        const box = svg.getBoundingClientRect();
        const clone = svg.cloneNode(true) as SVGSVGElement;
        clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
        clone.setAttribute("width", String(box.width));
        clone.setAttribute("height", String(box.height));
        clone.setAttribute("style", "font-family: Arial, sans-serif");
        const xml = new XMLSerializer().serializeToString(clone);
        const url = URL.createObjectURL(
          new Blob([xml], { type: "image/svg+xml;charset=utf-8" }),
        );
        const image = new Image();
        try {
          await new Promise<void>((resolve, reject) => {
            image.onload = () => resolve();
            image.onerror = () => reject(new Error("SVG could not be drawn"));
            image.src = url;
          });
          const area = { x: 30, y: 110, w: width - 60, h: 560 };
          const scale = Math.min(area.w / box.width, area.h / box.height);
          ctx.drawImage(
            image,
            area.x + (area.w - box.width * scale) / 2,
            area.y,
            box.width * scale,
            box.height * scale,
          );
        } finally {
          URL.revokeObjectURL(url);
        }
        ctx.font = "18px Arial";
        let x = 30;
        chart.y.forEach((y, i) => {
          ctx.fillStyle = palette[i % 4];
          ctx.fillRect(x, 70, 16, 16);
          ctx.fillStyle = "#183d32";
          const name = seriesName(chart, y);
          ctx.fillText(name, x + 24, 85);
          x += ctx.measureText(name).width + 60;
        });
      } else {
        ctx.fillStyle = "#183d32";
        ctx.font = "22px Arial";
        chart.rows.slice(0, 12).forEach((r, i) =>
          ctx.fillText(
            Object.entries(r)
              .map(([k, v]) => `${k}: ${tickLabel(v)}`)
              .join(" · ")
              .slice(0, 110),
            30,
            90 + i * 42,
          ),
        );
      }
      ctx.fillStyle = "#9a4a22";
      ctx.font = "18px Arial";
      chart.highlights
        .slice(0, 6)
        .forEach((h, i) =>
          ctx.fillText(`● ${h.callout}`.slice(0, 140), 30, 700 + i * 30),
        );
      const a = document.createElement("a");
      a.download = "insightforge-chart.png";
      a.href = canvas.toDataURL("image/png");
      a.click();
    } catch {
      setError("Chart export failed. Choose “table” or retry.");
    }
  }
  const valueAxis = (id: "primary" | "secondary") => {
    const props = {
      tick: { fontSize: 10 },
      tickFormatter: (v: number) => Number(v).toLocaleString(),
    };
    const label = {
      value: id === "primary" ? primaryLabel : secondaryLabel,
      fontSize: 10,
      fill: "#5b7066",
    };
    return horizontal ? (
      <XAxis
        key={id}
        xAxisId={id}
        type="number"
        orientation={id === "primary" ? "bottom" : "top"}
        label={{ ...label, position: id === "primary" ? "bottom" : "top" }}
        height={id === "primary" ? 45 : 40}
        {...props}
      />
    ) : (
      <YAxis
        key={id}
        yAxisId={id}
        type="number"
        orientation={id === "primary" ? "left" : "right"}
        label={{
          ...label,
          angle: -90,
          position: id === "primary" ? "insideLeft" : "insideRight",
          style: { textAnchor: "middle" },
        }}
        width={80}
        {...props}
      />
    );
  };
  // Bar categories are few and every label matters; date axes may thin their ticks.
  const categoryAxis = horizontal ? (
    <YAxis
      type="category"
      dataKey={chart.x || undefined}
      tick={{ fontSize: 10 }}
      tickFormatter={tickLabel}
      width={150}
    />
  ) : (
    <XAxis
      type="category"
      dataKey={chart.x || undefined}
      tick={{ fontSize: 10 }}
      tickFormatter={tickLabel}
      interval={kind === "line" ? "preserveEnd" : 0}
      angle={kind !== "line" && chart.rows.length > 6 ? -30 : 0}
      textAnchor={kind !== "line" && chart.rows.length > 6 ? "end" : "middle"}
      label={{
        value: chart.x_label,
        position: "bottom",
        fontSize: 10,
        fill: "#5b7066",
      }}
      height={kind !== "line" && chart.rows.length > 6 ? 70 : 45}
    />
  );
  const axes = [
    <CartesianGrid key="grid" strokeDasharray="3 3" stroke="#cad7cf" />,
    categoryAxis,
    valueAxis("primary"),
    ...(hasSecondary ? [valueAxis("secondary")] : []),
    <Tooltip key="tooltip" labelFormatter={tickLabel} />,
    <Legend key="legend" verticalAlign="top" />,
  ];
  const axisFor = (y: string) =>
    hasSecondary && secondary.has(y) ? "secondary" : "primary";
  return (
    <section className="border rounded-xl p-4 my-4 bg-white text-slate-800">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-semibold">{chart.title}</h3>
        <div className="flex gap-2">
          <select
            aria-label="Chart type"
            className="border rounded p-2 text-sm bg-white"
            value={kind}
            onChange={(e) => setKind(e.target.value)}
          >
            {chart.compatible_types.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
          <Button variant="outline" onClick={png}>
            Export PNG
          </Button>
        </div>
      </div>
      <p className="text-xs text-slate-500 my-2">{chart.reason}</p>
      <div ref={ref} role="figure" aria-label={describe}>
        {kind === "table" ? (
          <DataTable
            columns={Object.keys(chart.rows[0] || {})}
            rows={chart.rows}
          />
        ) : kind === "kpi" ? (
          <div className="flex flex-wrap gap-6 p-6">
            {chart.y.map((y) => (
              <div key={y}>
                <p>{y}</p>
                <strong className="text-3xl">
                  {typeof chart.rows[0]?.[y] === "number"
                    ? (chart.rows[0][y] as number).toLocaleString()
                    : String(chart.rows[0]?.[y] ?? "—")}
                </strong>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              {kind === "line" ? (
                <LineChart
                  data={chart.rows}
                  accessibilityLayer
                  margin={{ top: 5, right: 20, bottom: 15, left: 10 }}
                >
                  {axes}
                  {chart.y.map((y, i) => (
                    <Line
                      key={y}
                      dataKey={y}
                      name={seriesName(chart, y)}
                      yAxisId={axisFor(y)}
                      stroke={palette[i % 4]}
                      strokeWidth={2}
                      dot={(props) => {
                        const { cx, cy, index } = props;
                        return (
                          <circle
                            key={index}
                            cx={cx}
                            cy={cy}
                            r={isFlagged(index, y) ? 6 : 3}
                            fill={
                              isFlagged(index, y)
                                ? highlightColor
                                : palette[i % 4]
                            }
                          />
                        );
                      }}
                    />
                  ))}
                </LineChart>
              ) : kind === "scatter" ? (
                <ScatterChart
                  accessibilityLayer
                  margin={{ top: 5, right: 20, bottom: 15, left: 10 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#cad7cf" />
                  <XAxis
                    type="number"
                    dataKey={chart.x || undefined}
                    name={chart.x || undefined}
                    tick={{ fontSize: 10 }}
                    tickFormatter={(v: number) => Number(v).toLocaleString()}
                    label={{
                      value: chart.x_label,
                      position: "bottom",
                      fontSize: 10,
                      fill: "#5b7066",
                    }}
                    height={45}
                  />
                  <YAxis
                    type="number"
                    dataKey={chart.y[0]}
                    name={chart.y[0]}
                    tick={{ fontSize: 10 }}
                    tickFormatter={(v: number) => Number(v).toLocaleString()}
                    label={{
                      value: chart.y_label,
                      angle: -90,
                      position: "insideLeft",
                      fontSize: 10,
                      fill: "#5b7066",
                      style: { textAnchor: "middle" },
                    }}
                    width={80}
                  />
                  <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                  <Scatter
                    data={chart.rows}
                    name={chart.y[0]}
                    fill={palette[0]}
                  >
                    {chart.rows.map((r, i) => (
                      <Cell
                        key={i}
                        fill={
                          highlights.has(i)
                            ? highlightColor
                            : chart.series
                              ? palette[
                                  Math.max(
                                    0,
                                    Array.from(
                                      new Set(
                                        chart.rows.map((row) =>
                                          String(row[chart.series!]),
                                        ),
                                      ),
                                    ).indexOf(String(r[chart.series])),
                                  ) % 4
                                ]
                              : palette[0]
                        }
                      />
                    ))}
                  </Scatter>
                </ScatterChart>
              ) : (
                <BarChart
                  data={chart.rows}
                  layout={horizontal ? "vertical" : "horizontal"}
                  accessibilityLayer
                  margin={{ top: 5, right: 20, bottom: 15, left: 10 }}
                >
                  {axes}
                  {chart.y.map((y, i) => (
                    <Bar
                      dataKey={y}
                      key={y}
                      name={seriesName(chart, y)}
                      fill={palette[i % 4]}
                      {...(horizontal
                        ? { xAxisId: axisFor(y) }
                        : { yAxisId: axisFor(y) })}
                    >
                      {chart.rows.map((_, j) => (
                        <Cell
                          key={j}
                          fill={
                            isFlagged(j, y) ? highlightColor : palette[i % 4]
                          }
                        />
                      ))}
                    </Bar>
                  ))}
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>
        )}
      </div>
      {chart.highlights.length > 0 && (
        <ul
          className="text-xs text-orange-800 mt-3 space-y-1"
          aria-label="Outlier callouts"
        >
          {chart.highlights.slice(0, 8).map((h, i) => (
            <li key={i}>● {h.callout}</li>
          ))}
        </ul>
      )}
      {error && (
        <p role="alert" className="text-sm text-red-700 mt-2">
          {error}
        </p>
      )}
    </section>
  );
}
