"use client";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { Check } from "lucide-react";
import { statusApi } from "@/lib/api";

export type JourneyStep = "health" | "ask" | "challenge" | "pin" | "brief";

export function useProgress(datasetId: string) {
  return useQuery({
    queryKey: ["progress", datasetId],
    queryFn: () => statusApi.progress(datasetId),
    enabled: !!datasetId,
  });
}

export function Journey({
  datasetId,
  current,
}: {
  datasetId: string;
  current?: JourneyStep;
}) {
  const progress = useProgress(datasetId);
  const p = progress.data;
  const latest = p?.latest_completed_analysis_id;
  const ask = `/datasets/${datasetId}/ask`;
  const onFinding = latest ? `${ask}?analysis=${latest}` : ask;
  const steps: {
    key: JourneyStep;
    label: string;
    href: string;
    done: boolean;
    hint: string;
  }[] = [
    {
      key: "health",
      label: "Inspect health",
      href: `/datasets/${datasetId}`,
      done: true,
      hint: "Review quality issues and the cleaning log.",
    },
    {
      key: "ask",
      label: "Ask a question",
      href: ask,
      done: !!p?.completed_analyses,
      hint: "Ask a business question; InsightForge plans it, runs guarded SQL, and cites the evidence.",
    },
    {
      key: "challenge",
      label: "Challenge it",
      href: onFinding,
      done: !!p?.challenged_analyses,
      hint: "Open your finding and click Challenge My Insight to test alternative explanations.",
    },
    {
      key: "pin",
      label: "Pin evidence",
      href: onFinding,
      done: !!p?.pinned_findings,
      hint: "Pin the finding (and its challenge) to include them in a brief.",
    },
    {
      key: "brief",
      label: "Executive brief",
      href: p?.briefs[0] ? `/briefs/${p.briefs[0].id}` : onFinding,
      done: !!p?.briefs.length,
      hint: "Generate the one-page executive brief from your pinned evidence.",
    },
  ];
  const next = p ? steps.find((s) => !s.done) : undefined;
  return (
    <nav aria-label="Analysis journey" className="panel px-4 py-3 mb-6">
      <ol className="flex flex-wrap items-center gap-x-1 gap-y-2 text-xs">
        {steps.map((s, i) => {
          const isCurrent = s.key === current;
          const isNext = s.key === next?.key;
          return (
            <li key={s.key} className="flex items-center gap-1">
              {i > 0 && <span className="w-4 md:w-6 h-px bg-border" aria-hidden />}
              <Link
                href={s.href}
                aria-current={isCurrent ? "step" : undefined}
                className={`flex items-center gap-2 rounded-full border px-3 py-1.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
                  isCurrent
                    ? "border-primary bg-emerald-50 dark:bg-emerald-950 text-primary font-semibold"
                    : isNext
                      ? "border-amber-400 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200"
                      : "hover:bg-muted"
                }`}
              >
                <span
                  className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-semibold ${
                    s.done
                      ? "bg-primary text-white"
                      : "border border-current"
                  }`}
                  aria-hidden
                >
                  {s.done ? <Check size={12} /> : i + 1}
                </span>
                {s.label}
                <span className="sr-only">
                  {s.done ? " (done)" : isNext ? " (next step)" : ""}
                </span>
              </Link>
            </li>
          );
        })}
      </ol>
      <p className="subtle text-xs mt-2" aria-live="polite">
        {!p
          ? "Loading your progress…"
          : next
            ? `Next: ${next.hint}`
            : `All steps complete. ${p.briefs.length} brief${p.briefs.length === 1 ? "" : "s"} generated — refine it, or ask another question.`}
      </p>
    </nav>
  );
}
