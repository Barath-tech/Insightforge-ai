import json
from datetime import datetime, timezone

EVENT_TYPES = {
    "plan",
    "step_started",
    "sql_generated",
    "validation",
    "execution",
    "correction",
    "step_done",
    "finding",
    "error",
    "done",
}


class Events:
    def __init__(self, analysis_id, queue):
        self.analysis_id, self.queue, self.sequence = analysis_id, queue, 0
        self.finished = False

    async def emit(self, kind, payload):
        if self.finished:
            return
        assert kind in EVENT_TYPES
        self.sequence += 1
        await self.queue.put(
            {
                "type": kind,
                "analysis_id": self.analysis_id,
                "sequence": self.sequence,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "payload": payload,
            }
        )
        if kind == "done":
            self.finished = True


def frame(event):
    return "data: " + json.dumps(event, ensure_ascii=False, allow_nan=False) + "\n\n"
