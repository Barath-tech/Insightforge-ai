"use client";
import { QueryClient, QueryClientProvider, useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Activity,
  ChevronRight,
  Database,
  FileText,
  Layers3,
  Menu,
  MessageSquare,
  Moon,
  ShieldCheck,
  Sun,
  Terminal,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { BASE, api, briefApi, statusApi } from "@/lib/api";

type Crumb = { label: string; href?: string };

function routeInfo(path: string) {
  const datasetId = path.match(/^\/datasets\/([^/]+)/)?.[1];
  const briefId = path.match(/^\/briefs\/([^/]+)/)?.[1];
  const page = path.endsWith("/sql")
    ? "SQL workspace"
    : path.endsWith("/ask")
      ? "Ask InsightForge"
      : datasetId
        ? "Data health"
        : briefId
          ? "Executive brief"
          : path === "/audit"
            ? "AI Transparency"
            : path === "/"
              ? "Data library"
              : "Not found";
  return { datasetId, briefId, page };
}

function ModeBadge() {
  const health = useQuery({
    queryKey: ["health"],
    queryFn: statusApi.health,
    refetchInterval: 30000,
    retry: false,
  });
  const mode = health.error
    ? {
        label: "API offline",
        tone: "bg-red-50 text-red-800 border-red-200 dark:bg-red-950/40 dark:text-red-200",
        dot: "bg-red-500",
        help: `The backend is not reachable at ${BASE}. Start it, then refresh.`,
      }
    : !health.data
      ? {
          label: "Connecting…",
          tone: "",
          dot: "bg-muted-foreground",
          help: "Checking the backend.",
        }
      : health.data.demo_replay === "replay"
        ? {
            label: "Offline replay",
            tone: "bg-amber-50 text-amber-900 border-amber-200 dark:bg-amber-950/40 dark:text-amber-200",
            dot: "bg-amber-500",
            help: "AI responses are scripted for the demo question; SQL and statistics run for real. No API key or network is used.",
          }
        : health.data.demo_replay === "record"
          ? {
              label: "Live AI · recording",
              tone: "bg-emerald-50 text-emerald-900 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-200",
              dot: "bg-emerald-500",
              help: "Live model calls are saved for later offline replay.",
            }
          : health.data.llm_enabled
            ? {
                label: "Live AI",
                tone: "bg-emerald-50 text-emerald-900 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-200",
                dot: "bg-emerald-500",
                help: "Questions are answered with live model calls. Requests may incur charges.",
              }
            : {
                label: "AI unavailable · SQL only",
                tone: "",
                dot: "bg-muted-foreground",
                help: "No API key is configured. Data Health and the SQL workspace still work.",
              };
  return (
    <span
      className={`text-xs border rounded-full px-3 py-1 flex items-center gap-2 shrink-0 ${mode.tone}`}
      title={mode.help}
      role="status"
      aria-label={`Mode: ${mode.label}. ${mode.help}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${mode.dot}`} />
      {mode.label}
    </span>
  );
}

function Frame({ children }: { children: React.ReactNode }) {
  const [dark, setDark] = useState(false);
  const [menu, setMenu] = useState(false);
  const path = usePathname();
  const { datasetId: routeDataset, briefId, page } = routeInfo(path);
  const brief = useQuery({
    queryKey: ["brief", briefId],
    queryFn: () => briefApi.get(briefId!),
    enabled: !!briefId,
  });
  const datasetId = routeDataset || brief.data?.dataset_id;
  const dataset = useQuery({
    queryKey: ["dataset", datasetId],
    queryFn: () => api.dataset(datasetId!),
    enabled: !!datasetId,
  });
  const datasetName = dataset.data?.name;
  useEffect(() => {
    const value = localStorage.getItem("theme") === "dark";
    setDark(value);
    document.documentElement.classList.toggle("dark", value);
  }, []);
  useEffect(() => setMenu(false), [path]);
  useEffect(() => {
    document.title = [page, datasetName, "InsightForge AI"]
      .filter(Boolean)
      .join(" · ");
  }, [page, datasetName]);
  function toggle() {
    setDark(!dark);
    document.documentElement.classList.toggle("dark", !dark);
    localStorage.setItem("theme", !dark ? "dark" : "light");
  }
  const crumbs: Crumb[] = [{ label: "Data library", href: "/" }];
  if (datasetId)
    crumbs.push({
      label: datasetName || "Dataset",
      href: `/datasets/${datasetId}`,
    });
  if (page !== "Data library" && !(datasetId && page === "Data health"))
    crumbs.push({ label: page });
  // The last crumb is the current location, so it is not a link.
  crumbs[crumbs.length - 1] = { label: crumbs[crumbs.length - 1].label };
  const main = [
    { href: "/", label: "Data library", icon: Database },
    { href: "/audit", label: "AI Transparency", icon: ShieldCheck },
  ];
  const datasetLinks = datasetId
    ? [
        { href: `/datasets/${datasetId}`, label: "Data health", icon: Activity },
        { href: `/datasets/${datasetId}/ask`, label: "Ask InsightForge", icon: MessageSquare },
        { href: `/datasets/${datasetId}/sql`, label: "SQL workspace", icon: Terminal },
        ...(briefId ? [{ href: path, label: "Executive brief", icon: FileText }] : []),
      ]
    : [];
  const link = ({ href, label, icon: Icon }: (typeof main)[number]) => {
    const active = path === href;
    return (
      <Link
        key={href}
        href={href}
        aria-current={active ? "page" : undefined}
        className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${active ? "bg-emerald-50 dark:bg-emerald-950 text-primary font-semibold" : "text-muted-foreground hover:bg-muted"}`}
      >
        <Icon size={17} />
        {label}
      </Link>
    );
  };
  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 bg-primary text-white rounded-lg px-4 py-2"
      >
        Skip to main content
      </a>
      <div className="min-h-screen md:grid md:grid-cols-[240px_1fr]">
        <aside
          id="sidebar"
          className={`${menu ? "flex" : "hidden"} md:flex border-r bg-white dark:bg-[#111b17] p-6 flex-col md:sticky md:top-0 md:h-screen md:overflow-y-auto`}
        >
          <Link
            href="/"
            className="hidden md:flex gap-2 items-center font-bold text-xl tracking-tight"
          >
            <span className="bg-primary p-2 rounded-lg text-white">
              <Layers3 size={21} />
            </span>
            InsightForge
            <span className="text-primary text-xs self-start">AI</span>
          </Link>
          <nav aria-label="Primary" className="md:mt-10">
            <div className="eyebrow mb-3">Workspace</div>
            <div className="flex flex-col gap-1">{main.map(link)}</div>
            {datasetId && (
              <>
                <div className="eyebrow mt-8 mb-1">Current dataset</div>
                <p
                  className="text-sm font-semibold mb-3 truncate"
                  title={datasetName}
                >
                  {datasetName || "Loading…"}
                </p>
                <div className="flex flex-col gap-1">{datasetLinks.map(link)}</div>
              </>
            )}
          </nav>
          <div className="mt-auto pt-10">
            <div className="rounded-xl bg-muted p-4">
              <ShieldCheck size={20} className="text-primary mb-3" />
              <p className="text-sm font-semibold">Evidence comes first.</p>
              <p className="subtle mt-2 text-xs leading-relaxed">
                Deterministic profiles. Validated SQL. Every number from your
                data.
              </p>
            </div>
            <div className="flex justify-between items-center mt-5">
              <span className="text-xs text-muted-foreground">Theme</span>
              <Button
                variant="ghost"
                onClick={toggle}
                aria-label={dark ? "Switch to light theme" : "Switch to dark theme"}
                title="Toggle color theme"
              >
                {dark ? <Sun size={16} /> : <Moon size={16} />}
              </Button>
            </div>
          </div>
        </aside>
        <div className="min-w-0 md:col-start-2 md:row-start-1">
          <header className="min-h-16 border-b px-4 md:px-10 py-3 flex gap-3 justify-between items-center">
            <div className="flex items-center gap-3 min-w-0">
              <Button
                variant="ghost"
                className="md:hidden px-2"
                aria-label={menu ? "Close navigation" : "Open navigation"}
                aria-expanded={menu}
                aria-controls="sidebar"
                onClick={() => setMenu(!menu)}
              >
                {menu ? <X size={18} /> : <Menu size={18} />}
              </Button>
              <Link href="/" className="md:hidden text-primary" aria-label="InsightForge home">
                <Layers3 size={20} />
              </Link>
              <nav aria-label="Breadcrumb" className="min-w-0">
                <ol className="flex items-center gap-1 text-sm text-muted-foreground min-w-0">
                  {crumbs.map((c, i) => (
                    <li key={i} className="flex items-center gap-1 min-w-0">
                      {i > 0 && <ChevronRight size={14} className="shrink-0" />}
                      {c.href ? (
                        <Link href={c.href} className="hover:text-foreground hover:underline truncate">
                          {c.label}
                        </Link>
                      ) : (
                        <span className="text-foreground truncate" aria-current="page">
                          {c.label}
                        </span>
                      )}
                    </li>
                  ))}
                </ol>
              </nav>
            </div>
            <ModeBadge />
          </header>
          <main id="main" tabIndex={-1} className="max-w-[1500px] mx-auto p-4 md:p-10 focus:outline-none">
            {children}
          </main>
        </div>
      </div>
    </>
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: { queries: { retry: 1, staleTime: 30000 } },
      }),
  );
  return (
    <QueryClientProvider client={client}>
      <Frame>{children}</Frame>
    </QueryClientProvider>
  );
}
