"use client";
import { useState } from "react";
import Link from "next/link";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { BASE, BriefContent, briefApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { ErrorBox, Loading } from "@/components/shared";
import { Journey, useProgress } from "@/components/journey";
type Section =
  | "situation"
  | "evidence"
  | "root_cause"
  | "business_impact"
  | "recommended_actions";
type EvidenceItem = BriefContent["evidence"][number];
type ActionItem = BriefContent["recommended_actions"][number];
const titles: Record<Section, string> = {
  situation: "Situation",
  evidence: "Evidence",
  root_cause: "Root Cause",
  business_impact: "Business Impact",
  recommended_actions: "Recommended Actions",
};
const limits = { text: 500, owner: 70, priority: 30, impact: 350, max: 3 };
function SourceSelect({
  label,
  value,
  sources,
  onChange,
}: {
  label: string;
  value: string;
  sources: string[];
  onChange: (v: string) => void;
}) {
  const options = sources.includes(value) ? sources : [value, ...sources];
  return (
    <label className="text-xs block mt-2">
      {label}
      <select
        className="border rounded p-2 ml-2 bg-white text-slate-800"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>
    </label>
  );
}
export default function BriefPage({ params }: { params: { id: string } }) {
  const cache = useQueryClient(),
    router = useRouter();
  const [editing, setEditing] = useState<Section | "">(""),
    [draft, setDraft] = useState(""),
    [evidenceDraft, setEvidenceDraft] = useState<EvidenceItem[]>([]),
    [actionsDraft, setActionsDraft] = useState<ActionItem[]>([]);
  const b = useQuery({
    queryKey: ["brief", params.id],
    queryFn: () => briefApi.get(params.id),
  });
  const save = useMutation({
    mutationFn: () =>
      briefApi.edit(params.id, {
        [editing]:
          editing === "evidence"
            ? evidenceDraft
            : editing === "recommended_actions"
              ? actionsDraft
              : draft,
      }),
    onSuccess: (value) => {
      setEditing("");
      cache.setQueryData(["brief", params.id], value);
    },
  });
  const regenerate = useMutation({
    mutationFn: () => briefApi.create(b.data!.dataset_id, b.data!.analysis_ids),
    onSuccess: (v) => {
      void cache.invalidateQueries({ queryKey: ["progress", v.dataset_id] });
      router.push(`/briefs/${v.id}`);
    },
  });
  const progress = useProgress(b.data?.dataset_id ?? "");
  if (b.error)
    return <ErrorBox error={b.error} retry={() => void b.refetch()} />;
  if (!b.data) return <Loading />;
  const c = b.data.content_json;
  const datasetId = b.data.dataset_id;
  const included = (
    (b.data.evidence_json.findings as
      | { finding?: { headline?: string } }[]
      | undefined) ?? []
  ).map((f, i) => ({
    id: b.data!.analysis_ids[i],
    headline: f.finding?.headline || `Finding ${i + 1}`,
  }));
  const others = (progress.data?.briefs ?? []).filter((x) => x.id !== params.id);
  // Edit token templates so unchanged numbers keep their evidence links.
  const source = b.data.evidence_json.templates ?? c;
  const sources = b.data.evidence_json.sources;
  const start = (key: Section) => {
    save.reset();
    setEditing(key);
    if (key === "evidence")
      setEvidenceDraft(source.evidence.map((e) => ({ ...e })));
    else if (key === "recommended_actions")
      setActionsDraft(source.recommended_actions.map((a) => ({ ...a })));
    else setDraft(source[key]);
  };
  const updateEvidence = (i: number, change: Partial<EvidenceItem>) =>
    setEvidenceDraft((items) =>
      items.map((e, j) => (j === i ? { ...e, ...change } : e)),
    );
  const updateAction = (i: number, change: Partial<ActionItem>) =>
    setActionsDraft((items) =>
      items.map((a, j) => (j === i ? { ...a, ...change } : a)),
    );
  const editor = (key: Section) => {
    if (key === "evidence")
      return (
        <div className="space-y-3 mt-2">
          {evidenceDraft.map((e, i) => (
            <fieldset key={i} className="border rounded p-3">
              <legend className="text-xs px-1">Evidence item {i + 1}</legend>
              <textarea
                aria-label={`Evidence item ${i + 1} text`}
                className="border rounded w-full p-2 min-h-20 text-sm bg-white text-slate-800"
                maxLength={limits.text}
                value={e.text}
                onChange={(v) => updateEvidence(i, { text: v.target.value })}
              />
              <SourceSelect
                label={`Evidence item ${i + 1} source`}
                value={e.source}
                sources={sources}
                onChange={(v) => updateEvidence(i, { source: v })}
              />
              <button
                type="button"
                className="text-xs underline mt-2"
                onClick={() =>
                  setEvidenceDraft((items) => items.filter((_, j) => j !== i))
                }
              >
                Remove evidence item {i + 1}
              </button>
            </fieldset>
          ))}
          {evidenceDraft.length < limits.max && (
            <Button
              type="button"
              variant="outline"
              onClick={() =>
                setEvidenceDraft((items) => [
                  ...items,
                  { text: "", source: sources[0] ?? "finding:0" },
                ])
              }
            >
              Add evidence item
            </Button>
          )}
        </div>
      );
    if (key === "recommended_actions")
      return (
        <div className="space-y-3 mt-2">
          {actionsDraft.map((a, i) => (
            <fieldset key={i} className="border rounded p-3 text-sm">
              <legend className="text-xs px-1">Action {i + 1}</legend>
              <div className="grid sm:grid-cols-2 gap-2">
                <label className="text-xs">
                  Owner role
                  <input
                    aria-label={`Action ${i + 1} owner role`}
                    className="border rounded w-full p-2 bg-white text-slate-800"
                    maxLength={limits.owner}
                    value={a.owner_role}
                    onChange={(v) =>
                      updateAction(i, { owner_role: v.target.value })
                    }
                  />
                </label>
                <label className="text-xs">
                  Priority
                  <input
                    aria-label={`Action ${i + 1} priority`}
                    className="border rounded w-full p-2 bg-white text-slate-800"
                    maxLength={limits.priority}
                    value={a.priority}
                    onChange={(v) =>
                      updateAction(i, { priority: v.target.value })
                    }
                  />
                </label>
              </div>
              <label className="text-xs block mt-2">
                Expected impact
                <textarea
                  aria-label={`Action ${i + 1} expected impact`}
                  className="border rounded w-full p-2 min-h-16 bg-white text-slate-800"
                  maxLength={limits.impact}
                  value={a.expected_impact}
                  onChange={(v) =>
                    updateAction(i, { expected_impact: v.target.value })
                  }
                />
              </label>
              <SourceSelect
                label={`Action ${i + 1} linked evidence`}
                value={a.linked_evidence}
                sources={sources}
                onChange={(v) => updateAction(i, { linked_evidence: v })}
              />
              <button
                type="button"
                className="text-xs underline mt-2"
                onClick={() =>
                  setActionsDraft((items) => items.filter((_, j) => j !== i))
                }
              >
                Remove action {i + 1}
              </button>
            </fieldset>
          ))}
          {actionsDraft.length < limits.max && (
            <Button
              type="button"
              variant="outline"
              onClick={() =>
                setActionsDraft((items) => [
                  ...items,
                  {
                    owner_role: "",
                    priority: "Medium",
                    expected_impact: "",
                    linked_evidence: sources[0] ?? "finding:0",
                  },
                ])
              }
            >
              Add action
            </Button>
          )}
        </div>
      );
    return (
      <textarea
        aria-label={`Edit ${titles[key]}`}
        className="border rounded w-full p-3 min-h-28 text-slate-800 bg-white"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
      />
    );
  };
  return (
    <>
      <Journey datasetId={datasetId} current="brief" />
      <div className="flex flex-wrap justify-between gap-3">
        <h1 className="page-title">Executive brief</h1>
        <div className="flex gap-2">
          <Button asChild>
            <a href={`${BASE}/api/briefs/${params.id}/pdf`}>Download PDF</a>
          </Button>
          <Button asChild variant="outline">
            <a href={`${BASE}/api/briefs/${params.id}/markdown`}>
              Download Markdown
            </a>
          </Button>
          <Button
            variant="outline"
            disabled={regenerate.isPending}
            onClick={() => regenerate.mutate()}
          >
            {regenerate.isPending ? "Regenerating…" : "Regenerate"}
          </Button>
        </div>
      </div>
      {regenerate.error && <ErrorBox error={regenerate.error} />}
      <article className="mx-auto max-w-[800px] bg-white text-slate-800 shadow-lg border rounded p-8 md:p-12 my-7">
        <p className="eyebrow text-emerald-800 border-b-2 border-emerald-700 pb-3">
          INSIGHTFORGE AI / EXECUTIVE BRIEF
        </p>
        <h2 className="text-3xl font-semibold mt-6">{b.data.title}</h2>
        <p className="text-xs text-slate-500 mt-3">
          {new Date(b.data.created_at).toLocaleDateString()} ·{" "}
          {b.data.evidence_json.dataset_name} · {b.data.audience}
        </p>
        {(Object.keys(titles) as Section[]).map((key) => (
          <section className="mt-6" key={key}>
            <div className="flex justify-between">
              <h3 className="font-semibold text-emerald-800">{titles[key]}</h3>
              {editing !== key && (
                <button
                  className="text-xs underline"
                  disabled={!!editing}
                  onClick={() => start(key)}
                >
                  Edit {titles[key].toLowerCase()}
                </button>
              )}
            </div>
            {editing === key ? (
              <div>
                {editor(key)}
                {save.error && <ErrorBox error={save.error} />}
                <div className="flex gap-2 mt-3">
                  <Button
                    onClick={() => save.mutate()}
                    disabled={save.isPending}
                  >
                    {save.isPending ? "Saving…" : "Save section"}
                  </Button>
                  <Button
                    variant="outline"
                    disabled={save.isPending}
                    onClick={() => setEditing("")}
                  >
                    Cancel
                  </Button>
                </div>
                <p className="text-xs my-2">
                  Write numbers as evidence tokens such as{" "}
                  <code>{"{{e:scale_max}}"}</code> (see the token list below).
                  Unsupported numbers or sources are removed and the brief is
                  marked unverified until corrected.
                </p>
              </div>
            ) : key === "evidence" ? (
              <ul className="text-sm mt-2 space-y-2">
                {c.evidence.map((e, i) => (
                  <li key={i}>
                    {e.text}{" "}
                    <span className="text-xs text-slate-500">[{e.source}]</span>
                  </li>
                ))}
              </ul>
            ) : key === "recommended_actions" ? (
              <ul className="text-sm mt-2 space-y-2">
                {c.recommended_actions.map((a, i) => (
                  <li key={i}>
                    <strong>
                      {a.owner_role} · {a.priority}
                    </strong>
                    : {a.expected_impact} [{a.linked_evidence}]
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm leading-relaxed mt-2">{c[key]}</p>
            )}
          </section>
        ))}
        <footer className="border-t mt-8 pt-4 text-xs text-slate-600">
          <strong>Data quality & confidence</strong>
          <p>{c.confidence_statement}</p>
          {c.risks_and_caveats.map((v, i) => (
            <p key={i}>{v}</p>
          ))}
          <p className="mt-3" role="status">
            Grounding: {b.data.grounding_json.status}
          </p>
          {b.data.grounding_json.errors.map((v, i) => (
            <p className="text-orange-800" key={i}>
              {v}
            </p>
          ))}
        </footer>
      </article>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <section className="panel p-4">
          <h2 className="font-semibold text-sm">Evidence behind this brief</h2>
          <ul className="mt-2 space-y-1 text-sm">
            {included.map((f) => (
              <li key={f.id}>
                <Link
                  className="text-primary underline"
                  href={`/datasets/${datasetId}/ask?analysis=${f.id}`}
                >
                  {f.headline}
                </Link>
              </li>
            ))}
          </ul>
          <p className="subtle text-xs mt-2">
            Opens the saved analysis with its SQL, results, and challenge.
          </p>
        </section>
        <section className="panel p-4">
          <h2 className="font-semibold text-sm">Other briefs for this dataset</h2>
          {others.length ? (
            <ul className="mt-2 space-y-1 text-sm">
              {others.map((o) => (
                <li key={o.id}>
                  <Link className="text-primary underline" href={`/briefs/${o.id}`}>
                    {o.title}
                  </Link>{" "}
                  <span className="subtle text-xs">
                    {new Date(o.created_at).toLocaleString(undefined, {
                      dateStyle: "short",
                      timeStyle: "short",
                    })}{" "}
                    · {o.grounding_status}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="subtle text-xs mt-2">
              This is the only brief so far. Regenerate to compare wording.
            </p>
          )}
        </section>
      </div>
      <details className="panel p-4">
        <summary>Evidence tokens for manual editing</summary>
        <pre className="overflow-auto text-xs mt-4">
          {Object.entries(b.data.evidence_json.numbers)
            .map(([k, v]) => `{{e:${k}}} = ${v}`)
            .join("\n")}
        </pre>
        <p className="text-xs mt-3">
          Evidence references: {sources.join(", ") || "none"}
        </p>
      </details>
    </>
  );
}
