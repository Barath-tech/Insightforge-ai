"""One durable QueryRun for each submission, shared by console and agent."""

import time

from app.core.config import settings
from app.llm.redaction import sanitize
from app.models.metadata import QueryRun
from app.services.executor import execute
from app.services.sql_guard import SQLValidationError, validate_sql


def submit(
    session, dataset, sql, source="console", cancel=None, on_validation=None, policy_check=None
):
    start = time.perf_counter()
    run = QueryRun(dataset_id=dataset.id, sql=sql, status="running", source=source)
    session.add(run)
    session.commit()
    result, normalized = None, None
    try:
        normalized = validate_sql(sql, dataset.table_names)
        if policy_check:
            policy_check(normalized)
        if on_validation:
            on_validation({"status": "ok", "normalized_sql": normalized})
        result = execute(
            dataset.duckdb_path,
            normalized,
            dataset.table_names,
            settings.query_timeout_seconds,
            settings.query_max_rows,
            cancel=cancel,
        )
        run.status, run.row_count = "ok", result["row_count"]
    except SQLValidationError as exc:
        run.status, run.error = "validation_error", sanitize(str(exc))[:1000]
        if on_validation:
            on_validation({"status": "failed", "error": run.error})
    except InterruptedError:
        run.status, run.error = "cancelled", "Analysis cancelled."
    except Exception as exc:
        run.status, run.error = "execution_error", sanitize(str(exc))[:1000]
    finally:
        run.elapsed_ms = round((time.perf_counter() - start) * 1000, 2)
        session.add(run)
        session.commit()
        session.refresh(run)
    return {"run": run.model_dump(mode="json"), "result": result, "normalized_sql": normalized}
