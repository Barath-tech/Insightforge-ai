# Remaining work

Updated: 22 November 2026. The offline analysis → challenge → brief product is functionally complete, validated, and polished for orientation. This file lists only what is still outstanding, followed by a record of what was completed.

## Still to do

### Verification that could not run in the current environment

- **Docker Compose (`docker compose up --build`).** Compose and the backend Dockerfile were updated (replay by default, fixtures refreshed from the image on each start, HarfBuzz for PDFs) but not built end to end: the authoring network's TLS inspection blocks `pip`/`npm` inside image builds. Validate on an unrestricted network, then confirm `/api/health`, the demo flow, SQLite upload, and PDF export inside the containers.
- **SQLite extension paths.** Three backend tests (`test_upload_profile_preview_query[uk_retail.sqlite]`, `test_sqlite_multiple_tables_and_names`, `test_schema_multitable_and_missing_profile`) and the **SQLite fallback** demo need DuckDB's SQLite extension, which the proxy blocks. They pass with a matching DuckDB 1.5.5/extension pair; rerun with the locked DuckDB 1.5.6 where `extensions.duckdb.org` is reachable.
- **Fresh-checkout `make setup && make demo` on native Linux/WSL.** Verified only inside a Linux container on Windows.
- **Browser run of the extended validation (tests 07–13).** Ask, Challenge, brief, and audit are covered by the Playwright demo test (now passing against the production build from Windows Edge) and by 80/82 API-level checks, but the longer per-feature browser suite could not finish because Docker Desktop crashed under load with a 1 CPU / 2 GB `.wslconfig`. Rerun on a machine with more resources.
- **`make e2e` inside Linux.** On this machine the E2E was run from Windows with Edge against the hosted production build, because `next dev` + Chromium exceeded the 2 GB Docker limit. Confirm `make e2e` (Chromium, ports 3100/8100) on Linux or CI.
- **CI.** The project folder is not a Git repository here, so the GitHub Actions workflow was not run remotely. Push, then confirm `make setup gen-data`, `make test lint build`, and `make e2e` pass on `ubuntu-latest`.
- **Live OpenAI operation.** No authorised key was used. Run `INSIGHTFORGE_LIVE_TEST=1 .venv/bin/python -m pytest backend/tests -m live -q` with a key, then try the London question and a few unscripted questions in `DEMO_REPLAY=off`. Committed replay fixtures remain labelled `scripted_fixture`.
- **TCS GenAI Lab gateway.** The client now supports `OPENAI_BASE_URL` (configured locally for `https://genailab.tcs.in/` with model `genailab-openai-gpt-5.6-luna`; TLS verifies and the endpoint answers 403 without a key). Not yet exercised with a key: paste it into `OPENAI_API_KEY`, restart the backend in live mode, and confirm the gateway accepts Responses API Structured Outputs (`responses.parse` with `text_format`) and the `store`/`max_output_tokens` parameters.

### Documentation and delivery

- Create `docs/DEMO_SCRIPT.md` (presenter script for the walkthrough in HOW_TO_RUN.md).
- Update `AGENTS.md` for the final modules (`analysis/`, `challenge/`, `report/`, `llm/replay.py`, `components/journey.tsx`), commands (`make demo`, `make demo-stop`, `make seed-replay`, `make e2e`, `make screenshots`), replay conventions, and the separate Next.js output folders. Its last line still forbids Phase 3/4 work that now exists.
- Commit outstanding work (tests, UI, configuration, docs) in reviewable commits.
- Package the submission. Exclude `.env`, `.venv/`, `frontend/node_modules/`, `frontend/.next*`, `frontend/test-results/`, `work/` (logs, PID files, `demo-proof/`), `data/metadata.sqlite`, `data/datasets/`, and `data/extensions/`. Include `data/samples/` and `data/demo_cache/` (19 scripted entries; regenerated, stale entries removed).

### Product follow-ups (optional)

- **Replay sensitivity to error text.** Correction contexts include execution error messages, so a timing-dependent failure (for example a timeout on a slow machine) causes a replay miss. Consider normalising volatile error text in the replay key, or raising the default `QUERY_TIMEOUT_SECONDS`.
- **Query worker start-up cost.** Each query spawns a fresh interpreter (about 2–3 s on a constrained host). A small pool of pre-started read-only workers would reduce latency while keeping isolation.
- **Dependency advisories.** Next.js 14.2.35 carries known advisories (see `dependency-audit.json`). Upgrade and revalidate before any public deployment.
- **Repository dev container.** The Windows Docker workflow in HOW_TO_RUN.md could be shipped as a `.devcontainer/` configuration.
- **Further orientation ideas.** A first-run guided tour; per-dataset rename/delete in the library (dataset deletion remains deferred); a compact history filter (questions only / include challenge tests); a "what changed since last brief" view.

## Completed — orientation polish (22 November 2026)

- **Global orientation:** breadcrumb trail (Data library › dataset › page), live mode badge (Offline replay / Live AI / AI unavailable / API offline, with explanations), dataset-scoped sidebar section with the current dataset name, page titles naming page and dataset, skip-to-content link, consistent focus outlines, smooth anchor scrolling (respects reduced motion), and a mobile navigation menu.
- **Analysis journey tracker** on Data Health, Ask, SQL, and brief pages: five linked steps, ticks for completed steps, the next step highlighted with a one-line hint. Backed by a new read-only `GET /api/datasets/{id}/progress` endpoint (tested).
- **Home page:** "How it works" five-step strip, "Continue where you left off" link, "Most recent" badge, file names and times in the library.
- **Ask workspace:** offline-replay banner with a **Use the demo question** button; deep links (`?analysis=<id>`) kept in the URL; active analysis highlighted in history with coloured status and timestamps; **Next step** hint under each finding (challenge → pin → brief); **Generate Executive Brief** disabled until a finding is pinned, with a pinned-count explanation.
- **Challenge tests separated from questions:** history labels them **Challenge test** (indented, dashed), `GET /analyses` returns `challenge_of`, the test view offers **Back to the original finding** and hides Challenge/Pin actions, and progress counts exclude them. History refreshes after a challenge completes (bug found by the E2E run).
- **Data Health:** primary **Next: Ask a question** action alongside the SQL workspace.
- **Executive brief:** journey bar, **Evidence behind this brief** links to each analysis, **Other briefs for this dataset** list.
- **AI Transparency:** intro text, per-call links to the analysis or dataset, "show only this analysis", and paging (25 at a time with a count) instead of one very long list.
- **Error and 404 pages** explain what happened and link back to the library and audit.
- **Verification:** backend 110 passed (3 extension-blocked); ruff, ESLint, TypeScript, 4 frontend unit tests, and the production build pass; the extended Playwright demo test (journey, mode badge, breadcrumb, demo-question shortcut, deep link, challenge-test labels, pinned-count, audit paging) passes; `docs/screenshots/` recaptured and inspected (desktop and mobile layouts reviewed).

## Completed — previous pass (19 November 2026)

### Fixes

- `test_correction_audit_history_schema` now includes the audited population COUNT query.
- Outlier callouts: timestamps display as dates (no colon-split duplication); one consolidated callout per flagged cell lists every detection method; scatter outliers are labelled by descriptive columns.
- Cross-step consistency now measures actual directional agreement between the decomposition and time-series evidence (mapped to implied margin direction); it is neutral when fewer than two comparable signals exist. Exposed in the evidence bundle and UI.
- Challenge verdicts require a completed test whose final planned step succeeded; partial failures are INCONCLUSIVE.
- Query timeout now starts after the worker connects (start-up has a separate 30-second bound), removing false timeouts caused by interpreter start-up.
- PDF SQL appendix no longer double-escapes quotes and `<`; challenge SQL is labelled by hypothesis, step, attempt, and status; caveats render as a list.
- Generator writes the SQLite sample byte-stably.

### Features and polish

- Inline structured editing of Evidence and Recommended Actions (add, remove, edit, choose source). Edits re-ground the whole brief from stored token templates, so correcting a section restores *verified*.
- Decision page auto-fits one A4 page (type scale steps down for long content); verified with maximum-length content.
- Charts: secondary axis for mixed-scale measures (UI and PDF), labelled axes, date tick formatting, rotated category labels, number formatting, per-cell highlighting, scatter axes, accessible chart descriptions and keyboard support, PNG export including legend and callouts.
- Margin bridge rebuilt as a true waterfall with population mix and an observed-change total; zero-impact components omitted with a note.
- Pin buttons send explicit state and wait for pin data.
- Separate Next.js output folders for dev, build, and E2E.
- Demo launcher: verifies reused servers (identity and replay mode), waits for frontend readiness, records PID identity, and adds `make demo-stop` for launcher-owned processes only.
- Docker Compose: replay mode by default, optional key/model passthrough, fixtures copied from the image on each start, HarfBuzz for PDF rendering.
- Replay cache re-seeded (19 entries, stale entries removed; recording again adds nothing; pure replay passes).

### Verification

- Backend 109 passed (3 extension-blocked), ruff clean; frontend type-check, lint, unit tests, and production build pass.
- Playwright full offline flow passes, including PNG export and structured brief edits.
- PDF pages inspected visually.
- Offline validation of every feature: browser checks for home, Data Health, uploads, SQL workspace, and issue links; 80/82 API checks for Ask, cancellation, Challenge, pins, briefs, exports, audit, errors, guard negatives, and admission control (the two misses were incorrect test expectations).
- New documentation: README overhaul, HOW_TO_RUN.md updates, `docs/OPENAI_USAGE.md`.
