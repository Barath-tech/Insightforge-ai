"""Injectable one-request transport plus bounded, audited orchestration."""

import asyncio
import json
import ssl
import time
from pathlib import Path
from typing import Protocol

import httpx
from openai import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AsyncOpenAI,
    AuthenticationError,
    RateLimitError,
)
from pydantic import ValidationError
from sqlmodel import Session

from app.core.config import settings
from app.llm.redaction import redact
from app.models.analysis import LLMCall

PROMPT_VERSION = "system_v2"
PROMPT = Path(__file__).with_name("prompts").joinpath(PROMPT_VERSION + ".txt").read_text()


class LLMError(Exception):
    def __init__(self, code, message, retryable=False):
        super().__init__(message)
        self.code, self.retryable = code, retryable


class Transport(Protocol):
    async def request(self, purpose, context, response_model): ...


def client_options():
    """AsyncOpenAI options: official API by default, or a configured compatible gateway."""
    options = {
        "api_key": settings.openai_api_key,
        "max_retries": 0,
        "timeout": settings.llm_timeout_seconds,
    }
    if settings.openai_base_url:
        options["base_url"] = settings.openai_base_url
    if settings.openai_ca_bundle or not settings.openai_verify_ssl or settings.openai_base_url:
        if settings.openai_verify_ssl:
            # System trust store (includes enterprise roots) plus an optional extra bundle.
            verify = ssl.create_default_context()
            if settings.openai_ca_bundle:
                verify.load_verify_locations(cafile=settings.openai_ca_bundle)
        else:
            verify = False
        options["http_client"] = httpx.AsyncClient(
            verify=verify, timeout=settings.llm_timeout_seconds
        )
    return options


class OpenAITransport:
    async def request(self, purpose, context, response_model):
        if not settings.openai_api_key:
            raise LLMError(
                "unavailable", "AI is unavailable. Configure OPENAI_API_KEY on the backend."
            )
        async with AsyncOpenAI(**client_options()) as client:
            response = await client.responses.parse(
                model=settings.openai_model,
                input=[
                    {"role": "system", "content": PROMPT},
                    {
                        "role": "user",
                        "content": json.dumps(
                            {"purpose": purpose, "untrusted_data": context}, default=str
                        ),
                    },
                ],
                text_format=response_model,
                max_output_tokens=settings.llm_max_output_tokens,
                store=False,
            )
        return response


def get_transport():
    if settings.demo_replay in {"record", "replay"}:
        from app.llm.replay import ReplayTransport

        return ReplayTransport(settings.demo_replay, OpenAITransport())
    return OpenAITransport()


def error_info(exc):
    if isinstance(exc, LLMError):
        return exc
    if isinstance(exc, AuthenticationError):
        return LLMError(
            "authentication", "OpenAI authentication failed. Check backend configuration."
        )
    if isinstance(exc, RateLimitError):
        return LLMError(
            "rate_limit",
            "OpenAI rate limit reached. Try later or switch to DEMO_REPLAY=replay.",
            True,
        )
    if isinstance(exc, (APITimeoutError, TimeoutError)):
        return LLMError("timeout", "The model request timed out.", True)
    if isinstance(exc, APIConnectionError):
        return LLMError("connection", "Could not reach the model service.", True)
    if isinstance(exc, APIStatusError):
        return LLMError(
            "service", "The model service could not complete the request.", exc.status_code >= 500
        )
    if isinstance(exc, (ValidationError, ValueError, json.JSONDecodeError)):
        return LLMError("schema", "Response did not match the required schema.")
    return LLMError("model_error", "The model request could not be completed.")


class Client:
    def __init__(self, engine, dataset_id, transport, analysis_id=None):
        self.engine, self.dataset_id = engine, dataset_id
        self.transport, self.analysis_id = transport, analysis_id

    def save(self, call):
        with Session(self.engine) as session:
            session.add(call)
            session.commit()
            session.refresh(call)

    async def generate(self, purpose, context, response_model):
        if isinstance(self.transport, OpenAITransport) and not settings.openai_api_key:
            raise LLMError(
                "unavailable",
                "AI unavailable: configure OPENAI_API_KEY or switch to DEMO_REPLAY=replay.",
            )
        # One repair and a separate shared transport budget for this generation.
        repaired, retries = False, 0
        context = dict(context)
        while True:
            if len(json.dumps(context, default=str)) > settings.llm_context_chars:
                raise LLMError(
                    "context_limit", "Dataset context is too large; use a smaller dataset."
                )
            call = LLMCall(
                dataset_id=self.dataset_id,
                analysis_id=self.analysis_id,
                purpose=purpose,
                model=(
                    "replay:" + settings.openai_model
                    if getattr(self.transport, "mode", None) == "replay"
                    else settings.openai_model
                ),
                prompt_version=PROMPT_VERSION,
                request_json=redact(
                    {"context": context, "response_schema": response_model.__name__}
                ),
            )
            await asyncio.to_thread(self.save, call)
            start = time.perf_counter()
            error = None
            try:
                response = await asyncio.wait_for(
                    self.transport.request(purpose, context, response_model),
                    timeout=settings.llm_timeout_seconds,
                )
                # Fake transports use the same response validation and audit path.
                if isinstance(response, dict):
                    raw = response
                else:
                    call.response_json = redact(
                        {
                            "status": response.status,
                            "output": response.model_dump().get("output", []),
                        }
                    )
                    usage = response.usage
                    call.input_tokens = usage.input_tokens if usage else None
                    call.output_tokens = usage.output_tokens if usage else None
                    if response.status != "completed":
                        raise LLMError("incomplete", "Model response was incomplete.")
                    if any(
                        c.type == "refusal"
                        for o in response.output
                        if o.type == "message"
                        for c in o.content
                    ):
                        raise LLMError("refusal", "The model declined this request.")
                    if response.output_parsed is None:
                        raise ValueError("Missing structured output")
                    raw = response.output_parsed.model_dump()
                call.response_json = redact(raw)
                parsed = response_model.model_validate(raw)
                call.status = "ok"
            except asyncio.CancelledError:
                call.status, call.error = "cancelled", "Request cancelled."
                raise
            except Exception as exc:
                error = error_info(exc)
                if isinstance(exc, ValidationError):
                    locations = [
                        ".".join(map(str, item["loc"]))
                        for item in exc.errors(include_input=False, include_url=False)[:6]
                    ]
                    error = LLMError("schema", "Invalid response fields: " + ", ".join(locations))
                call.status, call.error = error.code, str(error)
            finally:
                call.latency_ms = round((time.perf_counter() - start) * 1000, 2)
                await asyncio.shield(asyncio.to_thread(self.save, call))
            if error is None:
                return parsed
            if error.code == "schema" and not repaired:
                repaired = True
                context["schema_repair"] = str(error)
                continue
            if error.retryable and retries < settings.llm_transport_retries:
                retries += 1
                await asyncio.sleep(min(retries, 2))
                continue
            raise error
