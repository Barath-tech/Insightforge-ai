"""Additive storage: preserve all Phase 2 tables without destructive migrations."""

from datetime import datetime
from uuid import uuid4

from sqlalchemy import JSON, Column
from sqlmodel import Field, SQLModel

from app.models.metadata import now


class Challenge(SQLModel, table=True):
    __tablename__ = "challenges"
    id: str = Field(default_factory=lambda: str(uuid4()), primary_key=True)
    analysis_id: str = Field(foreign_key="analyses.id", index=True)
    status: str = "running"
    result_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=now)


class Pin(SQLModel, table=True):
    __tablename__ = "pins"
    item_id: str = Field(primary_key=True)
    kind: str
    dataset_id: str = Field(foreign_key="datasets.id", index=True)
    pinned: bool = False


class Brief(SQLModel, table=True):
    __tablename__ = "briefs"
    id: str = Field(default_factory=lambda: str(uuid4()), primary_key=True)
    dataset_id: str = Field(foreign_key="datasets.id", index=True)
    title: str
    audience: str
    content_json: dict = Field(sa_column=Column(JSON))
    evidence_json: dict = Field(sa_column=Column(JSON))
    grounding_json: dict = Field(default_factory=dict, sa_column=Column(JSON))
    analysis_ids: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=now)
