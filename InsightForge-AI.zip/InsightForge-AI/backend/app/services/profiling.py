"""Deterministic cleaning and evidence-only profiling; no fixture-specific constants."""

import json
import re

import pandas as pd


def snake(name):
    name = re.sub(r"[^a-z0-9]+", "_", str(name).lower()).strip("_") or "column"
    return "c_" + name if name[0].isdigit() else name


def json_records(frame):
    return json.loads(frame.to_json(orient="records", date_format="iso"))


def clean_and_profile(raw):
    df = raw.copy()
    mapping, used = {}, set()
    for original in raw.columns:
        base = snake(original)
        name, suffix = base, 2
        while name in used:
            name, suffix = f"{base}_{suffix}", suffix + 1
        used.add(name)
        mapping[str(original)] = name
    df.columns = list(mapping.values())
    logs, issues, types = [], [], {}

    def issue(code, column, count, severity, message, samples):
        if count:
            issues.append(
                dict(
                    code=code,
                    column=column,
                    count=int(count),
                    severity=severity,
                    message=message,
                    samples=[str(x) for x in samples][:5],
                )
            )

    def log(column, action, count):
        if count:
            logs.append(dict(column=column, action=action, affected_rows=int(count)))

    for original, col in mapping.items():
        if original != col:
            log(col, f"Renamed from {original}", len(df))
        s = df[col]
        text = s.astype("string").str.strip().replace("", pd.NA)
        present = text.dropna()
        log(col, "Trimmed surrounding whitespace", (s.astype("string") != text).fillna(False).sum())
        log(col, "Converted empty strings to NULL", (s.notna() & text.isna()).sum())
        if "date" in col or "timestamp" in col:
            # UK exports use day/month/year. Parse explicitly before generic ISO parsing.
            def parse(value):
                if pd.isna(value):
                    return pd.NaT
                if re.match(r"^\d{4}-\d{2}-\d{2}", value):
                    result = pd.to_datetime(value, format="ISO8601", errors="coerce", utc=True)
                    return result.tz_localize(None) if pd.notna(result) else pd.NaT
                for fmt in ["%d/%m/%Y", "%d %b %Y", "%d %B %Y"]:
                    try:
                        return pd.to_datetime(value, format=fmt)
                    except (ValueError, TypeError):
                        pass
                return pd.NaT

            parsed = text.map(parse)
            invalid = text.notna() & parsed.isna()
            formats = present.map(
                lambda v: (
                    "slash"
                    if "/" in v
                    else "named month"
                    if re.search(r"[A-Za-z]", v.replace("T", ""))
                    else "ISO"
                )
            ).value_counts()
            if len(formats) > 1:
                issue(
                    "mixed_dates",
                    col,
                    len(present),
                    "medium",
                    "Mixed date formats detected",
                    present.drop_duplicates().head(),
                )
            issue(
                "invalid_dates",
                col,
                invalid.sum(),
                "high",
                "Unparseable dates became NULL",
                text[invalid],
            )
            log(col, "Parsed mixed dates; invalid values become NULL", text.notna().sum())
            df[col], types[col] = pd.to_datetime(parsed), "datetime"
        elif col.endswith("_id") or col == "id":
            df[col], types[col] = text, "id"
        elif set(present.str.lower().unique()).issubset({"true", "false", "0", "1"}) and (
            col.endswith("flag") or s.dtype == bool
        ):
            df[col] = text.str.lower().map({"true": True, "false": False, "1": True, "0": False})
            types[col] = "boolean"
            if not pd.api.types.is_bool_dtype(s):
                log(col, "Converted boolean strings", text.notna().sum())
        else:
            currency = text.str.contains(r"[£$€]", na=False)
            stripped = text.str.replace(r"[£$€,]", "", regex=True)
            number = pd.to_numeric(stripped, errors="coerce")
            numeric = pd.api.types.is_numeric_dtype(s) or (
                len(present) > 0 and number.notna().sum() / len(present) >= 0.9
            )
            if numeric:
                df[col] = number
                types[col] = (
                    "currency"
                    if currency.any()
                    or any(word in col for word in ["price", "revenue", "cost", "cogs", "amount"])
                    else "numeric"
                )
                issue(
                    "currency_strings",
                    col,
                    currency.sum(),
                    "medium",
                    "Currency-formatted strings converted to numbers",
                    text[currency],
                )
                invalid = text.notna() & number.isna()
                issue(
                    "invalid_numeric",
                    col,
                    invalid.sum(),
                    "high",
                    "Invalid numbers became NULL",
                    text[invalid],
                )
                log(col, "Converted currency strings to numbers", currency.sum())
                log(col, "Invalid numeric values became NULL", invalid.sum())
                if not pd.api.types.is_numeric_dtype(s):
                    log(col, "Parsed numeric values", (number.notna() & ~currency).sum())
            else:
                normalized = text.str.title()
                changed = (text != normalized).fillna(False) | (s.astype("string") != text).fillna(
                    False
                )
                types[col] = "categorical" if text.nunique() <= max(30, len(df) * 0.1) else "text"
                df[col] = normalized if types[col] == "categorical" else text
                if types[col] == "categorical":
                    # Count inconsistent variants, not consistently lower-case categories.
                    variants = pd.DataFrame({"raw": s.astype("string"), "norm": normalized})
                    bad_norm = variants.groupby("norm").raw.nunique()
                    bad = normalized.isin(bad_norm[bad_norm > 1].index)
                    issue(
                        "inconsistent_casing",
                        col,
                        bad.sum(),
                        "medium",
                        "Casing or whitespace variants normalized",
                        s[bad].drop_duplicates(),
                    )
                    log(col, "Trimmed and title-cased categorical text", changed.sum())
        missing = df[col].isna()
        issue("missing_values", col, missing.sum(), "low", "Missing values", [])
        if "quantity" in col and pd.api.types.is_numeric_dtype(df[col]):
            bad = df[col] < 0
            issue(
                "negative_quantity", col, bad.sum(), "high", "Negative quantities", df.loc[bad, col]
            )
        if "discount" in col and pd.api.types.is_numeric_dtype(df[col]):
            bad = (df[col] > 100) | (df[col] < 0)
            issue(
                "impossible_discount",
                col,
                bad.sum(),
                "high",
                "Discount outside 0–100 percent",
                df.loc[bad, col],
            )
    id_col = next((c for c in df if c == "id" or c.endswith("_id")), None)
    if id_col:
        duplicate = df[id_col].notna() & df[id_col].duplicated()
        issue(
            "duplicate_ids",
            id_col,
            duplicate.sum(),
            "high",
            "Duplicate identifier rows retained",
            df.loc[duplicate, id_col],
        )
    if {"delivery_slot", "delivery_timestamp"}.issubset(df.columns):
        delivered = df.delivery_slot.notna() & ~df.delivery_slot.str.lower().isin(["none", "n/a"])
        bad = delivered & df.delivery_timestamp.isna()
        issue(
            "missing_delivery_timestamp",
            "delivery_timestamp",
            bad.sum(),
            "high",
            "Delivered orders missing timestamps",
            df.loc[bad, id_col] if id_col else [],
        )
    columns = []
    for col in df:
        s = df[col]
        profile = dict(
            name=col,
            semantic_type=types[col],
            null_count=int(s.isna().sum()),
            null_pct=round(float(s.isna().mean() * 100), 2),
            distinct_count=int(s.nunique()),
        )
        if types[col] in ["numeric", "currency"]:
            profile["stats"] = json_records(
                pd.DataFrame(
                    [
                        {
                            "min": s.min(),
                            "max": s.max(),
                            "mean": s.mean(),
                            "median": s.median(),
                            "std": s.std(),
                        }
                    ]
                )
            )[0]
            values = s.dropna()
            if len(values):
                bins = pd.cut(values, bins=8).value_counts(sort=False)
                profile["distribution"] = [
                    {"name": str(k), "count": int(v)} for k, v in bins.items()
                ]
        elif types[col] == "datetime":
            profile["date_range"] = [
                str(s.min()) if s.notna().any() else None,
                str(s.max()) if s.notna().any() else None,
            ]
        else:
            profile["distribution"] = [
                {"name": str(k), "count": int(v)} for k, v in s.value_counts().head(5).items()
            ]
        columns.append(profile)
    severity = {"high": 0, "medium": 1, "low": 2}
    issues.sort(key=lambda x: severity[x["severity"]])
    score = max(0, 100 - sum({"high": 8, "medium": 4, "low": 1}[x["severity"]] for x in issues))
    dates = [c["date_range"] for c in columns if c["semantic_type"] == "datetime"]
    return df, dict(
        row_count=len(df),
        column_count=len(df.columns),
        unique_ids=int(df[id_col].nunique()) if id_col else None,
        date_range=dates[0] if dates else None,
        health_score=score,
        columns=columns,
        issues=issues,
        cleaning_log=logs,
        column_mapping=mapping,
    )
