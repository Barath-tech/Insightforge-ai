"use client";
import { BriefButton } from "@/components/brief-button";
import { FindingExtras } from "@/components/finding-extras";
import { AnalysisChart } from "@/components/analysis-chart";
import { Journey } from "@/components/journey";
import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { sql } from "@codemirror/lang-sql";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Info, Play, Square, History, ShieldCheck } from "lucide-react";
import {
  api,
  analysisApi,
  Analysis,
  AnalysisEvent,
  Attempt,
  DEMO_QUESTION,
  Finding,
  planSchema,
  statusApi,
} from "@/lib/api";
import { z } from "zod";
import { DataTable, ErrorBox } from "@/components/shared";
import { Button } from "@/components/ui/button";
const CodeMirror = dynamic(() => import("@uiw/react-codemirror"), {
  ssr: false,
});

function FindingCard({ finding }: { finding: Finding }) {
  return (
    <section className="panel p-6 mt-6" aria-label="Grounded finding">
      <span
        className={`text-xs rounded-full px-3 py-1 ${finding.grounding_status === "verified" ? "bg-emerald-100 text-emerald-900" : "bg-amber-100 text-amber-900"}`}
      >
        {finding.grounding_status === "verified"
          ? "Numeric evidence verified"
          : "Unverified — review required"}
      </span>
      <h2 className="text-xl font-semibold mt-4">{finding.headline}</h2>
      <p className="leading-7 mt-3 whitespace-pre-wrap">{finding.answer}</p>
      <div className="grid sm:grid-cols-2 gap-3 my-5">
        {finding.key_numbers.map((number, i) => (
          <a
            key={i}
            href={`#evidence-${number.source_step_id}-${number.source_attempt}`}
            className="border rounded-lg p-4 hover:bg-muted"
          >
            <span className="text-xs subtle block">{number.label}</span>
            <strong className="block mt-1">
              {number.value} {number.unit === "number" ? "" : number.unit}
            </strong>
            <span className="text-xs text-primary">
              {number.source_step_id} · attempt {number.source_attempt} · row{" "}
              {number.row_index + 1} · {number.column} ↗
            </span>
          </a>
        ))}
      </div>
      <ul className="list-disc pl-5 space-y-2 text-sm subtle">
        {finding.caveats.map((c, i) => (
          <li key={i}>{c}</li>
        ))}
      </ul>
      {finding.grounding_errors.length > 0 && (
        <ErrorBox error={finding.grounding_errors.join("\n")} />
      )}
      <p className="text-xs subtle mt-4">
        Verification checks cited numerical evidence. It does not establish
        causality or statistical confidence.
      </p>
    </section>
  );
}

function AttemptCard({
  attempt: a,
  previous,
}: {
  attempt: Attempt;
  previous?: Attempt;
}) {
  const removed =
    previous?.generated_sql
      .split("\n")
      .filter((l) => !a.generated_sql.split("\n").includes(l)) || [];
  const added = previous
    ? a.generated_sql
        .split("\n")
        .filter((l) => !previous.generated_sql.split("\n").includes(l))
    : [];
  return (
    <section
      className="panel overflow-hidden mt-4 scroll-mt-6"
      id={`evidence-${a.step_id}-${a.attempt_no}`}
    >
      <div className="p-5 border-b">
        <div className="flex flex-wrap gap-2 items-center justify-between">
          <h3 className="font-semibold">
            {a.step_id} · Attempt {a.attempt_no}
          </h3>
          <span
            className={`text-xs rounded px-2 py-1 ${a.status === "ok" ? "bg-emerald-100 text-emerald-900" : "bg-muted"}`}
          >
            {a.status}
          </span>
        </div>
        <p className="text-sm mt-2">{a.purpose}</p>
        <p className="subtle text-xs mt-2">{a.rationale}</p>
      </div>
      <details className="p-4" open={a.status !== "ok"}>
        <summary className="cursor-pointer text-sm">
          SQL · Guard {a.validation_json.status || "pending"}
        </summary>
        <div className="mt-3">
          <CodeMirror
            value={a.generated_sql}
            extensions={[sql()]}
            editable={false}
            theme="none"
            aria-label={`SQL for ${a.step_id} attempt ${a.attempt_no}`}
          />
        </div>
        {previous && (
          <details className="mt-3 text-xs">
            <summary className="cursor-pointer">
              Changes from previous attempt
            </summary>
            <pre className="whitespace-pre-wrap mt-2">
              {removed.map((line, i) => (
                <div key={`r${i}`} className="text-red-600 dark:text-red-300">
                  − {line}
                </div>
              ))}
              {added.map((line, i) => (
                <div key={`a${i}`} className="text-primary">
                  + {line}
                </div>
              ))}
            </pre>
          </details>
        )}
      </details>
      {a.error && (
        <div className="px-4 pb-4">
          <ErrorBox error={a.error} />
        </div>
      )}
      {a.result_json?.chart && <AnalysisChart chart={a.result_json.chart} />}
      {a.result_json && (
        <>
          <p className="px-5 py-3 border-t text-xs subtle">
            {a.result_json.row_count} rows returned ·{" "}
            {a.result_json.elapsed_ms.toFixed(0)} ms ·{" "}
            {a.result_json.column_types?.join(", ")}
          </p>
          <DataTable
            columns={a.result_json.columns}
            rows={a.result_json.rows}
          />
          {a.result_json.truncated && (
            <p className="p-4 text-amber-700 dark:text-amber-300 text-sm">
              Results truncated. Only the returned evidence is shown.
            </p>
          )}
        </>
      )}
    </section>
  );
}

function Workspace({ id }: { id: string }) {
  const cache = useQueryClient();
  const [activeId, setActiveId] = useState("");
  const [question, setQuestion] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState("ready");
  const [plan, setPlan] = useState<z.infer<typeof planSchema> | null>(null);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [finding, setFinding] = useState<Finding | null>(null);
  const [events, setEvents] = useState<AnalysisEvent[]>([]);
  const controller = useRef<AbortController | null>(null);
  const revision = useRef(0);
  const following = useRef(true);
  const bottom = useRef<HTMLDivElement>(null);
  const dataset = useQuery({
    queryKey: ["dataset", id],
    queryFn: () => api.dataset(id),
  });
  const history = useQuery({
    queryKey: ["analyses", id],
    queryFn: () => analysisApi.history(id),
    refetchOnWindowFocus: false,
    refetchInterval: (query) =>
      query.state.data?.some(
        (a) => a.status === "running" || a.status === "pending",
      )
        ? 1500
        : false,
  });
  const suggestions = useQuery({
    queryKey: ["suggestions", id],
    queryFn: () => analysisApi.suggestions(id),
    staleTime: Infinity,
    retry: false,
    refetchOnWindowFocus: false,
  });
  const health = useQuery({
    queryKey: ["health"],
    queryFn: statusApi.health,
    retry: false,
  });
  const replay = health.data?.demo_replay === "replay";
  const parentId = history.data?.find((a) => a.id === activeId)?.challenge_of;
  useEffect(() => {
    const currentRevision = revision;
    const params = new URLSearchParams(window.location.search);
    setQuestion(params.get("question")?.slice(0, 2000) || "");
    const linked = params.get("analysis");
    if (linked) void open(linked);
    const scroll = () => {
      following.current =
        window.innerHeight + window.scrollY >=
        document.documentElement.scrollHeight - 160;
    };
    window.addEventListener("scroll", scroll);
    return () => {
      currentRevision.current++;
      controller.current?.abort();
      window.removeEventListener("scroll", scroll);
    };
    // Mount-only: read deep-link parameters once.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (busy && following.current)
      bottom.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [events, busy]);
  const show = (a: Analysis) => {
    setActiveId(a.id);
    setQuestion(a.question);
    setPlan(a.plan_json);
    setAttempts(a.steps);
    setFinding(a.finding_json);
    setStatus(a.status);
    setError(a.error);
    // Keep the open analysis in the URL so reloads and shared links return here.
    window.history.replaceState(null, "", `?analysis=${a.id}`);
  };
  async function open(identifier: string) {
    const token = ++revision.current;
    setError(null);
    setEvents([]);
    try {
      const a = await analysisApi.detail(identifier);
      if (revision.current === token) show(a);
    } catch (e) {
      if (revision.current === token) setError(String(e));
    }
  }
  async function submit() {
    if (controller.current || question.trim().length < 3) return;
    const token = ++revision.current;
    const active = new AbortController();
    controller.current = active;
    setBusy(true);
    setError(null);
    setPlan(null);
    setFinding(null);
    setAttempts([]);
    setEvents([]);
    setStatus("running");
    let analysisId = "";
    try {
      await analysisApi.ask(id, question, active.signal, (event) => {
        if (revision.current !== token) return;
        analysisId = event.analysis_id;
        setActiveId(analysisId);
        setEvents((old) => [...old, event]);
        if (event.type === "plan") setPlan(event.payload);
        if (event.type === "execution")
          setAttempts((old) => [
            ...old.filter(
              (a) =>
                a.step_id !== event.payload.step_id ||
                a.attempt_no !== event.payload.attempt_no,
            ),
            event.payload,
          ]);
        if (event.type === "finding") setFinding(event.payload);
        if (event.type === "error") setError(event.payload.message);
        if (event.type === "done") setStatus(event.payload.status);
      });
      if (analysisId && revision.current === token) {
        const completed = await analysisApi.detail(analysisId);
        if (revision.current === token) show(completed);
      }
    } catch (e) {
      if (revision.current === token) {
        if (active.signal.aborted) setStatus("cancelled");
        else {
          setError(e instanceof Error ? e.message : "Analysis failed.");
          setStatus("failed");
        }
      }
    } finally {
      if (revision.current === token) {
        setBusy(false);
        controller.current = null;
        void cache.invalidateQueries({ queryKey: ["analyses", id] });
        void cache.invalidateQueries({ queryKey: ["progress", id] });
      }
    }
  }
  return (
    <>
      <Journey datasetId={id} current="ask" />
      <div className="eyebrow mb-3">
        {dataset.data?.name || "Dataset"} / Analysis workspace
      </div>
      <h1 className="page-title">Questions, explored with evidence.</h1>
      <BriefButton datasetId={id} />
      <p className="subtle mt-3 flex items-center gap-2">
        <ShieldCheck size={16} /> Read-only queries · Visible corrections ·
        Cited findings
      </p>
      <div className="grid lg:grid-cols-[240px_minmax(0,1fr)] gap-6 mt-7">
        <aside className="panel p-4 h-fit lg:sticky lg:top-6">
          <h2 className="font-semibold flex gap-2 items-center">
            <History size={16} /> Analysis history
          </h2>
          {history.error && (
            <ErrorBox error={history.error} retry={() => history.refetch()} />
          )}
          {!history.data?.length && (
            <p className="subtle text-xs mt-4">
              Your saved analyses will appear here.
            </p>
          )}
          <div className="mt-3 max-h-[60vh] overflow-auto space-y-2">
            {history.data?.map((a) => (
              <button
                disabled={busy}
                key={a.id}
                onClick={() => open(a.id)}
                aria-current={a.id === activeId ? "true" : undefined}
                className={`text-left border rounded-lg p-3 hover:bg-muted disabled:opacity-50 ${a.id === activeId ? "border-primary bg-emerald-50/60 dark:bg-emerald-950/40" : ""} ${a.challenge_of ? "ml-3 w-[calc(100%-0.75rem)] border-dashed" : "w-full"}`}
              >
                {a.challenge_of && (
                  <span className="block text-[10px] uppercase tracking-wide text-muted-foreground mb-1">
                    Challenge test
                  </span>
                )}
                <span className="text-sm line-clamp-2">{a.question}</span>
                <span className="block text-xs subtle mt-2">
                  <span
                    className={
                      a.status === "completed"
                        ? "text-primary"
                        : a.status === "failed"
                          ? "text-red-700 dark:text-red-300"
                          : ""
                    }
                  >
                    {a.status}
                  </span>{" "}
                  ·{" "}
                  {new Date(a.created_at).toLocaleString(undefined, {
                    dateStyle: "short",
                    timeStyle: "short",
                  })}
                </span>
              </button>
            ))}
          </div>
        </aside>
        <div className="min-w-0">
          <form
            className="panel p-5"
            onSubmit={(e) => {
              e.preventDefault();
              void submit();
            }}
          >
            <label htmlFor="question" className="font-semibold">
              What would you like to explore?
            </label>
            {replay && (
              <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-900 p-3 text-sm flex flex-wrap items-center gap-3">
                <Info size={16} className="text-amber-700 shrink-0" />
                <span className="flex-1 min-w-[220px]">
                  <strong>Offline replay mode.</strong> AI responses are
                  scripted for one demo question, so other questions will stop
                  with a “no exact replay” message. SQL still runs for real.
                </span>
                <Button
                  type="button"
                  variant="outline"
                  disabled={busy}
                  onClick={() => setQuestion(DEMO_QUESTION)}
                >
                  Use the demo question
                </Button>
              </div>
            )}
            <textarea
              id="question"
              className="field w-full min-h-28 mt-3"
              maxLength={2000}
              value={question}
              disabled={busy}
              placeholder="Ask a business question about this dataset…"
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={(e) => {
                if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
                  e.preventDefault();
                  void submit();
                }
              }}
            />
            <div className="flex justify-between items-center gap-3 mt-3">
              <span className="subtle text-xs">
                Ctrl / ⌘ + Enter · {question.length}/2000
              </span>
              <div className="flex gap-2">
                {busy && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      controller.current?.abort();
                      setStatus("cancelling");
                    }}
                  >
                    <Square size={14} /> Cancel
                  </Button>
                )}
                <Button
                  type="submit"
                  disabled={busy || question.trim().length < 3}
                >
                  <Play size={14} />
                  {busy ? "Analyzing…" : "Analyze"}
                </Button>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 mt-5">
              {suggestions.data?.questions.map((q, i) => (
                <button
                  key={i}
                  type="button"
                  disabled={busy}
                  className="text-xs text-left border rounded-full px-3 py-2 hover:bg-muted disabled:opacity-50"
                  onClick={() => setQuestion(q.question)}
                >
                  {q.question}
                </button>
              ))}
            </div>
          </form>
          {dataset.error && <ErrorBox error={dataset.error} />}
          {error && (
            <div className="mt-4">
              <ErrorBox error={error} />
            </div>
          )}
          <p role="status" className="subtle text-xs mt-4 capitalize">
            {status}
          </p>
          {parentId && !busy && (
            <div className="panel p-4 mt-4 text-sm flex flex-wrap items-center gap-3 border-dashed">
              <span className="flex-1 min-w-[220px]">
                This is a <strong>challenge test</strong>: an alternative
                explanation checked automatically by Challenge My Insight.
              </span>
              <Button type="button" variant="outline" onClick={() => open(parentId)}>
                Back to the original finding
              </Button>
            </div>
          )}
          {plan && (
            <section className="panel p-5 mt-4">
              <h2 className="font-semibold">Analysis plan · {plan.intent}</h2>
              <p className="text-sm mt-2">{plan.explanation}</p>
              <p className="subtle text-xs mt-2">Period: {plan.time_range}</p>
              <ol className="list-decimal pl-5 mt-4 space-y-3">
                {plan.steps.map((s) => (
                  <li key={s.id} className="text-sm">
                    <strong>{s.purpose}</strong>
                    <p className="subtle text-xs mt-1">{s.expected_output}</p>
                  </li>
                ))}
              </ol>
              <details className="mt-4 text-sm">
                <summary className="cursor-pointer">
                  Metrics and assumptions
                </summary>
                <ul className="mt-2 space-y-2">
                  {plan.metrics.map((m) => (
                    <li key={m.name}>
                      {m.name}: {m.definition} ({m.unit})
                    </li>
                  ))}
                  {plan.assumptions.map((s, i) => (
                    <li key={i} className="subtle">
                      {s}
                    </li>
                  ))}
                </ul>
              </details>
            </section>
          )}
          {events.length > 0 && (
            <section
              className="panel p-5 mt-4"
              aria-label="Live execution timeline"
            >
              <h2 className="font-semibold">Live execution</h2>
              <ol className="mt-3 space-y-2 text-xs max-h-64 overflow-auto">
                {events.map((event) => (
                  <li
                    key={event.sequence}
                    className="border-l-2 border-primary pl-3"
                  >
                    <span className="subtle mr-2">
                      {new Date(event.timestamp).toLocaleTimeString()}
                    </span>
                    <strong>{event.type.replaceAll("_", " ")}</strong>
                    {"step_id" in event.payload &&
                      ` · ${event.payload.step_id} · attempt ${event.payload.attempt_no}`}
                    {"error" in event.payload && (
                      <span className="block text-amber-700 dark:text-amber-300">
                        {event.payload.error}
                      </span>
                    )}
                    {event.type === "sql_generated" && (
                      <details className="mt-2">
                        <summary className="cursor-pointer">
                          Generated SQL
                        </summary>
                        <pre className="whitespace-pre-wrap p-2 bg-muted">
                          {event.payload.sql}
                        </pre>
                      </details>
                    )}
                    {event.type === "validation" && (
                      <span className="ml-2">
                        Guard: {event.payload.status}
                      </span>
                    )}
                  </li>
                ))}
              </ol>
            </section>
          )}
          {attempts.map((a) => (
            <AttemptCard
              key={a.id}
              attempt={a}
              previous={attempts.find(
                (p) =>
                  p.step_id === a.step_id && p.attempt_no === a.attempt_no - 1,
              )}
            />
          ))}
          {finding && (
            <>
              <FindingCard finding={finding} />
              <FindingExtras
                key={activeId}
                finding={finding}
                analysisId={activeId}
                datasetId={id}
                challengeTest={!!parentId}
              />
            </>
          )}
          {!plan && !busy && !error && (
            <section className="panel p-10 text-center mt-5 subtle">
              Choose a suggested question or write your own. Plans, SQL
              attempts, and evidence will appear here.
            </section>
          )}
          <div ref={bottom} />
        </div>
      </div>
    </>
  );
}
export default function Ask({ params }: { params: { id: string } }) {
  return <Workspace key={params.id} id={params.id} />;
}
