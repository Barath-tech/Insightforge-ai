import tempfile
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile
from pydantic import BaseModel, Field
from sqlmodel import Session, select

from app.core.config import settings
from app.core.db import get_session
from app.models.metadata import Dataset, DatasetProfile, QueryRun
from app.services.executor import execute
from app.services.ingest import ingest, quote
from app.services.query import submit

router = APIRouter(prefix="/api/datasets", tags=["datasets"])


class DatasetResponse(BaseModel):
    id: str
    name: str
    source_type: str
    original_filename: str
    table_names: list[str]
    row_count: int
    created_at: str
    status: str


def public(dataset):
    value = dataset.model_dump(mode="json")
    value.pop("duckdb_path")
    return value


def get_dataset(identifier, session):
    dataset = session.get(Dataset, identifier)
    if not dataset:
        raise HTTPException(404, "Dataset not found.")
    return dataset


@router.get("", response_model=list[DatasetResponse])
def list_datasets(session: Session = Depends(get_session)):
    return [public(d) for d in session.exec(select(Dataset).order_by(Dataset.created_at.desc()))]


@router.post("", response_model=DatasetResponse, status_code=201)
def upload(file: UploadFile, session: Session = Depends(get_session)):
    filename = Path(file.filename or "upload").name
    suffix = Path(filename).suffix.lower()
    if suffix not in {".csv", ".db", ".sqlite"}:
        raise HTTPException(415, "Upload a .csv, .sqlite, or .db file.")
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, dir=settings.data_dir) as temp:
            size = 0
            while chunk := file.file.read(1024 * 1024):
                size += len(chunk)
                if size > settings.max_upload_mb * 1024 * 1024:
                    raise HTTPException(413, f"Upload exceeds {settings.max_upload_mb} MB.")
                temp.write(chunk)
            if not size:
                raise HTTPException(400, "The uploaded file is empty.")
            temp.flush()
            return public(ingest(Path(temp.name), filename, session))
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(422, f"Could not ingest this file: {str(exc)[:500]}") from exc
    finally:
        file.file.close()


@router.post("/demo", response_model=DatasetResponse, status_code=201)
def demo(sample: str = "messy", session: Session = Depends(get_session)):
    names = {
        "messy": "UK Retail Operations.csv",
        "clean": "uk_retail_clean.csv",
        "sqlite": "uk_retail.sqlite",
    }
    if sample not in names:
        raise HTTPException(422, "Choose messy, clean, or sqlite.")
    path = settings.data_dir / "samples" / names[sample]
    if not path.exists():
        raise HTTPException(404, "Demo fixture missing. Run make gen-data first.")
    try:
        return public(ingest(path, path.name, session))
    except Exception as exc:
        raise HTTPException(422, f"Demo import failed: {str(exc)[:500]}") from exc


@router.get("/{identifier}", response_model=DatasetResponse)
def detail(identifier: str, session: Session = Depends(get_session)):
    return public(get_dataset(identifier, session))


@router.get("/{identifier}/profile")
def profile(identifier: str, session: Session = Depends(get_session)):
    get_dataset(identifier, session)
    p = session.get(DatasetProfile, identifier)
    return {"health_score": p.health_score, **p.profile_json}


@router.get("/{identifier}/preview")
def preview(
    identifier: str,
    table: str,
    offset: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    session: Session = Depends(get_session),
):
    dataset = get_dataset(identifier, session)
    if table not in dataset.table_names:
        raise HTTPException(400, "Unknown dataset table.")
    try:
        return execute(
            dataset.duckdb_path,
            f"SELECT * FROM {quote(table)} LIMIT {limit + 1} OFFSET {offset}",
            dataset.table_names,
            settings.query_timeout_seconds,
            limit,
        )
    except Exception as exc:
        raise HTTPException(422, str(exc)) from exc


class QueryRequest(BaseModel):
    sql: str = Field(min_length=1, max_length=20000)


@router.post("/{identifier}/query")
def query(identifier: str, request: QueryRequest, session: Session = Depends(get_session)):
    dataset = get_dataset(identifier, session)
    outcome = submit(session, dataset, request.sql)
    return {"run": outcome["run"], "result": outcome["result"]}


@router.get("/{identifier}/queries")
def history(identifier: str, session: Session = Depends(get_session)):
    get_dataset(identifier, session)
    return session.exec(
        select(QueryRun)
        .where(QueryRun.dataset_id == identifier)
        .order_by(QueryRun.created_at.desc())
        .limit(50)
    ).all()
