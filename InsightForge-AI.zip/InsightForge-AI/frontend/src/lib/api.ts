import { z } from "zod";
import { readSSE } from "./streaming";
export const datasetSchema = z.object({
  id: z.string(),
  name: z.string(),
  source_type: z.string(),
  original_filename: z.string(),
  table_names: z.array(z.string()),
  row_count: z.number(),
  created_at: z.string(),
  status: z.string(),
});
export type Dataset = z.infer<typeof datasetSchema>;
const distribution = z.array(z.object({ name: z.string(), count: z.number() }));
const columnSchema = z.object({
  name: z.string(),
  semantic_type: z.string(),
  null_count: z.number(),
  null_pct: z.number(),
  distinct_count: z.number(),
  stats: z.record(z.number().nullable()).optional(),
  distribution: distribution.optional(),
  date_range: z.array(z.string().nullable()).optional(),
});
export type Column = z.infer<typeof columnSchema>;
const tableSchema = z.object({
  row_count: z.number(),
  column_count: z.number(),
  unique_ids: z.number().nullable(),
  date_range: z.array(z.string().nullable()).nullable(),
  health_score: z.number(),
  columns: z.array(columnSchema),
  issues: z.array(
    z.object({
      code: z.string(),
      column: z.string(),
      count: z.number(),
      severity: z.string(),
      message: z.string(),
      samples: z.array(z.string()),
    }),
  ),
  cleaning_log: z.array(
    z.object({
      column: z.string(),
      action: z.string(),
      affected_rows: z.number(),
    }),
  ),
  schema: z.array(z.object({ name: z.string(), type: z.string() })),
  column_mapping: z.record(z.string()),
});
const profileSchema = z.object({
  health_score: z.number(),
  tables: z.record(tableSchema),
});
export const chartSchema = z.object({
  type: z.string(),
  x: z.string().nullable(),
  y: z.array(z.string()),
  series: z.string().nullable(),
  title: z.string(),
  x_label: z.string(),
  y_label: z.string(),
  reason: z.string(),
  horizontal: z.boolean(),
  secondary_y: z.array(z.string()).default([]),
  compatible_types: z.array(z.string()),
  rows: z.array(z.record(z.unknown())),
  highlights: z.array(
    z
      .object({
        row_index: z.number(),
        row_key: z.string(),
        column: z.string(),
        callout: z.string(),
        method: z.string(),
      })
      .passthrough(),
  ),
});
export type Chart = z.infer<typeof chartSchema>;
const confidenceSchema = z.object({
  score: z.number(),
  label: z.string(),
  method: z.string(),
  breakdown: z.array(
    z.object({ factor: z.string(), contribution: z.number() }),
  ),
});
const driverSchema = z.object({
  component: z.string(),
  dimension: z.string(),
  rank: z.string(),
  margin_impact: z.number(),
  per_order_contribution: z.number().optional(),
  change_pct: z.number().nullable(),
  baseline: z.number(),
  target: z.number(),
});
const resultSchema = z.object({
  chart: chartSchema.optional(),
  columns: z.array(z.string()),
  column_types: z.array(z.string()).optional(),
  rows: z.array(z.record(z.unknown())),
  row_count: z.number(),
  elapsed_ms: z.number(),
  truncated: z.boolean(),
});
export type Result = z.infer<typeof resultSchema>;
const runSchema = z.object({
  id: z.string(),
  sql: z.string(),
  status: z.string(),
  error: z.string().nullable(),
  row_count: z.number(),
  elapsed_ms: z.number(),
  created_at: z.string(),
});
const querySchema = z.object({
  run: runSchema,
  result: resultSchema.nullable(),
});
export const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
// The only question with scripted responses in offline replay mode.
export const DEMO_QUESTION =
  "Why did profit margin decline in London in October?";
export async function request<T>(
  path: string,
  schema: z.ZodType<T, z.ZodTypeDef, unknown>,
  options?: RequestInit,
): Promise<T> {
  const response = await fetch(`${BASE}/api${path}`, options);
  if (!response.ok) {
    const body = await response
      .json()
      .catch(() => ({ detail: response.statusText }));
    throw new Error(
      typeof body.detail === "string"
        ? body.detail
        : JSON.stringify(body.detail),
    );
  }
  return schema.parse(await response.json());
}
export const api = {
  list: () => request("/datasets", z.array(datasetSchema)),
  dataset: (id: string) => request(`/datasets/${id}`, datasetSchema),
  profile: (id: string) => request(`/datasets/${id}/profile`, profileSchema),
  demo: (sample = "messy") =>
    request(`/datasets/demo?sample=${sample}`, datasetSchema, {
      method: "POST",
    }),
  preview: (id: string, table: string, offset: number) =>
    request(
      `/datasets/${id}/preview?table=${encodeURIComponent(table)}&offset=${offset}`,
      resultSchema,
    ),
  query: (id: string, sql: string) =>
    request(`/datasets/${id}/query`, querySchema, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sql }),
    }),
  history: (id: string) =>
    request(`/datasets/${id}/queries`, z.array(runSchema)),
  upload: (file: File, onProgress: (value: number) => void): Promise<Dataset> =>
    new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", `${BASE}/api/datasets`);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable)
          onProgress(Math.round((e.loaded / e.total) * 100));
      };
      xhr.onerror = () =>
        reject(
          new Error(
            "Could not reach the API. Check that the backend is running.",
          ),
        );
      xhr.onload = () => {
        try {
          const body = JSON.parse(xhr.responseText);
          if (xhr.status >= 400)
            throw new Error(body.detail || "Upload failed");
          resolve(datasetSchema.parse(body));
        } catch (e) {
          reject(e);
        }
      };
      const data = new FormData();
      data.append("file", file);
      xhr.send(data);
    }),
};

const metricSchema = z.object({
  name: z.string(),
  definition: z.string(),
  unit: z.string(),
  nonnegative: z.boolean(),
});
export const planSchema = z.object({
  intent: z.enum([
    "lookup",
    "trend",
    "comparison",
    "why",
    "distribution",
    "correlation",
  ]),
  answerable: z.boolean(),
  explanation: z.string(),
  metrics: z.array(metricSchema),
  dimensions: z.array(z.string()),
  filters: z.array(
    z.object({ column: z.string(), operator: z.string(), value: z.string() }),
  ),
  time_range: z.string(),
  assumptions: z.array(z.string()),
  steps: z.array(
    z.object({
      id: z.string(),
      purpose: z.string(),
      expected_output: z.string(),
      depends_on: z.array(z.string()),
    }),
  ),
});
const keyNumberSchema = z.object({
  label: z.string(),
  value: z.string(),
  unit: z.string(),
  source_step_id: z.string(),
  source_attempt: z.number().int(),
  column: z.string(),
  row_index: z.number().int(),
  conversion: z.enum(["identity", "fraction_to_percent"]),
  decimals: z.number().int(),
});
export const findingSchema = z.object({
  primary_chart: chartSchema.nullable().optional(),
  confidence: confidenceSchema.optional(),
  driver_summary: z.string().optional(),
  drivers: z.array(driverSchema).optional(),
  outliers: z.array(z.object({ callout: z.string() }).passthrough()).optional(),
  evidence: z
    .object({
      supporting_steps: z.array(
        z.object({
          step_id: z.string(),
          sql: z.string(),
          returned_rows: z.number(),
          truncated: z.boolean(),
        }),
      ),
      count_definition: z.string(),
      rows_scanned: z.array(
        z.object({
          table: z.string(),
          sql: z.string(),
          rows: z.number().nullable(),
        }),
      ),
      sample_sizes: z.array(
        z.object({
          group: z.string(),
          baseline: z.number(),
          target: z.number(),
        }),
      ),
      quality_issues: z.array(
        z.object({
          column: z.string(),
          message: z.string(),
          count: z.number(),
        }),
      ),
      decomposition: z.record(z.unknown()).nullable(),
      consistency: z
        .object({
          score: z.number(),
          comparable: z.boolean(),
          method: z.string(),
          signals: z.array(
            z.object({
              source: z.string(),
              measure: z.string(),
              margin_direction: z.number(),
            }),
          ),
        })
        .optional(),
    })
    .optional(),
  headline: z.string(),
  answer: z.string(),
  caveats: z.array(z.string()),
  key_numbers: z.array(keyNumberSchema),
  grounding_status: z.enum(["verified", "unverified"]),
  grounding_errors: z.array(z.string()),
});
export const attemptSchema = z.object({
  id: z.string(),
  analysis_id: z.string(),
  step_id: z.string(),
  attempt_no: z.number().int(),
  purpose: z.string(),
  rationale: z.string(),
  generated_sql: z.string(),
  normalized_sql: z.string().nullable(),
  validation_json: z.object({ status: z.string().optional() }),
  execution_summary_json: z.object({
    status: z.string().optional(),
    row_count: z.number().optional(),
    elapsed_ms: z.number().optional(),
    truncated: z.boolean().optional(),
    checks: z.array(z.string()).optional(),
  }),
  result_json: resultSchema.nullable(),
  query_run_id: z.string().nullable(),
  error: z.string().nullable(),
  status: z.string(),
  created_at: z.string(),
  completed_at: z.string().nullable(),
});
const analysisBase = z.object({
  id: z.string(),
  dataset_id: z.string(),
  question: z.string(),
  status: z.enum(["pending", "running", "completed", "failed", "cancelled"]),
  plan_json: planSchema.nullable(),
  finding_json: findingSchema.nullable(),
  grounding_status: z.string(),
  error: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
  completed_at: z.string().nullable(),
  challenge_of: z.string().nullable().optional(),
});
export const analysisSchema = analysisBase.extend({
  steps: z.array(attemptSchema),
});
export type Analysis = z.infer<typeof analysisSchema>;
export type Attempt = z.infer<typeof attemptSchema>;
export type Finding = z.infer<typeof findingSchema>;
const stepEvent = z.object({
  step_id: z.string(),
  attempt_no: z.number().int(),
  purpose: z.string(),
});
const envelope = {
  analysis_id: z.string(),
  sequence: z.number().int().positive(),
  timestamp: z.string(),
};
export const eventSchema = z.discriminatedUnion("type", [
  z.object({ ...envelope, type: z.literal("plan"), payload: planSchema }),
  z.object({
    ...envelope,
    type: z.literal("step_started"),
    payload: stepEvent,
  }),
  z.object({
    ...envelope,
    type: z.literal("sql_generated"),
    payload: stepEvent.extend({
      sql: z.string(),
      rationale: z.string(),
      measure_columns: z.array(z.string()),
      nonnegative_columns: z.array(z.string()),
      no_matching_data: z.boolean(),
    }),
  }),
  z.object({
    ...envelope,
    type: z.literal("validation"),
    payload: stepEvent.extend({
      status: z.enum(["ok", "failed"]),
      normalized_sql: z.string().optional(),
      error: z.string().optional(),
    }),
  }),
  z.object({
    ...envelope,
    type: z.literal("execution"),
    payload: attemptSchema,
  }),
  z.object({
    ...envelope,
    type: z.literal("correction"),
    payload: stepEvent.extend({
      status: z.literal("retrying"),
      error: z.string(),
    }),
  }),
  z.object({
    ...envelope,
    type: z.literal("step_done"),
    payload: stepEvent.extend({ status: z.enum(["ok", "failed"]) }),
  }),
  z.object({ ...envelope, type: z.literal("finding"), payload: findingSchema }),
  z.object({
    ...envelope,
    type: z.literal("error"),
    payload: z.object({
      status: z.literal("failed"),
      message: z.string(),
      code: z.string(),
    }),
  }),
  z.object({
    ...envelope,
    type: z.literal("done"),
    payload: z.object({ status: z.enum(["completed", "failed", "cancelled"]) }),
  }),
]);
export type AnalysisEvent = z.infer<typeof eventSchema>;
const narrativeSchema = z.object({
  narrative: z.string(),
  status: z.enum(["verified", "fallback"]),
  fact_refs: z.array(z.string()),
  errors: z.array(z.string()),
});
export const analysisApi = {
  history: (id: string) =>
    request(`/datasets/${id}/analyses`, z.array(analysisBase)),
  detail: (id: string) => request(`/analyses/${id}`, analysisSchema),
  suggestions: (id: string) =>
    request(
      `/datasets/${id}/suggestions`,
      z.object({
        status: z.string(),
        questions: z.array(
          z.object({
            question: z.string(),
            table: z.string(),
            columns: z.array(z.string()),
          }),
        ),
      }),
    ),
  narrative: (id: string, refresh = false) =>
    request(`/datasets/${id}/narrative?refresh=${refresh}`, narrativeSchema, {
      method: "POST",
    }),
  async ask(
    id: string,
    question: string,
    signal: AbortSignal,
    onEvent: (event: AnalysisEvent) => void,
  ) {
    const response = await fetch(`${BASE}/api/datasets/${id}/ask`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question }),
      signal,
    });
    if (!response.ok) {
      const error = await response
        .json()
        .catch(() => ({ detail: "Could not start analysis." }));
      throw new Error(
        typeof error.detail === "string" ? error.detail : "Invalid question.",
      );
    }
    if (!response.body)
      throw new Error("Streaming is unavailable in this browser.");
    let sequence = 0,
      analysisId = "",
      done = false;
    for await (const raw of readSSE(response.body, signal)) {
      const event = eventSchema.parse(raw);
      if (
        done ||
        event.sequence !== sequence + 1 ||
        (analysisId && analysisId !== event.analysis_id)
      )
        throw new Error("Invalid stream sequence.");
      sequence = event.sequence;
      analysisId = event.analysis_id;
      done = event.type === "done";
      if (!signal.aborted) onEvent(event);
    }
    if (!done && !signal.aborted)
      throw new Error(
        "Connection ended before analysis completed. Reopen history to inspect its status.",
      );
  },
};

const factSchema = z.object({
  id: z.string(),
  table: z.string(),
  column: z.string().nullable(),
  label: z.string(),
  value: z.union([z.number(), z.string()]),
  category: z.enum(["number", "date", "identifier"]),
});
export const datasetContextSchema = z.object({
  dataset: z.object({ id: z.string(), name: z.string() }),
  tables: z.array(
    z.object({
      name: z.string(),
      role: z.enum(["raw", "clean"]),
      clean_table: z.string(),
      raw_table: z.string(),
      columns: z.array(
        z.object({
          name: z.string(),
          type: z.string(),
          semantic_type: z.string().nullable(),
          samples: z.array(z.string()),
        }),
      ),
      column_mapping: z.record(z.string()),
      cleaning_notes: z.array(
        z.object({
          column: z.string(),
          action: z.string(),
          affected_rows: z.number(),
        }),
      ),
    }),
  ),
  facts: z.array(factSchema),
  issues: z.array(
    z.object({
      table: z.string(),
      code: z.string(),
      column: z.string(),
      count: z.number(),
      severity: z.enum(["high", "medium", "low"]),
      message: z.string(),
    }),
  ),
});
export const getDatasetContext = (id: string) =>
  request(`/datasets/${id}/schema`, datasetContextSchema);

const challengeItemSchema = z.object({
  id: z.string(),
  status: z.string(),
  result_json: z.object({
    original_confidence: z.number(),
    revised_confidence: z.number().optional(),
    verdict_summary: z.string().optional(),
    surviving_explanation: z.string().optional(),
    confidence_explanation: z.string().optional(),
    hypotheses: z.array(
      z.object({
        id: z.string(),
        hypothesis: z.string(),
        rationale: z.string(),
        verdict: z.string(),
        explanation: z.string(),
        chart: chartSchema.nullable(),
        steps: z.array(attemptSchema),
      }),
    ),
    quality_checks: z.array(
      z.object({
        name: z.string(),
        verdict: z.string(),
        explanation: z.string(),
        sql: z.string().optional(),
      }),
    ),
    error: z.string().optional(),
  }),
});
export type Challenge = z.infer<typeof challengeItemSchema>;
export const finalApi = {
  challenges: (id: string) =>
    request(`/analyses/${id}/challenges`, z.array(challengeItemSchema)),
  pins: (id: string) =>
    request(
      `/datasets/${id}/pins`,
      z.array(
        z.object({
          item_id: z.string(),
          kind: z.string(),
          pinned: z.boolean(),
        }),
      ),
    ),
  pin: (kind: string, id: string, pinned: boolean) =>
    request(`/${kind}/${id}/pin`, z.object({ pinned: z.boolean() }), {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pinned }),
    }),
  async challenge(
    id: string,
    signal: AbortSignal,
    onEvent: (event: {
      type: string;
      payload: Record<string, unknown>;
    }) => void,
  ) {
    const response = await fetch(`${BASE}/api/analyses/${id}/challenge`, {
      method: "POST",
      signal,
    });
    if (!response.ok)
      throw new Error((await response.json()).detail || "Challenge failed");
    if (!response.body) throw new Error("Streaming unavailable");
    for await (const raw of readSSE(response.body, signal)) {
      const event = z
        .object({ type: z.string(), payload: z.record(z.unknown()) })
        .parse(raw);
      onEvent(event);
    }
  },
};

const briefContentSchema = z.object({
  situation: z.string(),
  evidence: z.array(z.object({ text: z.string(), source: z.string() })),
  root_cause: z.string(),
  business_impact: z.string(),
  recommended_actions: z.array(
    z.object({
      owner_role: z.string(),
      priority: z.string(),
      expected_impact: z.string(),
      linked_evidence: z.string(),
    }),
  ),
  risks_and_caveats: z.array(z.string()),
  confidence_statement: z.string(),
});
export type BriefContent = z.infer<typeof briefContentSchema>;
export const healthSchema = z.object({
  status: z.string(),
  phase: z.number(),
  llm_enabled: z.boolean(),
  demo_replay: z.enum(["off", "record", "replay"]),
});
export type Health = z.infer<typeof healthSchema>;
export const progressSchema = z.object({
  analyses: z.number(),
  completed_analyses: z.number(),
  latest_completed_analysis_id: z.string().nullable(),
  challenged_analyses: z.number(),
  pinned_findings: z.number(),
  pinned_challenges: z.number(),
  briefs: z.array(
    z.object({
      id: z.string(),
      title: z.string(),
      created_at: z.string(),
      grounding_status: z.string(),
    }),
  ),
});
export type Progress = z.infer<typeof progressSchema>;
export const statusApi = {
  health: () => request("/health", healthSchema),
  progress: (id: string) => request(`/datasets/${id}/progress`, progressSchema),
};
export const briefSchema = z.object({
  id: z.string(),
  dataset_id: z.string(),
  title: z.string(),
  audience: z.string(),
  created_at: z.string(),
  analysis_ids: z.array(z.string()),
  content_json: briefContentSchema,
  grounding_json: z.object({ status: z.string(), errors: z.array(z.string()) }),
  evidence_json: z
    .object({
      dataset_name: z.string(),
      numbers: z.record(z.number()),
      sources: z.array(z.string()).default([]),
      templates: briefContentSchema.optional(),
    })
    .passthrough(),
});
export type Brief = z.infer<typeof briefSchema>;
export const briefApi = {
  create: (id: string, analysis_ids?: string[]) =>
    request(`/datasets/${id}/briefs`, briefSchema, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ analysis_ids }),
    }),
  get: (id: string) => request(`/briefs/${id}`, briefSchema),
  edit: (id: string, body: Partial<z.infer<typeof briefContentSchema>>) =>
    request(`/briefs/${id}`, briefSchema, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }),
};
export const auditSchema = z.object({
  calls: z.array(
    z.object({
      id: z.string(),
      analysis_id: z.string().nullable(),
      dataset_id: z.string(),
      purpose: z.string(),
      model: z.string(),
      prompt_version: z.string(),
      input_tokens: z.number().nullable(),
      output_tokens: z.number().nullable(),
      latency_ms: z.number(),
      status: z.string(),
      request_json: z.record(z.unknown()),
      response_json: z.record(z.unknown()).nullable(),
    }),
  ),
  totals: z.object({
    calls: z.number(),
    input_tokens: z.number(),
    output_tokens: z.number(),
    unknown_usage_calls: z.number(),
    latency_ms: z.number(),
    correction_attempts: z.number(),
    corrected_steps: z.number(),
    correction_success_rate: z.number().nullable(),
  }),
});
